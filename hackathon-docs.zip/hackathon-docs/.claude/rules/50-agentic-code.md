---
paths:
  - "src/agents/**"
  - "src/tools/**"
  - "src/guardrails/**"
  - "src/prompts/**"
  - "src/observability/**"
  - "mcp_server/**"
  - "tests/agents/**"
  - "docs/04-agent-designs/**"
---

# Agents and workflows

## AI folders inside `src/`
`config.py` (Settings: model names, limits, thresholds in ONE place) · `schemas.py` (agent I/O Pydantic models, in the same file as the API DTOs) · `agents/common/` (shared infra) + `agents/<name>.py` (one file per agent) · `tools/<tool>.py` + `tools/registry.py` · `guardrails/` (code gates) · `prompts/<name>.md` (prompt text) · `observability/trace.py` (tool calls, cost, latency to `logs/`). Demo data: `data/sample/` (inputs), `data/fixtures/` (mock DB/API data). Scored demo cases: `tests/cases.py`, run with `uv run python -m tests.run_tests`. MCP (only if the case needs it): `mcp_server/` in the project root (server entry + one module per exposed tool, reusing `src/tools/`) and `.mcp.json` in the root to register it.

- Follow the `agentic-workflow-standards` skill and the full checklist in its `reference/` folder; build only what an approved `AD##` design specifies.
- Name the pattern(s) from the skill's pattern catalogue (P01-P15) in every design or suggestion, lowest tier first; read only the chosen `patterns/P##-*.md` files when needed.
- Tools return `ToolResult` with the status enum; errors carry code, message, context, suggested_action; coordinator errors use `ErrorEnvelope` severities.
- Structured outputs via `LLMClient.extract_structured` (strict tool + Pydantic validation loop). Retries only for transient errors. Budgets and stop conditions in code.
- Prompts: versioned `src/prompts/<name>.md` files with 5 sections, frozen (no dates/ids/facts in `system`), cached. Context: budget per step, tool output trimmed, compaction decided in the design (when / where / how) and built per `examples/06`.
- Model ids and the API key come from env vars only. Tests use the fake Messages API; never call the real model in tests.

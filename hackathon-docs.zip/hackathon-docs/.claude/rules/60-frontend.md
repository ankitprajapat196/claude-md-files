---
paths:
  - "static/**"
  - "templates/**"
---

# Frontend

- Follow the `vanilla-frontend-standards` skill: plain HTML/CSS/ES modules, no frameworks, no build step.
- Page controller -> service -> `static/js/core/api-client.js` (the only place that calls `fetch`).
- Build DOM with `h()`/text nodes; no `innerHTML` with data, no inline scripts or `on*=` attributes.
- Colours/spacing only from `static/css/tokens.css` variables. Render loading, empty, error, and success states. Label every input.

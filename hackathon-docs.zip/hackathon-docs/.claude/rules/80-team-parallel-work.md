# Team parallel work and feature dependencies

After MoSCoW is approved, each of the 4 teammates works alone in their own clone on their own branch (`feat/F##-<slug>`). Approvals live in `.workflow/approvals/` and travel through git, so a teammate's work becomes visible here only after they push it and you pull it.

## Before starting a stage
- Run `git pull` (or merge `main`) so you see teammates' accepted features and approvals.
- Commit code together with its `.workflow/approvals/` files, and push after every approval so teammates can pull it.
- In shared files (`src/schemas.py`, `src/dependencies/providers.py`, `src/api/v1/router.py`, `app/main.py`), add only your feature's own section or lines. Do not reformat or reorder other features' code; this keeps merges small.

## Dependency check (used by `/plan-feature`, `/implement-feature`, `/design-agent`, `/build-agent`)
1. Read the feature's `Depends on:` line in `docs/02-moscow/*/<F##>-*.md` (or the `Depends on` column in `docs/02-moscow/00-MOSCOW-INDEX.md`).
2. A dependency is **met** when:
   - for planning or design: its plan is `approved` or the feature is accepted (the status table shows it);
   - for implementation or build: the feature is accepted (`accepted = yes` in the status table).
3. If every dependency is met, or there are none, continue silently.
4. Otherwise, list the unmet ones with their names, then ask the human with AskUserQuestion (one question, these three options):
   - **A. A teammate has finished it.** Tell the human: ask the teammate who owns `<F##>` to commit and push the code with its `.workflow/approvals/` files, then run `git pull` (or `git merge origin/<their branch>`) here and rerun this same command. Stop.
   - **B. A teammate has not finished it yet.** Tell the human: ask the teammate to finish `<F##>` and get it accepted (`/approve-stage feature <F##>`), push it, then pull and rerun this command. Meanwhile, pick another feature with no unmet dependencies (name one or two from the status table). Stop.
   - **C. Mock the dependency and continue.** Continue the stage and add `Dependency mode: MOCK <F##>,<F##>` to the delegation message. For implementation, the stage-gate hook may then ask its own "Continue anyway?" question; the human answers yes.
5. Never choose an option for the human.

## Mock rules (Dependency mode: MOCK)
- **Planning:** plan against the dependency's assumed contract, taken from its MoSCoW file, its plan if one exists, and the PRD. Add a section `## Assumed dependency contracts` that lists, per dependency, the functions, endpoints, schemas, and fields relied on, each marked `ASSUMED (F##)`.
- **Implementation:** put mock code only in new files that belong to this feature:
  - backend: `src/mocks/dep_<f##>.py` (for example `src/mocks/dep_f02.py`), a fake class or functions matching the assumed contract, returning deterministic data;
  - frontend: `static/js/mocks/dep-<f##>.js`.
- Never create or edit files that belong to the dependency feature itself; its owner is building them.
- Every line outside the mock files that wires a mock in (imports, the provider in `providers.py`, a fallback) carries the comment `DEP-MOCK(<F##>)`. The mock files start with a module docstring containing `DEP-MOCK(<F##>)`.
- The implementation note gets a `## Mocks to remove` table: dependency, mock file, wiring lines (file:line), real target to wire instead.
- Tests may run against the mocks. A feature must not be accepted while it still contains `DEP-MOCK` markers.

## Mock-removal reminder
`/test-feature`, `/review-feature`, `/approve-stage feature`, and `/show-status` search for `DEP-MOCK` (Grep tool over `src/`, `static/`, `templates/`, `tests/`, `app/`). For each mocked dependency of the feature, show:
- If the dependency is now accepted here: "Mocks for `<F##>` are still in place. Remove them now:" followed by the exact command
  `/revise-artifact feature <this F##> Remove DEP-MOCK(<F##>): delete the mock files, wire the real <F##> code per the "Mocks to remove" table, remove the markers, rerun tests.`
  then "After that, rerun `/test-feature <this F##>`."
- If the dependency is still not accepted: "`<this F##>` runs on mocks of `<F##>`. Do not accept it yet. When `<F##>` is accepted, pull it and remove the mocks (the command will be shown then)."

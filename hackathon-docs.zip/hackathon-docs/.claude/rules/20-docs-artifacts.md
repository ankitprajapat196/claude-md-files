---
paths:
  - "docs/**"
---

# Docs and artifacts

- Naming, IDs, templates, and the RESULT block are defined in the `workflow-artifacts` skill; follow them exactly (hooks parse `F##-<slug>`, `AD##-<slug>`, `Depends on:`, and `**Overall result:** PASS|FAIL`).
- Never write "Approved" in a document; the approval ledger in `.workflow/approvals/` is the only source of truth.
- Editing an approved artifact invalidates its approval (content hash). Only edit approved artifacts through `/revise-artifact`.
- Keep slugs stable across all artifacts of the same item.

---
paths:
  - "src/api/**/*.py"
  - "src/schemas.py"
  - "src/services/**/*.py"
---

# API contract

- Follow the `production-api-standards` skill and its examples.
- Success: `SuccessResponse[T]` envelope `{data, meta}`; errors: RFC 9457 problem+json via the global handlers (never build error JSON in a controller).
- Correct status codes (201 + Location on create, 204 on delete, 404 for other users' objects, 409/412/428/422 as specified).
- POST with side effects requires `Idempotency-Key`; updates use `ETag`/`If-Match`; lists use cursor pagination with a max page size.
- Controllers: one service call, no business logic, no DAO or SQLAlchemy imports.

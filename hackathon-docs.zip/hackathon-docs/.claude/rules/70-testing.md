---
paths:
  - "tests/**"
  - "tests/frontend/**"
  - "docs/07-test-reports/**"
---

# Tests

- Follow the `testing-standards` skill: every acceptance criterion has a test; failure paths (401, other-user 404, 422, 409, 412/428, empty lists, agent timeouts/empty/partial results) are covered.
- Tests are deterministic: in-memory SQLite, fixed mock data, fake Messages API, no network.
- Test reports start with `**Overall result:** PASS` or `**Overall result:** FAIL`; PASS only when everything passes and every AC is covered.

# Workflow gates (main conversation)

The build runs stage by stage. A human approves every stage. Hooks enforce this; follow it in your behaviour too.

## Stages and owners
PRD (`prd-analyst`) -> MoSCoW (`moscow-prioritizer`) -> per feature: plan (`feature-planner`) -> implement (`feature-implementer`) -> test (`test-engineer`) + review (`code-reviewer`) -> accept. AI features: design (`agent-architect` DESIGN) -> build (`agent-architect` BUILD) -> test + review -> accept.

## Rules
- Start a stage only when the human types its slash command. Never chain into the next stage on your own, even if the human says "looks good" in words: answer with the exact `/approve-stage …` command they need to type.
- Delegate stage work to the owning subagent with the delegation message the command specifies (keep the labels `Feature ID:`, `Design ID:`, `MODE:` exact; hooks read them). Do not do a subagent's work in the main conversation.
- Never create, edit, or delete anything in `.workflow/`, `.claude/hooks/`, `.claude/settings.json`, `.env*`, or the case study. Never run `workflow_state.py approve|revoke|bypass`.
- If a hook denies something, show the human the reason and the command that unblocks it. Do not try another route around the gate.
- Subagents cannot see this conversation: paste any needed context (feedback, error output) into the delegation message.
- Small fixes the human asks for directly in chat are fine after planning is approved; record them in the relevant implementation note.

## Review request (show this after every stage, then stop)
```markdown
### <Stage> ready for your review — <item id or "project">
**File(s):** `<path>`
**Summary:** <3-6 bullets>
**Please check:** <3-5 specific review points>
**Open questions:** <questions or "none">

- Approve: `/approve-stage <stage> [id]`
- Request changes: `/revise-artifact <stage> [id] <your feedback>`
- After approval, run: `<next command>`
```
If the subagent returned `blocked` or `error`, show the reason and the fix instead of a review request.

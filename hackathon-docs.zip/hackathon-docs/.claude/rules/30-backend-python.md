---
paths:
  - "app/**/*.py"
  - "src/**/*.py"
---

# Backend Python

- Follow the `python-layered-architecture` skill: Controller -> Service -> DAO -> Schema/Model, wiring only in `src/dependencies/providers.py`. `app/main.py` is only the app factory (see `app/CLAUDE.md`). Everything else lives directly under `src/`: `config.py`, `schemas.py`, `core/`, `api/`, `services/`, `dao/`, `models/`, `dependencies/` plus the AI folders `agents/`, `tools/`, `guardrails/`, `prompts/`, `observability/`. Settings only in `src/config.py`; all Pydantic models only in `src/schemas.py` (one commented section per feature). `app` imports `src`; `src` never imports `app`. Agents/tools/guardrails never import `src.api` or `src.dependencies`; services call agents, controllers never do.
- Every module, public class, and public function has a Google-style docstring (`Args:`, `Returns:`, `Raises:`) and full type hints.
- Validate input with Pydantic request schemas (`extra="forbid"`) and output with response schemas; services return DTOs, never ORM objects.
- Raise `src.core.errors.AppError` subclasses with a specific `code`; never bare `except`, never `print()`.
- The quality-gate hook runs ruff and these checks after each write; fix its findings before moving on.
- Dev auth: `Authorization: Bearer dev-<user_id>` works only when `APP_ENVIRONMENT` is dev/test.
- Dependencies: `uv add <pkg>` (dev: `uv add --dev <pkg>`); commit `pyproject.toml` and `uv.lock`; list new packages in the implementation note.
- First feature only: if `src/core/` does not exist, create it from `.claude/skills/production-api-standards/examples/01-core-infrastructure.md` (`Settings` goes in `src/config.py`); later features reuse it.
- Migrations: Alembic (`migrations/` in the project root) once PostgreSQL is used; `create_all` runs only in dev/test.
- Error codes: UPPER_SNAKE_CASE, unique per meaning, listed in the implementation note (e.g. `RESOURCE_NOT_FOUND`, `VALIDATION_FAILED`, `VERSION_MISMATCH`).
- Run tests with `uv run pytest -q`.

# Mock data — MD## <Scope>

| Field | Value |
|---|---|
| For | F## / AD## / demo |
| Files | `data/fixtures/<entity>.json`, `data/seed_mock_data.py` |
| Seed command | `uv run python -m data.seed_mock_data` |

## Datasets
| File | Records | Schema (Pydantic model) | Purpose |
|---|---|---|---|

## Coverage
| Case type | Examples | Why |
|---|---|---|
| Typical | | |
| Edge (limits, unicode, empty optional fields) | | |
| Invalid / adversarial (for negative tests, prompt-injection text) | | |
| Demo story records | | |

## Rules followed
- Fake but realistic (Indian names/addresses/phones where relevant), no real PII.
- Deterministic (fixed seed), ids stable across runs.
- Validates against the app's request schemas.

## Revision history
| Version | Date | Change |
|---|---|---|

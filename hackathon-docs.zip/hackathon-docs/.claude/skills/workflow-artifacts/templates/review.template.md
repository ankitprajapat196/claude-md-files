# Review — <F## / AD##> <Name>

| Field | Value |
|---|---|
| Reviewed | <commit / files> |
| Verdict | APPROVE | APPROVE WITH FIXES | CHANGES REQUIRED |

## Findings
| # | Severity (Critical/High/Medium/Low) | File:line | Problem | Fix |
|---|---|---|---|---|

## Checklist pass
| Area | Result | Notes |
|---|---|---|
| Layering (C-S-D-S) | | |
| Validation in/out | | |
| Response envelope / problem+json | | |
| AuthN / AuthZ (BOLA) | | |
| Idempotency / concurrency | | |
| Docstrings / type hints | | |
| Security (secrets, injection, XSS) | | |
| Tests cover failure paths | | |
| Agentic checklist (if AI) | | |

## Strengths
-

## Revision history
| Version | Date | Change |
|---|---|---|

# Agent design — AD## <Name>

| Field | Value |
|---|---|
| Version | v1.0 |
| Status | Draft / Ready for review |
| Requested for | <feature F## or need> |
| PRD refs | US-##, FR-## |

## 1. Need
Problem, inputs, expected output, who consumes it, how often, latency/cost tolerance.

## 2. Decision: single call vs workflow vs agent vs hybrid
| Option | Fits? | Why / why not |
|---|---|---|
| Single LLM call | | |
| Deterministic workflow | | |
| Agent (dynamic tool use) | | |
| Hybrid | | |
**Recommendation:** <one line>. **Trade-offs accepted:** cost vs capability, auditability vs flexibility, reliability vs adaptability.

## 3. Pattern and topology
**Pattern(s):** P## <name> (tier) [+ P## ...] from the `agentic-workflow-standards` pattern catalogue. **Why not simpler:** <why the next lower-tier pattern fails>.
Sequential / parallel / hierarchical; single vs multi-agent (justify overhead); hub-and-spoke or pipeline; replanning rule; which must-haves from each pattern file apply.

## 4. Architecture
```mermaid
flowchart LR
  In[Input] --> S1[Step 1] --> V{Validate} --> S2[Step 2] --> Out[Output]
  V -- invalid --> R[Retry with errors] --> S1
```

## 5. Steps
| # | Step | Deterministic or LLM | Model tier | Input | Output schema | Validation | On failure |
|---|---|---|---|---|---|---|---|

## 6. Prompts (per LLM step) — checklist §3, `examples/06`
| Step | Prompt file (`src/prompts/<name>.md`, version) | Role (one line) | Context: tags the user message carries | Key instructions + output format | Constraints (never / out of scope) | Examples (count; edge + injection case?) | Output steering (structured output / strict tool) | Thinking / effort |
|---|---|---|---|---|---|---|---|---|

Conflict check: list any rule that appears in two places (prompt, tool descriptions, examples) and say which one wins. Frozen-prompt check: no dates, ids or facts in `system`. Prompt changes bump `version` and rerun the eval set.

## 7. Tools
| Tool | Description (what / when / when NOT) | Input schema (strict?) | Returns (status enum) | Side effects / idempotency |
|---|---|---|---|---|
tool_choice per step: auto / any / specific / none.

## 8. Response contract and errors
Status enum (`success`, `empty_result`, `partial_result`, `access_failure`), ToolError 4 fields, ErrorEnvelope (type, severity, context, recovery_hint) and severity policy.

## 9. Validation and hallucination control
Schema + semantic checks, grounding (evidence quotes), "not found" allowed, reviewer pass?

## 10. Error handling
Classification, retry (transient only, backoff + jitter, max attempts), idempotency keys, circuit breaker, fallback chain (primary -> alternate -> degraded -> human).

## 11. Loop control and budgets
Stop conditions: complete / error threshold / budget / stop signal. Limits: turns, tokens, cost per run. Spinning detection.

## 12. Guardrails
Pre-execution, post-execution, runtime; hard block vs soft warning.

## 13. Context management — checklist §10, `examples/06`
**Budget per LLM step / loop:**
| Step or loop | Model (window) | Est. input tokens per call (system + tools + data) | Reserved output | Grows over turns? | Compaction trigger (`compact_at` share of usable window) | Tool-output cap |
|---|---|---|---|---|---|---|

**Compaction plan:**
- **When:** which loops can reach the trigger. "None" is a valid answer for workflows; say why.
- **Where:** before each model call, never mid tool round. For workflows: the step boundaries.
- **How:** server-side compaction (live, long sessions), client-side simple compaction (`ContextManager`), or context editing. Say why that choice fits.
- **Fact block keys:** ids, numbers, decisions and constraints that must survive compaction. Which ones code sets (authoritative).
- **Never in context:** what is trimmed or paginated. What sub-agents receive and return (condensed only).

**Caching:**
- Frozen system prompt + breakpoint.
- Fixed tool list.
- Where dynamic data goes.
- Expected `cache_read_input_tokens` on repeat calls.
- Prefix >= 512 tokens or "not cached".

**Tests:**
- Facts survive compaction.
- The original request stays verbatim.
- No compaction runs mid tool round.
- `system` is identical across turns.

## 14. State and checkpointing
What is persisted, where, resume behaviour.

## 15. Human-in-the-loop
Triggers (hard/soft), interruption points, handoff payload (summary, verbatim question, attempts, next step), review queue.

## 16. Security
Least privilege, untrusted tool output, prompt-injection defences, secrets/PII.

## 17. Evaluation plan
| Case type | Examples | Grader (code/model) | Pass threshold |
|---|---|---|---|
| Typical | | | |
| Edge | | | |
| Adversarial | | | |

## 18. Observability and cost
Trace id, logged fields, estimated tokens and cost per run, latency target.

## 19. Implementation plan
Files: `src/agents/<name>.py`, `src/prompts/<name>.md`, `src/tools/*`, `src/guardrails/*`, endpoint that exposes it, tasks ≤ 2 h.

## 20. Checklist coverage (agent_workflow_production_checklist §1-15)
| § | Topic | How addressed | N/A reason |
|---|---|---|---|

## Revision history
| Version | Date | Change | Reason / feedback |
|---|---|---|---|

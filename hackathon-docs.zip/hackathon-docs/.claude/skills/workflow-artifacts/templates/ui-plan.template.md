# UI plan: F## <Feature name>

**Status:** Draft | Ready for review
**Version:** v1.0
**Feature plan:** `docs/03-feature-plans/F##-<slug>.plan.md`
**Design file:** `DESIGN.md`
**Mode per page:** create | improve

## 1. Goal and users
- Persona(s) and the job they do on these screens (cite the PRD persona and `US-##`).
- One-line UX goal (what should feel fast, clear, or trustworthy).

## 2. Screens
| Screen | URL | Template file | Page module | Create / improve | User stories |
|---|---|---|---|---|---|

## 3. User flow
```mermaid
flowchart LR
  A[Entry] --> B[Screen]
```
Cite the flow from the feature plan it follows.

## 4. Screen layouts
One subsection per screen: wireframe (ASCII), regions top to bottom, primary action, secondary actions, and responsive behaviour at 360 / 768 / 1280 px.

## 5. Components
| Component | Used on | Purpose | Source of the idea (DESIGN.md / ui-ux-pro-max / 21st) | Notes |
|---|---|---|---|---|

## 6. States
| Screen | Loading | Empty | Error (retry + request id) | Success | Feature-specific states |
|---|---|---|---|---|---|

## 7. Visual system (from DESIGN.md)
| Token | Value | Used for |
|---|---|---|
List new or changed tokens for `static/css/tokens.css` (light and dark). Note anything DESIGN.md does not cover and what you chose instead.

## 8. Interaction and motion
Hover, focus, pressed, disabled, transitions (durations, easing), `prefers-reduced-motion` fallback.

## 9. Accessibility
Landmarks, heading order, labels, keyboard order, focus management, contrast checks, live regions for async updates.

## 10. Data mapping
| UI element | API endpoint | Field | Formatting |
|---|---|---|---|
Only endpoints and fields from the feature plan. Missing data -> `OPEN QUESTION:`.

## 11. Guidance applied
- ui-ux-pro-max: queries run and rules applied.
- 21st: components looked at and how they will be translated to vanilla HTML/CSS/JS.
- Conflicts between sources and how they were resolved.

## 12. Files to create or change
| File | Change |
|---|---|

## 13. Acceptance checklist
- [ ] Every screen renders loading, empty, error, success
- [ ] Keyboard-only use works, focus visible
- [ ] Contrast >= 4.5:1 in light and dark
- [ ] No horizontal scroll at 360 px
- [ ] Only `tokens.css` variables for colours and spacing
- [ ] No `innerHTML` with data, no inline scripts

## 14. Open questions
`OPEN QUESTION:` items or "none".

## Revision history
| Version | Date | Change | Reason |
|---|---|---|---|
| v1.0 | YYYY-MM-DD | First draft | — |

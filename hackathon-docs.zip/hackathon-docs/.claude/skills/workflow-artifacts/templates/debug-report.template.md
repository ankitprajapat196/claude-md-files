# Debug — BUG## <Short title>

| Field | Value |
|---|---|
| Reported symptom | |
| Status | FIXED | NEEDS HUMAN | CANNOT REPRODUCE |
| Affects | F## / AD## |

## Reproduction
Steps / command / request id.

## Root cause
What and why (evidence: logs, failing test, file:line).

## Fix
| File | Change |
|---|---|

## Verification
Test added/updated and result.

## Prevention
-

# PRD — <Product name>

| Field | Value |
|---|---|
| Version | v1.0 |
| Status | Draft / Ready for review |
| Source | `<case study file>` |
| Team | CyberBulls |
| Last updated | <YYYY-MM-DD HH:MM> |

## 1. Executive summary
<5 lines max: problem, who has it, our solution, the AI angle, why it wins.>

## 2. Problem statement and context
- Current situation:
- Pain points (with evidence from the case study):
- Why now / why AI:

## 3. Goals and success metrics
| Goal | Metric | Target | How we measure in the demo |
|---|---|---|---|

**Judging alignment:** map each likely judging criterion (problem importance, technical depth, working demo, innovation, impact, presentation) to how this product scores.

## 4. Personas
| ID | Persona | Role | Goals | Pain points | Tech comfort | Key scenario |
|---|---|---|---|---|---|---|
| P1 | | | | | | |

## 5. Scope
- **In scope (30-hour build):**
- **Out of scope:**
- **Assumptions:** (each prefixed ASSUMPTION:)
- **Constraints:** 30-hour build, team of 4, Python FastAPI + PostgreSQL backend, HTML/CSS/JS frontend, Claude API for AI features, no pre-built solution code.

## 6. User stories
| ID | Persona | As a… I want… so that… | Acceptance criteria (Given/When/Then) | Priority hint |
|---|---|---|---|---|
| US-01 | P1 | | | High |

## 7. Main feature flows
For each core flow: one-line purpose + Mermaid diagram (flowchart or sequenceDiagram) + happy path + main failure paths.

### Flow 1 — <name>
```mermaid
flowchart LR
  A[Start] --> B[Step] --> C[Outcome]
```

## 8. Functional requirements
| ID | Requirement | Traces to | Notes |
|---|---|---|---|
| FR-01 | | US-01 | |

## 9. AI / agentic capabilities
| Capability | User value | Workflow or agent? (first guess) | Model tier | Human-in-the-loop point | Risk if wrong |
|---|---|---|---|---|---|
Note: final designs come from `/design-agent`.

## 10. Conceptual data model
```mermaid
erDiagram
  USER ||--o{ ITEM : owns
```
| Entity | Key fields | Notes (PII? retention?) |
|---|---|---|

## 11. Non-functional requirements
Performance (p95 targets), security (authn/authz, OWASP API Top 10), reliability, observability (request id, logs), accessibility, cost (LLM budget per request).

## 12. Integrations and external dependencies
| Dependency | Purpose | Failure mode | Fallback |
|---|---|---|---|

## 13. Risks and mitigations
| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|

## 14. Open questions
- OPEN QUESTION: …

## 15. Glossary
| Term | Meaning |
|---|---|

## 16. Traceability matrix
| User story | Functional requirements | Flow |
|---|---|---|

## Revision history
| Version | Date | Change | Reason / feedback |
|---|---|---|---|
| v1.0 | | Initial draft | |

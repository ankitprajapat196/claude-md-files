# Implementation — <F## / AD##> <Name>

| Field | Value |
|---|---|
| Version | v1.0 |
| Plan / design | `<path>` |
| Scope built | full / backend / frontend |
| Status | Ready for review |

## What was built
- Endpoints / pages / agent steps

## Files changed
| File | Layer | Change |
|---|---|---|

## API contract as built
| Method | Path | Status codes | Notes vs plan |
|---|---|---|---|

## Deviations from the plan
| Plan item | What changed | Why |
|---|---|---|

## Production API checklist (§ relevant to this feature)
| Item | Done? | Evidence (file:line or test) |
|---|---|---|

## How to run and try it
Commands, sample curl, page URL, dev token.

## Known limitations / follow-ups
-

## Revision history
| Version | Date | Change | Reason / feedback |
|---|---|---|---|

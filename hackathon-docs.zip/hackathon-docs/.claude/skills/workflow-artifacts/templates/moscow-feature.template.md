# F## — <Feature name>

- **Feature ID:** F##
- **Priority:** Must have | Should have | Could have
- **Depends on:** none | F01, F02
- **Personas:** P1
- **Source user stories:** US-01, US-02
- **Source requirements:** FR-01
- **Effort:** S | M | L (<hours> h)
- **Independently testable:** Yes | Partly (why)
- **Status:** Draft / Ready for review

## Description
<2-4 sentences: what it does and the value delivered.>

## In scope / out of scope
- In:
- Out:

## Acceptance criteria
| # | Given | When | Then |
|---|---|---|---|
| AC-1 | | | |

## Independent test strategy
How this feature is built and tested ALONE: stubs/fakes for dependencies, mock data needed, which endpoints/pages prove it works.

## Surface hint (not a design)
- API: e.g. `POST /api/v1/<resource>`
- UI: e.g. page `<name>.html`
- AI: none | uses agent/workflow (needs /design-agent)

## Definition of done
- [ ] Acceptance criteria pass in automated tests
- [ ] Production API checklist items for this feature satisfied
- [ ] Review and test report written, test report says PASS

## Revision history
| Version | Date | Change | Reason / feedback |
|---|---|---|---|

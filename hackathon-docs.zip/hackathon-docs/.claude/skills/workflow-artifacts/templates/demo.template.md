# DEMO_SCRIPT.md (≈5 minutes)
| Time | Screen / action | What we say | Backup if it fails |
|---|---|---|---|
| 0:00 | Problem slide | | |
Golden-path data: which seeded records to use. Reset command before demo.

# PITCH_OUTLINE.md (slides)
1. Problem (with a number) 2. Who suffers (persona) 3. Solution 4. Live demo
5. How the AI works (architecture diagram, reliability: validation, fallbacks, human-in-loop)
6. Impact metrics 7. Tech depth (checklists we follow) 8. What's next 9. Team

# JUDGES_README.md
What it is, how to run (one command), demo credentials, architecture diagram, feature list mapped to judging criteria, known limitations.

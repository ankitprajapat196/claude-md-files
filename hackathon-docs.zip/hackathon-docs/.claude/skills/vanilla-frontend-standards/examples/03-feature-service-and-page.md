# Example 3 — Feature service + page controller (Controller-Service-DAO on the frontend)

Page controller owns state and events and renders the four states (loading, empty, error, success); the service maps intents to API calls; field errors from the server are shown next to inputs; version conflicts reload data.

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `static/js/services/task.service.js`

```javascript
/**
 * Feature service: maps UI intents to API calls. No DOM access here.
 * @module services/task.service
 */
import { apiClient } from '../core/api-client.js';
import { DEFAULT_PAGE_SIZE } from '../core/config.js';

export class TaskService {
  /** @param {import('../core/api-client.js').ApiClient} [client] */
  constructor(client = apiClient) {
    this.client = client;
  }

  /**
   * @param {{cursor?:string|null, status?:string, limit?:number}} [params]
   * @returns {Promise<{items:Array<object>, nextCursor:string|null, hasMore:boolean}>}
   */
  async list({ cursor = null, status, limit = DEFAULT_PAGE_SIZE } = {}) {
    const { data, meta } = await this.client.request('GET', '/tasks', {
      query: { limit, cursor: cursor || undefined, status },
    });
    return { items: data, nextCursor: meta.pagination.next_cursor, hasMore: meta.pagination.has_more };
  }

  /** @param {{title:string, description:string|null}} input */
  async create(input) {
    const { data } = await this.client.request('POST', '/tasks', { body: input });
    return data;
  }

  /**
   * @param {string} id
   * @param {number} version Version from the last read (sent as If-Match).
   * @param {object} changes
   */
  async update(id, version, changes) {
    const { data } = await this.client.request('PATCH', `/tasks/${encodeURIComponent(id)}`, {
      body: changes,
      ifMatch: `"${version}"`,
    });
    return data;
  }

  /** @param {string} id */
  async remove(id) {
    await this.client.request('DELETE', `/tasks/${encodeURIComponent(id)}`);
  }
}
```

## `static/js/pages/tasks.page.js`

```javascript
/**
 * Page controller: owns state, handles events, renders. Talks only to services.
 * Renders four states explicitly: loading, empty, error, success.
 * @module pages/tasks.page
 */
import { ApiError } from '../core/api-client.js';
import { clear, h, toast } from '../core/dom.js';
import { validateTaskCreate } from '../core/validators.js';
import { TaskService } from '../services/task.service.js';

const ERROR_MESSAGES = {
  UNAUTHENTICATED: 'Please sign in again.',
  VERSION_MISMATCH: 'This task changed elsewhere. Reloaded the latest version.',
  INVALID_STATUS_TRANSITION: 'That status change is not allowed.',
  NETWORK_ERROR: 'You appear to be offline.',
  TIMEOUT: 'The server is slow right now. Try again.',
};

export class TasksPage {
  /**
   * @param {HTMLElement} root
   * @param {TaskService} [service]
   */
  constructor(root, service = new TaskService()) {
    this.root = root;
    this.service = service;
    this.state = { items: [], loading: true, error: null, nextCursor: null, hasMore: false };
  }

  async init() {
    this.render();
    await this.load();
  }

  async load(cursor = null) {
    this.setState({ loading: true, error: null });
    try {
      const page = await this.service.list({ cursor });
      const items = cursor ? [...this.state.items, ...page.items] : page.items;
      this.setState({ items, nextCursor: page.nextCursor, hasMore: page.hasMore, loading: false });
    } catch (err) {
      this.setState({ loading: false, error: this.describe(err) });
    }
  }

  /** @param {SubmitEvent} event */
  async onCreate(event) {
    event.preventDefault();
    const form = /** @type {HTMLFormElement} */ (event.currentTarget);
    const { valid, errors, value } = validateTaskCreate(Object.fromEntries(new FormData(form)));
    this.showFieldErrors(form, errors);
    if (!valid) return;
    const submit = form.querySelector('button[type="submit"]');
    submit.disabled = true;
    try {
      const task = await this.service.create(value);
      form.reset();
      this.setState({ items: [task, ...this.state.items] });
      toast('Task created.', 'success');
    } catch (err) {
      if (err instanceof ApiError && err.fieldErrors.length) {
        this.showFieldErrors(form, Object.fromEntries(err.fieldErrors.map((e) => [e.field, e.message])));
      }
      toast(this.describe(err), 'error');
    } finally {
      submit.disabled = false;
    }
  }

  /** @param {object} task */
  async onAdvance(task) {
    const next = task.status === 'todo' ? 'in_progress' : 'done';
    try {
      const updated = await this.service.update(task.id, task.version, { status: next });
      this.setState({ items: this.state.items.map((t) => (t.id === updated.id ? updated : t)) });
    } catch (err) {
      toast(this.describe(err), 'error');
      if (err instanceof ApiError && err.code === 'VERSION_MISMATCH') await this.load();
    }
  }

  /** @param {unknown} err @returns {string} */
  describe(err) {
    if (err instanceof ApiError) {
      const base = ERROR_MESSAGES[err.code] || err.message;
      return err.requestId ? `${base} (ref: ${err.requestId})` : base;
    }
    return 'Something went wrong.';
  }

  /** @param {HTMLFormElement} form @param {Record<string,string>} errors */
  showFieldErrors(form, errors) {
    form.querySelectorAll('[data-error-for]').forEach((node) => {
      node.textContent = errors[node.dataset.errorFor] || '';
    });
  }

  /** @param {Partial<typeof this.state>} patch */
  setState(patch) {
    this.state = { ...this.state, ...patch };
    this.render();
  }

  render() {
    const { items, loading, error, hasMore, nextCursor } = this.state;
    clear(this.root);
    const form = h(
      'form',
      { class: 'card stack', novalidate: true, onSubmit: (e) => this.onCreate(e) },
      h('label', { for: 'title' }, 'Title'),
      h('input', { id: 'title', name: 'title', maxlength: 200, required: true, autocomplete: 'off' }),
      h('p', { class: 'field-error', 'data-error-for': 'title', 'aria-live': 'polite' }),
      h('label', { for: 'description' }, 'Description'),
      h('textarea', { id: 'description', name: 'description', maxlength: 2000, rows: 3 }),
      h('p', { class: 'field-error', 'data-error-for': 'description', 'aria-live': 'polite' }),
      h('button', { type: 'submit', class: 'btn btn--primary' }, 'Add task'),
    );
    let body;
    if (loading && items.length === 0) body = h('p', { class: 'muted', role: 'status' }, 'Loading…');
    else if (error) body = h('div', { class: 'card card--error', role: 'alert' }, error, ' ', h('button', { class: 'btn', onClick: () => this.load() }, 'Retry'));
    else if (items.length === 0) body = h('p', { class: 'muted' }, 'No tasks yet. Create your first one above.');
    else {
      body = h(
        'ul',
        { class: 'list' },
        items.map((task) =>
          h(
            'li',
            { class: 'list__item' },
            h('span', { class: 'list__title' }, task.title),
            h('span', { class: `badge badge--${task.status}` }, task.status.replace('_', ' ')),
            task.status !== 'done' && h('button', { class: 'btn', onClick: () => this.onAdvance(task) }, 'Advance'),
          ),
        ),
      );
    }
    this.root.append(
      form,
      body,
      hasMore && h('button', { class: 'btn', onClick: () => this.load(nextCursor), disabled: loading }, 'Load more'),
    );
  }
}

const root = document.getElementById('app');
if (root) new TasksPage(root).init();
```

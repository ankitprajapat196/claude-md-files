# Example 2 — API client (frontend DAO), safe DOM helpers, validators

One gateway for all HTTP: timeout via AbortController, bearer token, `X-Request-ID`, automatic `Idempotency-Key` on POST, `If-Match` support, parses `{data, meta}` and RFC 9457 errors into `ApiError` (UI branches on `code`). DOM helper `h()` builds elements with text nodes only (XSS-safe). Validators mirror the backend schema.

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `static/js/core/config.js`

```javascript
/**
 * Frontend runtime configuration. No secrets ever live in frontend code.
 * @module core/config
 */
export const API_BASE_URL = '/api/v1';
export const REQUEST_TIMEOUT_MS = 15000;
export const DEFAULT_PAGE_SIZE = 20;
```

## `static/js/core/api-client.js`

```javascript
/**
 * Single HTTP gateway (the frontend "DAO"). Every network call goes through here.
 * - Parses the success envelope {data, meta} and RFC 9457 problem+json errors.
 * - Applies a timeout, attaches auth, request id, Idempotency-Key and If-Match.
 * @module core/api-client
 */
import { API_BASE_URL, REQUEST_TIMEOUT_MS } from './config.js';

/** Error thrown for every failed call; UI branches on `code`, never on message text. */
export class ApiError extends Error {
  /**
   * @param {{status:number, code:string, detail:string, fieldErrors?:Array<{field:string,message:string}>, requestId?:string}} p
   */
  constructor({ status, code, detail, fieldErrors = [], requestId = '' }) {
    super(detail);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.fieldErrors = fieldErrors;
    this.requestId = requestId;
  }
}

/** Holds the bearer token in memory (+ sessionStorage so a reload keeps the session). */
export const authStore = {
  /** @returns {string|null} */
  get() {
    try { return sessionStorage.getItem('auth_token'); } catch { return null; }
  },
  /** @param {string} token */
  set(token) {
    try { sessionStorage.setItem('auth_token', token); } catch { /* storage unavailable */ }
  },
};

export class ApiClient {
  /**
   * @param {{baseUrl?:string, timeoutMs?:number, fetchImpl?:typeof fetch, tokenProvider?:() => (string|null)}} [options]
   */
  constructor({ baseUrl = API_BASE_URL, timeoutMs = REQUEST_TIMEOUT_MS, fetchImpl, tokenProvider } = {}) {
    this.baseUrl = baseUrl;
    this.timeoutMs = timeoutMs;
    this.fetchImpl = fetchImpl || ((...args) => fetch(...args));
    this.tokenProvider = tokenProvider || (() => authStore.get());
  }

  /**
   * Perform a request and return `{data, meta, headers}`.
   * @param {'GET'|'POST'|'PATCH'|'DELETE'} method
   * @param {string} path Path relative to the API base, e.g. `/tasks`.
   * @param {{body?:object, query?:Record<string,string|number|undefined>, ifMatch?:string, idempotent?:boolean}} [options]
   * @returns {Promise<{data:any, meta:any, headers:Headers}>}
   * @throws {ApiError}
   */
  async request(method, path, { body, query, ifMatch, idempotent = method === 'POST' } = {}) {
    const url = new URL(this.baseUrl + path, globalThis.location?.origin || 'http://localhost');
    Object.entries(query || {}).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v));
    });
    const headers = { Accept: 'application/json', 'X-Request-ID': crypto.randomUUID().replace(/-/g, '') };
    const token = this.tokenProvider();
    if (token) headers.Authorization = `Bearer ${token}`;
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (idempotent) headers['Idempotency-Key'] = crypto.randomUUID();
    if (ifMatch) headers['If-Match'] = ifMatch;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    let response;
    try {
      response = await this.fetchImpl(url.toString(), {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal,
      });
    } catch (err) {
      const timedOut = err && err.name === 'AbortError';
      throw new ApiError({
        status: 0,
        code: timedOut ? 'TIMEOUT' : 'NETWORK_ERROR',
        detail: timedOut ? 'The server took too long to respond.' : 'Cannot reach the server.',
      });
    } finally {
      clearTimeout(timer);
    }

    if (response.status === 204) return { data: null, meta: null, headers: response.headers };
    const contentType = response.headers.get('content-type') || '';
    const payload = contentType.includes('json') ? await response.json() : null;
    if (!response.ok) {
      throw new ApiError({
        status: response.status,
        code: payload?.code || `HTTP_${response.status}`,
        detail: payload?.detail || 'Request failed.',
        fieldErrors: payload?.errors || [],
        requestId: payload?.request_id || response.headers.get('X-Request-ID') || '',
      });
    }
    return { data: payload?.data ?? null, meta: payload?.meta ?? null, headers: response.headers };
  }
}

export const apiClient = new ApiClient();
```

## `static/js/core/dom.js`

```javascript
/**
 * Safe DOM helpers. Never assign untrusted strings to innerHTML.
 * @module core/dom
 */

/**
 * Create an element with attributes and children (strings become text nodes).
 * @param {string} tag
 * @param {Record<string, any>} [attrs]
 * @param {...(Node|string|number|null|undefined|false)} children
 * @returns {HTMLElement}
 */
export function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null || value === false) continue;
    if (key.startsWith('on') && typeof value === 'function') {
      el.addEventListener(key.slice(2).toLowerCase(), value);
    } else if (key === 'dataset') {
      Object.assign(el.dataset, value);
    } else {
      el.setAttribute(key, value === true ? '' : String(value));
    }
  }
  for (const child of children.flat()) {
    if (child === null || child === undefined || child === false) continue;
    el.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return el;
}

/** @param {Element} el */
export function clear(el) {
  el.replaceChildren();
}

/**
 * Show a transient, screen-reader friendly message.
 * @param {string} message
 * @param {'info'|'error'|'success'} [kind]
 */
export function toast(message, kind = 'info') {
  const region = document.getElementById('toast-region');
  if (!region) return;
  const item = h('div', { class: `toast toast--${kind}`, role: kind === 'error' ? 'alert' : 'status' }, message);
  region.append(item);
  setTimeout(() => item.remove(), 4000);
}
```

## `static/js/core/validators.js`

```javascript
/**
 * Client-side validation that MIRRORS the backend Pydantic schema.
 * The server stays the source of truth; this only gives faster feedback.
 * @module core/validators
 */

/**
 * @param {{title?:string, description?:string}} input
 * @returns {{valid:boolean, errors:Record<string,string>, value:{title:string, description:string|null}}}
 */
export function validateTaskCreate(input) {
  const errors = {};
  const title = (input.title || '').trim();
  const description = (input.description || '').trim();
  if (title.length < 1) errors.title = 'Title is required.';
  else if (title.length > 200) errors.title = 'Title must be at most 200 characters.';
  if (description.length > 2000) errors.description = 'Description must be at most 2000 characters.';
  return {
    valid: Object.keys(errors).length === 0,
    errors,
    value: { title, description: description || null },
  };
}
```

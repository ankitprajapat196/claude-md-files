# Example 1 — Page shell, CSP, design tokens

Semantic HTML shell with a strict CSP meta tag (no inline scripts), skip link, `aria-live` toast region; all colours/spacing as tokens with light/dark values; mobile-first CSS that only uses tokens.

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `templates/index.html`

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'" />
    <title>Tasks · CyberBulls</title>
    <link rel="stylesheet" href="/static/css/tokens.css" />
    <link rel="stylesheet" href="/static/css/app.css" />
    <script type="module" src="/static/js/pages/tasks.page.js"></script>
  </head>
  <body>
    <a class="skip-link" href="#app">Skip to content</a>
    <header class="topbar"><h1>Tasks</h1></header>
    <main id="app" class="container" tabindex="-1"></main>
    <div id="toast-region" class="toast-region" aria-live="polite"></div>
  </body>
</html>
```

## `static/css/tokens.css`

```css
/* Design tokens: the ONLY place raw colors, spacing and radii are defined. */
:root {
  color-scheme: light dark;
  --color-bg: #f7f7f9;
  --color-surface: #ffffff;
  --color-text: #1b1d23;
  --color-muted: #5d6270;
  --color-primary: #3346d3;
  --color-on-primary: #ffffff;
  --color-danger: #b42318;
  --color-success: #127a3e;
  --color-border: #dcdfe6;
  --space-1: 0.25rem;
  --space-2: 0.5rem;
  --space-3: 1rem;
  --space-4: 1.5rem;
  --radius: 0.5rem;
  --font: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
}
@media (prefers-color-scheme: dark) {
  :root {
    --color-bg: #121318;
    --color-surface: #1c1e26;
    --color-text: #eceef4;
    --color-muted: #a2a7b5;
    --color-primary: #8fa0ff;
    --color-on-primary: #0d1033;
    --color-danger: #ff8a80;
    --color-success: #6fdc9b;
    --color-border: #2e313c;
  }
}
```

## `static/css/app.css`

```css
/* Components use tokens only. Mobile-first; no fixed widths. */
* { box-sizing: border-box; }
body { margin: 0; font-family: var(--font); background: var(--color-bg); color: var(--color-text); }
.container { max-width: 48rem; margin: 0 auto; padding: var(--space-3); display: grid; gap: var(--space-3); }
.topbar { padding: var(--space-3); border-bottom: 1px solid var(--color-border); background: var(--color-surface); }
.topbar h1 { margin: 0; font-size: 1.25rem; }
.card { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); padding: var(--space-3); }
.card--error { border-color: var(--color-danger); color: var(--color-danger); }
.stack { display: grid; gap: var(--space-2); }
input, textarea { font: inherit; padding: var(--space-2); border: 1px solid var(--color-border); border-radius: var(--radius); background: var(--color-bg); color: inherit; }
.btn { font: inherit; padding: var(--space-2) var(--space-3); border-radius: var(--radius); border: 1px solid var(--color-border); background: var(--color-surface); color: inherit; cursor: pointer; }
.btn--primary { background: var(--color-primary); color: var(--color-on-primary); border-color: transparent; }
.btn:disabled { opacity: 0.6; cursor: not-allowed; }
.btn:focus-visible, input:focus-visible, textarea:focus-visible { outline: 3px solid var(--color-primary); outline-offset: 2px; }
.field-error { margin: 0; min-height: 1.2em; color: var(--color-danger); font-size: 0.875rem; }
.muted { color: var(--color-muted); }
.list { list-style: none; padding: 0; margin: 0; display: grid; gap: var(--space-2); }
.list__item { display: flex; gap: var(--space-2); align-items: center; padding: var(--space-2) var(--space-3); background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); }
.list__title { flex: 1; overflow-wrap: anywhere; }
.badge { font-size: 0.75rem; padding: var(--space-1) var(--space-2); border-radius: 999px; border: 1px solid var(--color-border); }
.badge--done { color: var(--color-success); }
.toast-region { position: fixed; inset: auto var(--space-3) var(--space-3) auto; display: grid; gap: var(--space-2); }
.toast { padding: var(--space-2) var(--space-3); border-radius: var(--radius); background: var(--color-surface); border: 1px solid var(--color-border); }
.toast--error { border-color: var(--color-danger); }
.toast--success { border-color: var(--color-success); }
.skip-link { position: absolute; left: -999px; }
.skip-link:focus { left: var(--space-3); top: var(--space-3); }
```

# Example 4 — Frontend unit tests with node:test (no framework)

Run with `node --test tests/frontend/` from the project root. The root `package.json` only sets `"type": "module"` (so the ES modules under `static/js/` load in Node).

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `package.json`

```json
{ "type": "module", "private": true }
```

## `tests/frontend/api-client.test.js`

```javascript
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ApiClient, ApiError } from '../../static/js/core/api-client.js';
import { validateTaskCreate } from '../../static/js/core/validators.js';

const json = (status, body, type = 'application/json') =>
  new Response(JSON.stringify(body), { status, headers: { 'content-type': type } });

test('parses success envelope and sends idempotency key on POST', async () => {
  let seen;
  const client = new ApiClient({
    fetchImpl: async (url, init) => { seen = init; return json(201, { data: { id: '1' }, meta: { request_id: 'r' } }); },
    tokenProvider: () => 'dev-alice',
  });
  const { data } = await client.request('POST', '/tasks', { body: { title: 'x' } });
  assert.equal(data.id, '1');
  assert.ok(seen.headers['Idempotency-Key']);
  assert.equal(seen.headers.Authorization, 'Bearer dev-alice');
});

test('maps problem+json to ApiError with field errors', async () => {
  const client = new ApiClient({
    fetchImpl: async () => json(422, { code: 'VALIDATION_FAILED', detail: 'bad', errors: [{ field: 'title', message: 'req' }], request_id: 'abc' }, 'application/problem+json'),
    tokenProvider: () => null,
  });
  await assert.rejects(client.request('GET', '/tasks'), (err) => {
    assert.ok(err instanceof ApiError);
    assert.equal(err.code, 'VALIDATION_FAILED');
    assert.equal(err.fieldErrors[0].field, 'title');
    assert.equal(err.requestId, 'abc');
    return true;
  });
});

test('timeout becomes TIMEOUT ApiError', async () => {
  const client = new ApiClient({
    timeoutMs: 10,
    fetchImpl: (url, init) => new Promise((_, reject) => init.signal.addEventListener('abort', () => reject(Object.assign(new Error('a'), { name: 'AbortError' })))),
    tokenProvider: () => null,
  });
  await assert.rejects(client.request('GET', '/tasks'), (err) => err.code === 'TIMEOUT');
});

test('validator mirrors backend limits', () => {
  assert.equal(validateTaskCreate({ title: '  ' }).valid, false);
  assert.equal(validateTaskCreate({ title: 'a'.repeat(201) }).errors.title !== undefined, true);
  assert.deepEqual(validateTaskCreate({ title: ' ok ' }).value, { title: 'ok', description: null });
});
```

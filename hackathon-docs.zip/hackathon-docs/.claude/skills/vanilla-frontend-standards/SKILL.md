---
name: vanilla-frontend-standards
description: Frontend rules for this project - plain HTML, CSS and ES-module JavaScript (no frameworks, no build step) served by FastAPI from `templates/` and `static/`, with page controller -> service -> API client layering, safe DOM rendering, design tokens, accessibility, and verified examples. Use whenever creating or changing any page, component, style, or client-side logic under templates/ or static/.
---

# Vanilla frontend standards

Examples (verified): `examples/01-shell-and-styles.md`, `examples/02-api-client-and-dom.md`, `examples/03-feature-service-and-page.md`, `examples/04-frontend-tests.md`.

## Structure (`templates/` + `static/`)
```text
templates/index.html                  # landing / main page (served at /)
templates/<area>/<page>.html          # one HTML file per screen, grouped in a folder per area, e.g. templates/dashboard/overview.html (served at /pages/dashboard/overview)
templates/<page>.html                 # standalone pages may sit directly in templates/ (served at /pages/<page>)
static/css/tokens.css                 # ONLY place for raw colours, spacing, radii (light + dark)
static/css/app.css                    # shared components using tokens
static/css/<feature>.css              # optional feature styles (tokens only)
static/js/core/config.js              # API base URL, timeouts (no secrets)
static/js/core/api-client.js          # the ONLY module that calls fetch()  (frontend "DAO")
static/js/core/dom.js                 # h(), clear(), toast()
static/js/core/validators.js          # mirrors backend Pydantic limits
static/js/services/<feature>.service.js   # intents -> API calls, no DOM
static/js/pages/<area>/<page>.page.js     # page controller: state, events, render (or static/js/pages/<feature>.page.js for flat pages)
static/images/                        # images
tests/frontend/<module>.test.js       # node --test tests/frontend/ (root package.json sets "type": "module")
```
HTML is plain files (no template engine). FastAPI serves `static/` at `/static` and the pages from `templates/` (see `app/main.py` in production-api-standards example 02), so the API is same-origin (no CORS needed). Pages reference assets with absolute `/static/...` URLs.

## Layering (mirrors the backend)
Page controller -> Service -> ApiClient -> backend. Pages never call `fetch`; services never touch the DOM; validators are pure functions.

## Rules (quality-gate hook enforces the starred ones)
- ★ No `innerHTML`/`outerHTML` with dynamic data, no `eval`/`new Function`/`document.write`; build DOM with `h()` and text nodes.
- ★ No inline `<script>` blocks or `onclick=` attributes (CSP `script-src 'self'`); use `type="module"` scripts and `addEventListener`.
- ★ `fetch()` only inside `static/js/core/api-client.js`.
- Raw colours only in `static/css/tokens.css`; everything else uses `var(--…)`.
- Every async view renders loading, empty, error (with retry), and success states.
- Show server field errors (`ApiError.fieldErrors`) next to inputs; show `request_id` in error toasts for support.
- Disable submit buttons while a request is in flight; POSTs get an `Idempotency-Key` automatically.
- Accessibility: labels for every input, visible focus, `role="alert"`/`aria-live` for messages, keyboard reachable controls, colour contrast ≥ 4.5:1, `lang` attribute.
- Responsive: mobile-first, flex/grid, no fixed widths, test at 360 px and 1280 px.
- JSDoc on every exported function/class (`@param`, `@returns`, `@throws`).
- Tokens: dev only, `sessionStorage`; never put API keys or the Anthropic key in frontend code.

## Demo polish (judges notice)
Clear empty states with a call to action, consistent spacing from tokens, one primary action per screen, fast perceived performance (optimistic UI where safe), readable error messages.

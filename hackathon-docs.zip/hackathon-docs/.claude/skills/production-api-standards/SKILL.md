---
name: production-api-standards
description: Production-ready REST API rules for this project (OWASP API Top 10, RFC 9457 problem+json, success envelope, idempotency keys, optimistic locking, cursor pagination, auth/BOLA, status codes, logging, health) with verified FastAPI example code. Use whenever designing, implementing, reviewing, or testing any HTTP endpoint, API contract, or feature plan API section.
---

# Production API standards

Full checklist (source of truth): `reference/production_api_checklist.md`. Verified examples: `examples/01-core-infrastructure.md`, `examples/02-resource-endpoint-end-to-end.md`, `examples/03-api-tests.md`.

## Contract every endpoint follows

**Success** (`application/json`):
```json
{"data": {"id": "…"}, "meta": {"request_id": "…", "timestamp": "2026-10-23T10:00:00Z", "pagination": {"limit": 20, "has_more": true, "next_cursor": "…"}}}
```
`pagination` only on lists. `data` is a response DTO or a list of them.

**Error** (`application/problem+json`, RFC 9457):
```json
{"type": "urn:cyberbulls:problem:validation_failed", "title": "Validation Failed", "status": 422,
 "detail": "One or more fields are invalid.", "instance": "/api/v1/tasks", "code": "VALIDATION_FAILED",
 "request_id": "…", "errors": [{"field": "title", "message": "String should have at least 1 character"}]}
```
Clients branch on `code`; `detail` is human text; no stack traces/SQL ever.

## Status codes
200 read/update · 201 create (+ `Location`, `ETag`) · 202 long async job (+ status URL) · 204 delete · 400 malformed · 401 unauthenticated (+ `WWW-Authenticate`) · 403 authenticated but not allowed (function-level) · 404 missing OR not owned (object-level, do not leak existence) · 409 conflict / idempotency key reuse · 412 stale `If-Match` · 415 wrong content type · 422 validation or business rule · 428 `If-Match` required · 429 rate limited (+ `Retry-After`) · 500 unexpected (generic message) · 503 dependency down (+ `Retry-After`).

## Mandatory per endpoint (map to checklist sections)
- URLs: `/api/v1/<plural-nouns>`, lowercase, no verbs; custom actions `POST /api/v1/orders/{id}:cancel`. (§1)
- Auth dependency on every non-public route; object-level owner/tenant check inside the DAO query; role check for admin functions. (§4-5)
- Request schema with limits and `extra="forbid"`; read-only fields (`id`, `owner_id`, `version`, `role`) never accepted. (§6)
- POST that creates side effects requires `Idempotency-Key` (8-128 chars); store key + request hash + response. (§7)
- Updates use `ETag`/`If-Match` optimistic locking. (§7)
- Lists: cursor pagination, default 20, max 100, filters as query params, stable sort. (§10)
- Bulk operations return per-item results (`succeeded` / `failed` with reasons). (§10)
- Outbound calls (LLM, third-party): timeout, transient-only retry with backoff + jitter, circuit breaker, validate responses as untrusted; SSRF allow-list for user URLs. (§9)
- Long work (> ~5 s, e.g. multi-step AI): `202 Accepted` + job resource `GET /api/v1/jobs/{id}`. (§7)
- Structured JSON log per request with `request_id`, method, path, status, latency; no secrets/PII. (§12)
- `/health/live` and `/health/ready` exist. (§12)
- OpenAPI summary on each route; FastAPI docs at `/docs`. (§17)

## Hackathon scope (what to skip, consciously)
Rate limiting, API gateway, HSTS, canary deploys, SAST/DAST, OpenTelemetry exporters: note them as "prod follow-up" in the implementation note instead of building them. Everything in "Mandatory per endpoint" is NOT optional.

## Review checklist (code-reviewer uses this)
Layering respected · envelope + problem+json · correct status codes · auth + BOLA · validation in/out · idempotency/locking where writes happen · pagination bounds · no internals leaked · logging with request id · tests for 401/404-other-user/422/409/412 paths.

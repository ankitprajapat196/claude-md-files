# Example 1 — Core infrastructure (build once, in the first feature)

Shared plumbing every endpoint relies on (`src/config.py` plus `src/core/*`). Checklist coverage: §2 edge (CORS allow-list, timeouts via server), §4 auth (`401` + `WWW-Authenticate`), §6 validation errors as field lists, §10 consistent envelope + request id, §11 RFC 9457 problem+json with stable `code` and no internals leaked, §12 structured JSON access log, §13 stateless settings from env.

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `src/config.py`

```python
"""Application configuration loaded from environment variables (12-factor).

The ONE place for model names, limits, and thresholds (project-root ``src/config.py``).
It is used by every layer (core, API, services, agents) through ``get_settings()``;
nothing else reads the environment.
"""

from functools import lru_cache

from pydantic import AliasChoices, Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Typed, validated application settings.

    Every value comes from an ``APP_``-prefixed environment variable or ``.env``.
    Secrets are never hard-coded and never logged.

    Attributes:
        app_name (str): Human readable service name used in logs and OpenAPI.
        environment (str): Deployment environment (``dev``, ``test``, ``prod``).
        database_url (str): SQLAlchemy async URL (PostgreSQL in prod, SQLite in tests).
        cors_origins (list[str]): Explicit allow-list of browser origins. Never ``*``.
        default_page_size (int): Page size used when the client does not send ``limit``.
        max_page_size (int): Hard upper bound for ``limit`` on every list endpoint.
        problem_type_base (str): URI prefix for RFC 9457 ``type`` values.
        templates_dir (str): Folder with the HTML pages served by the app.
        static_dir (str): Folder with CSS/JS/images mounted at ``/static``.
        log_dir (str): Folder for agent trace output (gitignored).
        anthropic_api_key (SecretStr): Claude API key (``ANTHROPIC_API_KEY``); never logged.
        llm_model_fast (str): Cheap tier for classify/route/extract (``LLM_MODEL_FAST``).
        llm_model_default (str): Tier for most steps (``LLM_MODEL_DEFAULT``).
        llm_model_deep (str): Tier for hard reasoning (``LLM_MODEL_DEEP``).
    """

    model_config = SettingsConfigDict(env_file=".env", env_prefix="APP_", extra="ignore")

    app_name: str = "cyberbulls-api"
    environment: str = "dev"
    database_url: str = "sqlite+aiosqlite:///./dev.db"
    cors_origins: list[str] = Field(default_factory=list)
    default_page_size: int = Field(default=20, ge=1, le=100)
    max_page_size: int = Field(default=100, ge=1, le=500)
    problem_type_base: str = "urn:cyberbulls:problem:"
    templates_dir: str = "templates"
    static_dir: str = "static"
    log_dir: str = "logs"
    anthropic_api_key: SecretStr = Field(
        default=SecretStr(""), validation_alias=AliasChoices("ANTHROPIC_API_KEY")
    )
    llm_model_fast: str = Field(
        default="claude-haiku-5-5", validation_alias=AliasChoices("LLM_MODEL_FAST")
    )
    llm_model_default: str = Field(
        default="claude-sonnet-5-5", validation_alias=AliasChoices("LLM_MODEL_DEFAULT")
    )
    llm_model_deep: str = Field(
        default="claude-opus-5-5", validation_alias=AliasChoices("LLM_MODEL_DEEP")
    )


@lru_cache
def get_settings() -> Settings:
    """Return the process-wide settings instance.

    The instance is created on first call and cached, so every caller shares it.

    Returns:
        settings (Settings): Cached ``Settings`` object.
    """
    return Settings()
```

## `src/core/errors.py`

```python
"""Typed application errors mapped to RFC 9457 Problem Details.

Services and DAOs raise these; only ``exception_handlers`` turns them into HTTP.
Clients branch on the stable ``code`` value, never on ``detail`` text. Every layer
that needs to signal an expected failure imports these classes.
"""

from typing import Any


class AppError(Exception):
    """Base class for every expected (handled) application error.

    Subclasses override ``status_code``, ``code`` and ``title``; an instance may
    override ``code`` and carries a client-safe ``detail``.

    Example:
        >>> error = AppError("Something broke.")
        >>> error.status_code, error.code
        (500, 'INTERNAL_ERROR')

    Attributes:
        status_code (int): HTTP status returned to the client.
        code (str): Stable machine-readable error code (UPPER_SNAKE_CASE).
        title (str): Short, human-readable summary of the error type.
        detail (str): Occurrence-specific explanation safe to show to clients.
        errors (list[dict[str, Any]]): Optional field-level errors
            ``[{"field": ..., "message": ...}]``.
        headers (dict[str, str]): Optional extra response headers (for example
            ``Retry-After``).
    """

    status_code: int = 500
    code: str = "INTERNAL_ERROR"
    title: str = "Internal Server Error"

    def __init__(
        self,
        detail: str,
        *,
        code: str | None = None,
        errors: list[dict[str, Any]] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Create an application error.

        Args:
            detail (str): Client-safe explanation of this occurrence.
            code (str | None): Optional override of the class-level error code.
            errors (list[dict[str, Any]] | None): Optional list of field-level
                validation errors.
            headers (dict[str, str] | None): Optional response headers to attach.

        Returns:
            None: The constructor returns nothing; it initializes the error.
        """
        super().__init__(detail)
        self.detail = detail
        if code:
            self.code = code
        self.errors = errors or []
        self.headers = headers or {}


class ValidationAppError(AppError):
    """Input is well-formed JSON but semantically invalid (422).

    Attributes:
        status_code (int): Fixed to 422.
        code (str): Stable error code ``VALIDATION_FAILED``.
        title (str): Summary ``Validation Failed``.
    """

    status_code = 422
    code = "VALIDATION_FAILED"
    title = "Validation Failed"


class UnauthorizedError(AppError):
    """Caller is not authenticated (401).

    Attributes:
        status_code (int): Fixed to 401.
        code (str): Stable error code ``UNAUTHENTICATED``.
        title (str): Summary ``Unauthorized``.
    """

    status_code = 401
    code = "UNAUTHENTICATED"
    title = "Unauthorized"


class PermissionDeniedError(AppError):
    """Caller is authenticated but not allowed (403).

    Attributes:
        status_code (int): Fixed to 403.
        code (str): Stable error code ``PERMISSION_DENIED``.
        title (str): Summary ``Forbidden``.
    """

    status_code = 403
    code = "PERMISSION_DENIED"
    title = "Forbidden"


class NotFoundError(AppError):
    """Resource does not exist or is not visible to the caller (404).

    Attributes:
        status_code (int): Fixed to 404.
        code (str): Stable error code ``RESOURCE_NOT_FOUND``.
        title (str): Summary ``Not Found``.
    """

    status_code = 404
    code = "RESOURCE_NOT_FOUND"
    title = "Not Found"


class ConflictError(AppError):
    """Request conflicts with current state, e.g. idempotency key reuse (409).

    Attributes:
        status_code (int): Fixed to 409.
        code (str): Stable error code ``CONFLICT``.
        title (str): Summary ``Conflict``.
    """

    status_code = 409
    code = "CONFLICT"
    title = "Conflict"


class PreconditionFailedError(AppError):
    """``If-Match`` version does not match the stored version (412).

    Attributes:
        status_code (int): Fixed to 412.
        code (str): Stable error code ``VERSION_MISMATCH``.
        title (str): Summary ``Precondition Failed``.
    """

    status_code = 412
    code = "VERSION_MISMATCH"
    title = "Precondition Failed"


class PreconditionRequiredError(AppError):
    """A conditional header such as ``If-Match`` is required (428).

    Attributes:
        status_code (int): Fixed to 428.
        code (str): Stable error code ``PRECONDITION_REQUIRED``.
        title (str): Summary ``Precondition Required``.
    """

    status_code = 428
    code = "PRECONDITION_REQUIRED"
    title = "Precondition Required"


class BusinessRuleError(AppError):
    """A domain rule rejected the operation (422).

    Attributes:
        status_code (int): Fixed to 422.
        code (str): Stable error code ``BUSINESS_RULE_VIOLATION``.
        title (str): Summary ``Business Rule Violation``.
    """

    status_code = 422
    code = "BUSINESS_RULE_VIOLATION"
    title = "Business Rule Violation"


class ExternalServiceError(AppError):
    """A dependency (LLM, third-party API) is unavailable (503).

    Attributes:
        status_code (int): Fixed to 503.
        code (str): Stable error code ``UPSTREAM_UNAVAILABLE``.
        title (str): Summary ``Service Unavailable``.
    """

    status_code = 503
    code = "UPSTREAM_UNAVAILABLE"
    title = "Service Unavailable"
```

## `src/core/responses.py`

```python
"""Consistent success envelope shared by every endpoint.

Success: ``{"data": ..., "meta": {"request_id", "timestamp", "pagination"?}}``.
Errors never use this envelope; they use ``application/problem+json``. Every router
and service-facing endpoint uses these models to wrap its result.

Attributes:
    T (TypeVar): Type variable for the payload carried in ``SuccessResponse.data``.
"""

from datetime import UTC, datetime
from typing import Generic, TypeVar

from fastapi import Request
from pydantic import BaseModel, Field

T = TypeVar("T")


class PageMeta(BaseModel):
    """Cursor pagination metadata.

    Attributes:
        limit (int): Page size that was applied.
        has_more (bool): Whether another page exists.
        next_cursor (str | None): Opaque cursor for the next page, ``None`` on the
            last page.
    """

    limit: int
    has_more: bool
    next_cursor: str | None = None


class ResponseMeta(BaseModel):
    """Metadata attached to every successful response.

    Attributes:
        request_id (str): Correlation id, identical to the ``X-Request-ID`` header.
        timestamp (datetime): Server time in UTC (ISO 8601).
        pagination (PageMeta | None): Present only on list endpoints.
    """

    request_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    pagination: PageMeta | None = None


class SuccessResponse(BaseModel, Generic[T]):
    """Generic success envelope.

    Attributes:
        data (T): The resource or list of resources.
        meta (ResponseMeta): Correlation and pagination metadata.
    """

    data: T
    meta: ResponseMeta


def build_meta(request: Request, pagination: PageMeta | None = None) -> ResponseMeta:
    """Build response metadata for the current request.

    Args:
        request (Request): Incoming request (carries ``state.request_id``).
        pagination (PageMeta | None): Optional pagination block for list endpoints.
            Defaults to ``None``.

    Returns:
        meta (ResponseMeta): Populated ``ResponseMeta``.
    """
    request_id = getattr(request.state, "request_id", "unknown")
    return ResponseMeta(request_id=request_id, pagination=pagination)
```

## `src/core/middleware.py`

```python
"""Request-id propagation and structured access logging.

This module is registered as middleware by the app factory and is used for every
HTTP request the service handles.
"""

import json
import logging
import re
import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger("src.access")
_VALID_REQUEST_ID = re.compile(r"^[A-Za-z0-9._-]{8,64}$")


class RequestIdMiddleware(BaseHTTPMiddleware):
    """Attach a correlation id to every request and log one JSON line per request.

    A valid incoming ``X-Request-ID`` is reused; otherwise a new id is generated.
    The id is exposed as ``request.state.request_id`` and echoed on the response.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        """Assign ``request.state.request_id``, call the app, and log the outcome.

        Args:
            request (Request): Incoming request.
            call_next (RequestResponseEndpoint): Next ASGI handler.

        Returns:
            response (Response): The downstream response with an ``X-Request-ID``
                header.

        Raises:
            Exception: Any exception raised by the downstream handler propagates.
        """
        incoming = request.headers.get("X-Request-ID", "")
        request_id = incoming if _VALID_REQUEST_ID.match(incoming) else uuid.uuid4().hex
        request.state.request_id = request_id
        started = time.perf_counter()
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        logger.info(
            json.dumps(
                {
                    "event": "http_request",
                    "request_id": request_id,
                    "method": request.method,
                    "path": request.url.path,
                    "status": response.status_code,
                    "latency_ms": round((time.perf_counter() - started) * 1000, 1),
                }
            )
        )
        return response
```

## `src/core/exception_handlers.py`

```python
"""Global exception handlers producing RFC 9457 ``application/problem+json``.

No stack traces, SQL, or internals ever reach the client; full detail is logged
server-side with the request id. The app factory calls ``register_exception_handlers``
once at startup.

Attributes:
    logger (logging.Logger): Logger ``src.errors`` for unexpected failures.
    PROBLEM_JSON (str): Media type ``application/problem+json`` for error responses.
"""

import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from src.config import get_settings
from src.core.errors import AppError

logger = logging.getLogger("src.errors")
PROBLEM_JSON = "application/problem+json"


def problem_response(
    request: Request,
    *,
    status: int,
    code: str,
    title: str,
    detail: str,
    errors: list[dict[str, Any]] | None = None,
    headers: dict[str, str] | None = None,
) -> JSONResponse:
    """Build a Problem Details response.

    Args:
        request (Request): Current request (for ``instance`` and ``request_id``).
        status (int): HTTP status code.
        code (str): Stable machine-readable error code.
        title (str): Short summary of the problem type.
        detail (str): Occurrence-specific, client-safe explanation.
        errors (list[dict[str, Any]] | None): Optional field-level error list.
        headers (dict[str, str] | None): Optional extra headers.

    Returns:
        response (JSONResponse): Response with media type ``application/problem+json``.
    """
    request_id = getattr(request.state, "request_id", "unknown")
    body: dict[str, Any] = {
        "type": f"{get_settings().problem_type_base}{code.lower()}",
        "title": title,
        "status": status,
        "detail": detail,
        "instance": request.url.path,
        "code": code,
        "request_id": request_id,
    }
    if errors:
        body["errors"] = errors
    merged = {"X-Request-ID": request_id, **(headers or {})}
    return JSONResponse(body, status_code=status, media_type=PROBLEM_JSON, headers=merged)


async def _handle_app_error(request: Request, exc: Exception) -> JSONResponse:
    assert isinstance(exc, AppError)
    return problem_response(
        request,
        status=exc.status_code,
        code=exc.code,
        title=exc.title,
        detail=exc.detail,
        errors=exc.errors,
        headers=exc.headers,
    )


async def _handle_validation(request: Request, exc: Exception) -> JSONResponse:
    assert isinstance(exc, RequestValidationError)
    field_errors = [
        {"field": ".".join(str(p) for p in err["loc"] if p != "body"), "message": err["msg"]}
        for err in exc.errors()
    ]
    return problem_response(
        request,
        status=422,
        code="VALIDATION_FAILED",
        title="Validation Failed",
        detail="One or more fields are invalid.",
        errors=field_errors,
    )


async def _handle_http(request: Request, exc: Exception) -> JSONResponse:
    assert isinstance(exc, StarletteHTTPException)
    return problem_response(
        request,
        status=exc.status_code,
        code=f"HTTP_{exc.status_code}",
        title=str(exc.detail),
        detail=str(exc.detail),
    )


async def _handle_unexpected(request: Request, exc: Exception) -> JSONResponse:
    logger.exception(
        "unhandled_error", extra={"request_id": getattr(request.state, "request_id", None)}
    )
    return problem_response(
        request,
        status=500,
        code="INTERNAL_ERROR",
        title="Internal Server Error",
        detail="An unexpected error occurred. Quote the request_id when reporting it.",
    )


def register_exception_handlers(app: FastAPI) -> None:
    """Register all global exception handlers on the app.

    Args:
        app (FastAPI): FastAPI application instance.

    Returns:
        None: Handlers are registered on ``app`` in place.
    """
    app.add_exception_handler(AppError, _handle_app_error)
    app.add_exception_handler(RequestValidationError, _handle_validation)
    app.add_exception_handler(StarletteHTTPException, _handle_http)
    app.add_exception_handler(Exception, _handle_unexpected)
```

## `src/core/database.py`

```python
"""Async SQLAlchemy engine, session factory, and declarative base.

This module is used by the DAO layer and the composition root for database access.
"""

from collections.abc import AsyncIterator
from functools import lru_cache

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from src.config import get_settings


class Base(DeclarativeBase):
    """Declarative base for every ORM model."""


@lru_cache
def get_engine() -> AsyncEngine:
    """Create the process-wide async engine with pooling and pre-ping.

    Returns:
        engine (AsyncEngine): Shared ``AsyncEngine``.
    """
    return create_async_engine(get_settings().database_url, pool_pre_ping=True)


@lru_cache
def get_sessionmaker() -> async_sessionmaker[AsyncSession]:
    """Return the session factory bound to the shared engine.

    Returns:
        factory (async_sessionmaker[AsyncSession]): ``async_sessionmaker`` producing
            ``AsyncSession`` objects.
    """
    return async_sessionmaker(get_engine(), expire_on_commit=False)


async def get_db_session() -> AsyncIterator[AsyncSession]:
    """FastAPI dependency yielding one session per request.

    Yields:
        session (AsyncSession): An ``AsyncSession`` closed automatically after the
            request.

    Raises:
        Exception: Errors raised while the session is in use propagate to the caller.
    """
    async with get_sessionmaker()() as session:
        yield session
```

## `src/core/pagination.py`

```python
"""Opaque cursor encoding for keyset (cursor) pagination.

This module is used by DAOs and services that implement list endpoints.
"""

import base64
import json
from datetime import datetime

from src.core.errors import ValidationAppError


def encode_cursor(created_at: datetime, item_id: str) -> str:
    """Encode a keyset position as an opaque cursor string.

    Args:
        created_at (datetime): Sort key of the last item on the page.
        item_id (str): Tie-breaker id of the last item on the page.

    Returns:
        cursor (str): URL-safe base64 cursor.

    Example:
        >>> from datetime import datetime
        >>> decode_cursor(encode_cursor(datetime(2024, 1, 1), "t1"))
        (datetime.datetime(2024, 1, 1, 0, 0), 't1')
    """
    raw = json.dumps({"c": created_at.isoformat(), "i": item_id}).encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def decode_cursor(cursor: str) -> tuple[datetime, str]:
    """Decode a cursor produced by ``encode_cursor``.

    Args:
        cursor (str): Opaque cursor from the client.

    Returns:
        position (tuple[datetime, str]): Tuple of ``(created_at, item_id)``.

    Raises:
        ValidationAppError: If the cursor is malformed.
    """
    try:
        padded = cursor + "=" * (-len(cursor) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded.encode()))
        return datetime.fromisoformat(payload["c"]), str(payload["i"])
    except (ValueError, KeyError, TypeError) as exc:
        raise ValidationAppError(
            "Invalid pagination cursor.", errors=[{"field": "cursor", "message": "malformed"}]
        ) from exc
```

## `src/core/security.py`

```python
"""Authentication dependency.

Hackathon mode accepts ``Authorization: Bearer dev-<user_id>`` only when
``APP_ENVIRONMENT`` is ``dev`` or ``test``. In prod replace ``_verify_token`` with
full JWT validation (signature, ``exp``, ``iss``, ``aud``, algorithm allow-list).
It is used as a FastAPI dependency by every non-public endpoint.
"""

import re
from typing import Annotated

from fastapi import Depends, Header
from pydantic import BaseModel

from src.config import Settings, get_settings
from src.core.errors import UnauthorizedError

_DEV_TOKEN = re.compile(r"^dev-([A-Za-z0-9_-]{1,64})$")


class CurrentUser(BaseModel):
    """Authenticated principal.

    Attributes:
        id (str): Stable user id used for object-level authorization.
        roles (list[str]): Role names used for function-level authorization.
    """

    id: str
    roles: list[str] = []


def _verify_token(token: str, settings: Settings) -> CurrentUser:
    """Validate a bearer token and return the principal.

    Args:
        token (str): Raw bearer token.
        settings (Settings): Application settings.

    Returns:
        user (CurrentUser): The authenticated user.

    Raises:
        UnauthorizedError: If the token is invalid for this environment.
    """
    match = _DEV_TOKEN.match(token)
    if settings.environment in {"dev", "test"} and match:
        return CurrentUser(id=match.group(1), roles=["user"])
    raise UnauthorizedError("Invalid or expired token.", headers={"WWW-Authenticate": "Bearer"})


async def get_current_user(
    settings: Annotated[Settings, Depends(get_settings)],
    authorization: Annotated[str | None, Header()] = None,
) -> CurrentUser:
    """FastAPI dependency that authenticates the caller.

    Args:
        settings (Settings): Injected settings.
        authorization (str | None): ``Authorization`` header value. Defaults to ``None``.

    Returns:
        user (CurrentUser): The authenticated user.

    Raises:
        UnauthorizedError: If the header is missing or malformed.
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise UnauthorizedError("Missing bearer token.", headers={"WWW-Authenticate": "Bearer"})
    return _verify_token(authorization.removeprefix("Bearer ").strip(), settings)
```

# Example 2 — One resource end to end (Schema -> Model -> DAO -> Service -> Provider -> Controller)

Shows: owner-scoped queries (BOLA-safe, other users get 404 not 403), `extra="forbid"` request schemas (no mass assignment), response DTO without internal fields, `Idempotency-Key` on POST (same key + same payload = stored replay, different payload = 409), optimistic locking with `ETag`/`If-Match` (428 when missing, 412 when stale), business-rule errors (422 with a specific code), keyset cursor pagination with a max page size, `201 + Location`, `204` on delete, health endpoints, static frontend mount.

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `src/models/task_model.py`

```python
"""ORM models for the ``tasks`` example resource.

Only the DAO layer imports these models; services and controllers work with
schemas from ``src/schemas.py`` instead.
"""

import uuid
from datetime import UTC, datetime

from sqlalchemy import DateTime, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from src.core.database import Base


def utcnow() -> datetime:
    """Return the current UTC time.

    Returns:
        now (datetime): Timezone-aware ``datetime`` in UTC.
    """
    return datetime.now(UTC)


class TaskModel(Base):
    """A task owned by exactly one user (tenant isolation by ``owner_id``).

    Every query on this table must be scoped by ``owner_id`` so one user can
    never read or change another user's task.

    Attributes:
        id (str): Primary key, a UUID string generated on insert.
        owner_id (str): Id of the owning user (tenant).
        title (str): Short task title.
        description (str | None): Optional longer text.
        status (str): Current status value; defaults to ``"todo"``.
        version (int): Optimistic-locking counter, starts at 1.
        created_at (datetime): Creation time (UTC).
        updated_at (datetime): Last update time (UTC).
    """

    __tablename__ = "tasks"
    __table_args__ = (Index("ix_tasks_owner_created_id", "owner_id", "created_at", "id"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    owner_id: Mapped[str] = mapped_column(String(64), index=True)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="todo", index=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class IdempotencyRecordModel(Base):
    """Stored response for an ``Idempotency-Key`` so retries never duplicate writes.

    The primary key is ``(owner_id, key)``, so keys are scoped per user and a
    concurrent duplicate insert fails with an integrity error.

    Attributes:
        owner_id (str): Id of the user that sent the key.
        key (str): Client-supplied ``Idempotency-Key``.
        request_hash (str): SHA-256 of the canonical request body.
        status_code (int): HTTP status returned for the original request.
        response_body (str): Serialized response ``data`` JSON.
        created_at (datetime): Time the record was stored (UTC).
    """

    __tablename__ = "idempotency_records"

    owner_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    key: Mapped[str] = mapped_column(String(128), primary_key=True)
    request_hash: Mapped[str] = mapped_column(String(64))
    status_code: Mapped[int] = mapped_column(Integer)
    response_body: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
```

## `src/schemas.py` (tasks section)

All Pydantic models live in this one file; each feature adds its own `# --- <feature> ---` section.

```python
"""All Pydantic models: API request/response DTOs and agent I/O.

Schemas validate input AND shape output. Rules: ``extra="forbid"`` on requests
(no mass assignment), read-only fields (``id``, ``version``, ``owner_id``) never
accepted from clients, and responses expose only what the client needs
(``owner_id`` is never returned). Controllers, services, and agents import these
models; the DAO layer works with ORM models instead.
"""

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, model_validator


class TaskStatus(StrEnum):
    """Allowed task states. ``done`` is terminal.

    Attributes:
        TODO (str): Not started, value ``"todo"``.
        IN_PROGRESS (str): Being worked on, value ``"in_progress"``.
        DONE (str): Finished and terminal, value ``"done"``.

    Example:
        >>> TaskStatus("done") is TaskStatus.DONE
        True
        >>> TaskStatus.IN_PROGRESS.value
        'in_progress'
    """

    TODO = "todo"
    IN_PROGRESS = "in_progress"
    DONE = "done"


class TaskCreateRequest(BaseModel):
    """Body of ``POST /tasks``.

    Attributes:
        title (str): Short task title, 1-200 characters after trimming.
        description (str | None): Optional longer text, at most 2000 characters.
    """

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    title: str = Field(min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=2000)


class TaskUpdateRequest(BaseModel):
    """Body of ``PATCH /tasks/{task_id}``; at least one field is required.

    Attributes:
        title (str | None): New title.
        description (str | None): New description.
        status (TaskStatus | None): New status; transitions are validated by the service.
    """

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    title: str | None = Field(default=None, min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=2000)
    status: TaskStatus | None = None

    @model_validator(mode="after")
    def _require_one_field(self) -> "TaskUpdateRequest":
        if not self.model_fields_set:
            raise ValueError("Provide at least one field to update.")
        return self


class TaskResponse(BaseModel):
    """Public representation of a task.

    Attributes:
        id (str): Task id (UUID).
        title (str): Task title.
        description (str | None): Optional description.
        status (TaskStatus): Current status.
        version (int): Optimistic-locking version, also sent as ``ETag``.
        created_at (datetime): Creation time (UTC).
        updated_at (datetime): Last update time (UTC).
    """

    model_config = ConfigDict(from_attributes=True)

    id: str
    title: str
    description: str | None
    status: TaskStatus
    version: int
    created_at: datetime
    updated_at: datetime
```

## `src/dao/task_dao.py`

```python
"""Data access for tasks. The DAO is the ONLY layer that touches SQLAlchemy.

This module is used by ``TaskService`` (wired in ``src/dependencies/providers.py``).
DAOs never commit and never raise HTTP errors: the service owns the
transaction and translates ``None``/``False`` results into domain errors.
Every query is scoped by ``owner_id`` (object-level authorization, BOLA-safe).
"""

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import and_, delete, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from src.models.task_model import IdempotencyRecordModel, TaskModel


class TaskDAO:
    """Persistence operations for ``TaskModel``.

    Every method is scoped by ``owner_id`` and never commits; the service owns
    the transaction.

    Attributes:
        _session (AsyncSession): Request-scoped async session.
    """

    def __init__(self, session: AsyncSession) -> None:
        """Bind the DAO to a session.

        Args:
            session (AsyncSession): Request-scoped async session.
        """
        self._session = session

    async def create(self, owner_id: str, title: str, description: str | None) -> TaskModel:
        """Insert a task.

        Args:
            owner_id (str): Owner (tenant) id.
            title (str): Validated title.
            description (str | None): Validated description.

        Returns:
            task (TaskModel): The persisted task (flushed, id assigned).
        """
        task = TaskModel(owner_id=owner_id, title=title, description=description)
        self._session.add(task)
        await self._session.flush()
        return task

    async def get_for_owner(self, task_id: str, owner_id: str) -> TaskModel | None:
        """Fetch one task visible to the owner.

        Args:
            task_id (str): Task id.
            owner_id (str): Owner id (enforced in the WHERE clause).

        Returns:
            task (TaskModel | None): The task, or ``None`` if missing or owned by
                someone else.
        """
        stmt = select(TaskModel).where(TaskModel.id == task_id, TaskModel.owner_id == owner_id)
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_for_owner(
        self,
        owner_id: str,
        *,
        limit: int,
        after: tuple[datetime, str] | None,
        status: str | None,
    ) -> list[TaskModel]:
        """List tasks newest-first with keyset pagination (fetches ``limit + 1``).

        Args:
            owner_id (str): Owner id.
            limit (int): Page size requested by the service.
            after (tuple[datetime, str] | None): ``(created_at, id)`` of the last item of
                the previous page.
            status (str | None): Optional status filter.

        Returns:
            tasks (list[TaskModel]): Up to ``limit + 1`` tasks; the extra row signals
                ``has_more``.
        """
        stmt = select(TaskModel).where(TaskModel.owner_id == owner_id)
        if status:
            stmt = stmt.where(TaskModel.status == status)
        if after:
            created_at, last_id = after
            stmt = stmt.where(
                or_(
                    TaskModel.created_at < created_at,
                    and_(TaskModel.created_at == created_at, TaskModel.id < last_id),
                )
            )
        stmt = stmt.order_by(TaskModel.created_at.desc(), TaskModel.id.desc()).limit(limit + 1)
        return list((await self._session.execute(stmt)).scalars().all())

    async def update_if_version(
        self, task_id: str, owner_id: str, expected_version: int, changes: dict[str, Any]
    ) -> TaskModel | None:
        """Conditionally update a task (optimistic locking).

        Args:
            task_id (str): Task id.
            owner_id (str): Owner id.
            expected_version (int): Version the client last saw.
            changes (dict[str, Any]): Column values to set.

        Returns:
            task (TaskModel | None): The updated task, or ``None`` if the version no
                longer matches.
        """
        stmt = (
            update(TaskModel)
            .where(
                TaskModel.id == task_id,
                TaskModel.owner_id == owner_id,
                TaskModel.version == expected_version,
            )
            .values(**changes, version=expected_version + 1, updated_at=datetime.now(UTC))
            .execution_options(synchronize_session=False)
        )
        result = await self._session.execute(stmt)
        if result.rowcount == 0:
            return None
        task = await self.get_for_owner(task_id, owner_id)
        if task is not None:
            await self._session.refresh(task)
        return task

    async def delete_for_owner(self, task_id: str, owner_id: str) -> bool:
        """Delete a task owned by the caller.

        Args:
            task_id (str): Task id.
            owner_id (str): Owner id.

        Returns:
            deleted (bool): ``True`` if a row was deleted.
        """
        stmt = delete(TaskModel).where(TaskModel.id == task_id, TaskModel.owner_id == owner_id)
        return (await self._session.execute(stmt)).rowcount > 0


class IdempotencyDAO:
    """Persistence for idempotency records.

    Like ``TaskDAO``, it never commits; the service owns the transaction.

    Attributes:
        _session (AsyncSession): Request-scoped async session.
    """

    def __init__(self, session: AsyncSession) -> None:
        """Bind the DAO to a session.

        Args:
            session (AsyncSession): Request-scoped async session.
        """
        self._session = session

    async def get(self, owner_id: str, key: str) -> IdempotencyRecordModel | None:
        """Fetch a stored idempotency record.

        Args:
            owner_id (str): Owner id (keys are scoped per user).
            key (str): Client-supplied ``Idempotency-Key``.

        Returns:
            record (IdempotencyRecordModel | None): The record or ``None``.
        """
        return await self._session.get(IdempotencyRecordModel, {"owner_id": owner_id, "key": key})

    async def save(
        self, owner_id: str, key: str, request_hash: str, status_code: int, body: str
    ) -> None:
        """Store the response for a key.

        Args:
            owner_id (str): Owner id.
            key (str): Idempotency key.
            request_hash (str): SHA-256 of the canonical request body.
            status_code (int): HTTP status that was returned.
            body (str): Serialized response ``data`` JSON.

        Returns:
            None: The record is added and flushed, not committed.
        """
        self._session.add(
            IdempotencyRecordModel(
                owner_id=owner_id,
                key=key,
                request_hash=request_hash,
                status_code=status_code,
                response_body=body,
            )
        )
        await self._session.flush()
```

## `src/services/task_service.py`

```python
"""Business logic for tasks: rules, transactions, idempotency, error translation.

Services never import FastAPI or SQLAlchemy query helpers; they receive DAOs,
own the transaction boundary, and raise typed ``AppError`` subclasses. This
module is used by the task controller through the provider in
``src/dependencies/providers.py``.

Attributes:
    logger (logging.Logger): Logger for task events (``src.services.task``).
    ALLOWED_TRANSITIONS (dict[TaskStatus, set[TaskStatus]]): Status transitions the
        service accepts, keyed by the current status.
"""

import hashlib
import logging

from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.errors import BusinessRuleError, ConflictError, NotFoundError, PreconditionFailedError
from src.core.pagination import decode_cursor, encode_cursor
from src.core.responses import PageMeta
from src.dao.task_dao import IdempotencyDAO, TaskDAO
from src.schemas import (
    TaskCreateRequest,
    TaskResponse,
    TaskStatus,
    TaskUpdateRequest,
)

logger = logging.getLogger("src.services.task")

ALLOWED_TRANSITIONS: dict[TaskStatus, set[TaskStatus]] = {
    TaskStatus.TODO: {TaskStatus.TODO, TaskStatus.IN_PROGRESS, TaskStatus.DONE},
    TaskStatus.IN_PROGRESS: {TaskStatus.IN_PROGRESS, TaskStatus.TODO, TaskStatus.DONE},
    TaskStatus.DONE: {TaskStatus.DONE},
}


class TaskService:
    """Use cases for the task resource.

    The service owns the transaction boundary, enforces business rules (status
    transitions, optimistic locking, idempotency), and translates DAO results
    into typed domain errors.

    Attributes:
        _session (AsyncSession): Session used only for the transaction boundary.
        _tasks (TaskDAO): Task DAO.
        _idempotency (IdempotencyDAO): Idempotency DAO.
    """

    def __init__(self, session: AsyncSession, tasks: TaskDAO, idempotency: IdempotencyDAO) -> None:
        """Wire the service with its collaborators.

        Args:
            session (AsyncSession): Session used only for the transaction boundary.
            tasks (TaskDAO): Task DAO.
            idempotency (IdempotencyDAO): Idempotency DAO.
        """
        self._session = session
        self._tasks = tasks
        self._idempotency = idempotency

    async def create_task(
        self, owner_id: str, payload: TaskCreateRequest, idempotency_key: str
    ) -> tuple[TaskResponse, bool]:
        """Create a task exactly once per ``Idempotency-Key``.

        Args:
            owner_id (str): Authenticated user id.
            payload (TaskCreateRequest): Validated request body.
            idempotency_key (str): Client-generated key for safe retries.

        Returns:
            result (tuple[TaskResponse, bool]): Tuple of ``(task, replayed)``;
                ``replayed`` is True for a stored replay.

        Raises:
            ConflictError: Same key reused with a different payload, or a concurrent
                request with the same key is still in flight.
        """
        request_hash = hashlib.sha256(payload.model_dump_json().encode()).hexdigest()
        try:
            async with self._session.begin():
                existing = await self._idempotency.get(owner_id, idempotency_key)
                if existing is not None:
                    if existing.request_hash != request_hash:
                        raise ConflictError(
                            "Idempotency-Key was already used with a different payload.",
                            code="IDEMPOTENCY_KEY_REUSED",
                        )
                    return TaskResponse.model_validate_json(existing.response_body), True
                task = await self._tasks.create(owner_id, payload.title, payload.description)
                response = TaskResponse.model_validate(task)
                await self._idempotency.save(
                    owner_id, idempotency_key, request_hash, 201, response.model_dump_json()
                )
        except IntegrityError as exc:
            raise ConflictError(
                "A request with this Idempotency-Key is in progress. Retry shortly.",
                code="IDEMPOTENCY_IN_PROGRESS",
                headers={"Retry-After": "1"},
            ) from exc
        logger.info("task_created", extra={"task_id": response.id, "owner_id": owner_id})
        return response, False

    async def get_task(self, owner_id: str, task_id: str) -> TaskResponse:
        """Return one task owned by the caller.

        Args:
            owner_id (str): Authenticated user id.
            task_id (str): Task id.

        Returns:
            task (TaskResponse): The task.

        Raises:
            NotFoundError: If missing or owned by another user (no existence leak).
        """
        task = await self._tasks.get_for_owner(task_id, owner_id)
        if task is None:
            raise NotFoundError(f"Task '{task_id}' was not found.")
        return TaskResponse.model_validate(task)

    async def list_tasks(
        self, owner_id: str, *, limit: int, cursor: str | None, status: TaskStatus | None
    ) -> tuple[list[TaskResponse], PageMeta]:
        """List the caller's tasks with cursor pagination.

        Args:
            owner_id (str): Authenticated user id.
            limit (int): Page size (already bounded by the controller).
            cursor (str | None): Opaque cursor from the previous page.
            status (TaskStatus | None): Optional status filter.

        Returns:
            result (tuple[list[TaskResponse], PageMeta]): Tuple of
                ``(tasks, page_meta)``.

        Raises:
            ValidationAppError: If the cursor is malformed.
        """
        after = decode_cursor(cursor) if cursor else None
        rows = await self._tasks.list_for_owner(
            owner_id, limit=limit, after=after, status=status.value if status else None
        )
        has_more = len(rows) > limit
        page = rows[:limit]
        next_cursor = encode_cursor(page[-1].created_at, page[-1].id) if has_more and page else None
        items = [TaskResponse.model_validate(row) for row in page]
        return items, PageMeta(limit=limit, has_more=has_more, next_cursor=next_cursor)

    async def update_task(
        self, owner_id: str, task_id: str, payload: TaskUpdateRequest, expected_version: int
    ) -> TaskResponse:
        """Apply a partial update guarded by optimistic locking.

        Args:
            owner_id (str): Authenticated user id.
            task_id (str): Task id.
            payload (TaskUpdateRequest): Validated partial update.
            expected_version (int): Version from the ``If-Match`` header.

        Returns:
            task (TaskResponse): The updated task.

        Raises:
            NotFoundError: If the task is not visible to the caller.
            PreconditionFailedError: If the version changed since the client read it.
            BusinessRuleError: If the status transition is not allowed.
        """
        async with self._session.begin():
            current = await self._tasks.get_for_owner(task_id, owner_id)
            if current is None:
                raise NotFoundError(f"Task '{task_id}' was not found.")
            if current.version != expected_version:
                raise PreconditionFailedError(
                    f"Task changed (current version {current.version}). Reload and retry."
                )
            changes = payload.model_dump(exclude_unset=True)
            if "status" in changes:
                new_status = TaskStatus(changes["status"])
                if new_status not in ALLOWED_TRANSITIONS[TaskStatus(current.status)]:
                    raise BusinessRuleError(
                        f"Cannot move a task from '{current.status}' to '{new_status.value}'.",
                        code="INVALID_STATUS_TRANSITION",
                    )
                changes["status"] = new_status.value
            updated = await self._tasks.update_if_version(
                task_id, owner_id, expected_version, changes
            )
            if updated is None:
                raise PreconditionFailedError("Task was modified concurrently. Reload and retry.")
            return TaskResponse.model_validate(updated)

    async def delete_task(self, owner_id: str, task_id: str) -> None:
        """Delete a task owned by the caller.

        Args:
            owner_id (str): Authenticated user id.
            task_id (str): Task id.

        Returns:
            None: The task is deleted within the transaction.

        Raises:
            NotFoundError: If the task is not visible to the caller.
        """
        async with self._session.begin():
            if not await self._tasks.delete_for_owner(task_id, owner_id):
                raise NotFoundError(f"Task '{task_id}' was not found.")
```

## `src/dependencies/providers.py`

```python
"""Composition root: wires sessions -> DAOs -> services for FastAPI ``Depends``.

This is the ONLY place that knows how layers are assembled, which keeps
controllers free of DAO/SQLAlchemy imports and services free of FastAPI.
Controllers import the provider functions defined here and never build services
themselves.
"""

from typing import Annotated

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.database import get_db_session
from src.dao.task_dao import IdempotencyDAO, TaskDAO
from src.services.task_service import TaskService


def get_task_service(session: Annotated[AsyncSession, Depends(get_db_session)]) -> TaskService:
    """Assemble a ``TaskService`` for the current request.

    Args:
        session (AsyncSession): Request-scoped session, injected via ``Depends``.

    Returns:
        service (TaskService): A ready ``TaskService``.
    """
    return TaskService(session, TaskDAO(session), IdempotencyDAO(session))
```

## `src/api/v1/controllers/task_controller.py`

```python
"""HTTP controller for tasks: parse + authenticate + call service + wrap response.

Controllers contain NO business logic and NO database access. Each handler is
a thin adapter: validated input in, ``SuccessResponse`` out. It is used by the
version 1 router, which includes ``router`` under ``/api/v1``.

Attributes:
    router (APIRouter): Router for ``/tasks`` endpoints.
    ServiceDep (type): Annotated dependency that injects the ``TaskService``.
    UserDep (type): Annotated dependency that injects the authenticated user.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, Header, Query, Request, Response, status

from src.config import Settings, get_settings
from src.core.errors import PreconditionRequiredError, ValidationAppError
from src.core.responses import SuccessResponse, build_meta
from src.core.security import CurrentUser, get_current_user
from src.dependencies.providers import get_task_service
from src.schemas import TaskCreateRequest, TaskResponse, TaskStatus, TaskUpdateRequest
from src.services.task_service import TaskService

router = APIRouter(prefix="/tasks", tags=["tasks"])


ServiceDep = Annotated[TaskService, Depends(get_task_service)]
UserDep = Annotated[CurrentUser, Depends(get_current_user)]


def _parse_if_match(if_match: str | None) -> int:
    """Turn an ``If-Match: "3"`` header into an integer version.

    Args:
        if_match (str | None): Raw header value.

    Returns:
        version (int): Expected version.

    Raises:
        PreconditionRequiredError: If the header is missing.
        ValidationAppError: If the header is not a quoted integer.
    """
    if not if_match:
        raise PreconditionRequiredError("If-Match header with the task version is required.")
    try:
        return int(if_match.strip().removeprefix("W/").strip('"'))
    except ValueError as exc:
        raise ValidationAppError(
            "If-Match must be a quoted version number.",
            errors=[{"field": "If-Match", "message": 'expected e.g. "3"'}],
        ) from exc


@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
    response_model=SuccessResponse[TaskResponse],
    summary="Create a task (idempotent with Idempotency-Key)",
)
async def create_task(
    payload: TaskCreateRequest,
    request: Request,
    response: Response,
    user: UserDep,
    service: ServiceDep,
    idempotency_key: Annotated[str, Header(alias="Idempotency-Key", min_length=8, max_length=128)],
) -> SuccessResponse[TaskResponse]:
    """Create a task for the authenticated user.

    Sets the ``Location`` and ``ETag`` headers, and ``Idempotent-Replayed`` when
    the stored response of an earlier identical request is returned.

    Args:
        payload (TaskCreateRequest): Validated body.
        request (Request): Current request.
        response (Response): Response used to set headers.
        user (CurrentUser): Authenticated user, injected via ``Depends``.
        service (TaskService): Task service, injected via ``Depends``.
        idempotency_key (str): Required client key for safe retries, from the
            ``Idempotency-Key`` header (8-128 characters).

    Returns:
        envelope (SuccessResponse[TaskResponse]): Envelope containing the created (or
            replayed) task.

    Raises:
        ConflictError: If the key was reused with a different payload, or a request
            with the same key is still in flight.
    """
    task, replayed = await service.create_task(user.id, payload, idempotency_key)
    response.headers["Location"] = f"/api/v1/tasks/{task.id}"
    response.headers["ETag"] = f'"{task.version}"'
    if replayed:
        response.headers["Idempotent-Replayed"] = "true"
    return SuccessResponse(data=task, meta=build_meta(request))


@router.get("", response_model=SuccessResponse[list[TaskResponse]], summary="List my tasks")
async def list_tasks(
    request: Request,
    user: UserDep,
    service: ServiceDep,
    settings: Annotated[Settings, Depends(get_settings)],
    limit: Annotated[int | None, Query(ge=1, le=100)] = None,
    cursor: Annotated[str | None, Query(max_length=512)] = None,
    task_status: Annotated[TaskStatus | None, Query(alias="status")] = None,
) -> SuccessResponse[list[TaskResponse]]:
    """List the caller's tasks, newest first, with cursor pagination.

    Args:
        request (Request): Current request.
        user (CurrentUser): Authenticated user, injected via ``Depends``.
        service (TaskService): Task service, injected via ``Depends``.
        settings (Settings): App settings (page-size bounds), injected via ``Depends``.
        limit (int | None): Page size (bounded by ``max_page_size``), from the query
            string (1-100).
        cursor (str | None): Opaque cursor from ``meta.pagination.next_cursor``, from
            the query string.
        task_status (TaskStatus | None): Optional status filter, from the ``status``
            query parameter.

    Returns:
        envelope (SuccessResponse[list[TaskResponse]]): Envelope with the page of tasks
            and pagination metadata.

    Raises:
        ValidationAppError: If the cursor is malformed.
    """
    page_size = min(limit or settings.default_page_size, settings.max_page_size)
    items, page = await service.list_tasks(
        user.id, limit=page_size, cursor=cursor, status=task_status
    )
    return SuccessResponse(data=items, meta=build_meta(request, page))


@router.get("/{task_id}", response_model=SuccessResponse[TaskResponse], summary="Get one task")
async def get_task(
    task_id: str, request: Request, response: Response, user: UserDep, service: ServiceDep
) -> SuccessResponse[TaskResponse]:
    """Return one task owned by the caller.

    Args:
        task_id (str): Task id, from the path.
        request (Request): Current request.
        response (Response): Response used to set ``ETag``.
        user (CurrentUser): Authenticated user, injected via ``Depends``.
        service (TaskService): Task service, injected via ``Depends``.

    Returns:
        envelope (SuccessResponse[TaskResponse]): Envelope with the task.

    Raises:
        NotFoundError: If the task is missing or owned by another user.
    """
    task = await service.get_task(user.id, task_id)
    response.headers["ETag"] = f'"{task.version}"'
    return SuccessResponse(data=task, meta=build_meta(request))


@router.patch(
    "/{task_id}", response_model=SuccessResponse[TaskResponse], summary="Update a task (If-Match)"
)
async def update_task(
    task_id: str,
    payload: TaskUpdateRequest,
    request: Request,
    response: Response,
    user: UserDep,
    service: ServiceDep,
    if_match: Annotated[str | None, Header(alias="If-Match")] = None,
) -> SuccessResponse[TaskResponse]:
    """Partially update a task with optimistic locking.

    Args:
        task_id (str): Task id, from the path.
        payload (TaskUpdateRequest): Validated partial update.
        request (Request): Current request.
        response (Response): Response used to set ``ETag``.
        user (CurrentUser): Authenticated user, injected via ``Depends``.
        service (TaskService): Task service, injected via ``Depends``.
        if_match (str | None): Version the client last read, e.g. ``"3"``, from the
            ``If-Match`` header.

    Returns:
        envelope (SuccessResponse[TaskResponse]): Envelope with the updated task.

    Raises:
        PreconditionRequiredError: If the ``If-Match`` header is missing.
        ValidationAppError: If ``If-Match`` is not a quoted integer.
        NotFoundError: If the task is not visible to the caller.
        PreconditionFailedError: If the version changed since the client read it.
        BusinessRuleError: If the status transition is not allowed.
    """
    task = await service.update_task(user.id, task_id, payload, _parse_if_match(if_match))
    response.headers["ETag"] = f'"{task.version}"'
    return SuccessResponse(data=task, meta=build_meta(request))


@router.delete("/{task_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete a task")
async def delete_task(task_id: str, user: UserDep, service: ServiceDep) -> Response:
    """Delete a task owned by the caller.

    Args:
        task_id (str): Task id, from the path.
        user (CurrentUser): Authenticated user, injected via ``Depends``.
        service (TaskService): Task service, injected via ``Depends``.

    Returns:
        response (Response): Empty 204 response.

    Raises:
        NotFoundError: If the task is not visible to the caller.
    """
    await service.delete_task(user.id, task_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
```

## `src/api/v1/router.py`

```python
"""Version 1 API router: include every feature controller here.

The application factory in ``app/main.py`` includes ``api_router`` once.

Attributes:
    api_router (APIRouter): Router mounted at ``/api/v1`` that aggregates all
        feature routers.
"""

from fastapi import APIRouter

from src.api.v1.controllers import task_controller

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(task_controller.router)
```

## `app/main.py`

```python
"""Application factory: middleware, error handlers, routers, health, static files, pages.

This is the demo layer entry point; uvicorn serves ``app.main:app``. It imports
from ``src`` and is never imported by it.

Attributes:
    app (FastAPI): The application instance built by ``create_app``.
"""

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text

from src.api.v1.router import api_router
from src.config import get_settings
from src.core.database import Base, get_engine
from src.core.exception_handlers import register_exception_handlers
from src.core.middleware import RequestIdMiddleware

logging.basicConfig(level=logging.INFO, format="%(message)s")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Create tables in dev/test only; production uses Alembic migrations.

    Args:
        app (FastAPI): The application.

    Yields:
        Control to the running application.
    """
    if get_settings().environment in {"dev", "test"}:
        async with get_engine().begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    yield
    await get_engine().dispose()


def create_app() -> FastAPI:
    """Build the FastAPI application.

    Returns:
        app (FastAPI): Configured application instance.
    """
    settings = get_settings()
    app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)
    app.add_middleware(RequestIdMiddleware)
    if settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.cors_origins,
            allow_methods=["GET", "POST", "PATCH", "DELETE"],
            allow_headers=["Authorization", "Content-Type", "Idempotency-Key", "If-Match"],
            expose_headers=["X-Request-ID", "ETag", "Location"],
        )
    register_exception_handlers(app)
    app.include_router(api_router)

    @app.get("/health/live", include_in_schema=False)
    async def live() -> dict[str, str]:
        """Liveness: the process is up.

        Returns:
            body (dict[str, str]): ``{"status": "ok"}``.
        """
        return {"status": "ok"}

    @app.get("/health/ready", include_in_schema=False)
    async def ready() -> JSONResponse:
        """Readiness: dependencies (database) are reachable.

        Returns:
            response (JSONResponse): ``{"status": "ok"}`` with 200, or
                ``{"status": "unavailable"}`` with 503 if the database cannot be reached.
        """
        try:
            async with get_engine().connect() as conn:
                await conn.execute(text("SELECT 1"))
        except Exception:  # noqa: BLE001 - readiness must never raise
            return JSONResponse({"status": "unavailable"}, status_code=503)
        return JSONResponse({"status": "ok"})

    static_dir = Path(settings.static_dir)
    if static_dir.is_dir():
        app.mount("/static", StaticFiles(directory=static_dir), name="static")
    templates_dir = Path(settings.templates_dir)

    @app.get("/", include_in_schema=False)
    async def index() -> FileResponse:
        """Serve the landing page (plain HTML, no template engine).

        Returns:
            response (FileResponse): The ``index.html`` file from ``templates/``.
        """
        return FileResponse(templates_dir / "index.html")

    @app.get("/pages/{page:path}", include_in_schema=False)
    async def page(page: str) -> FileResponse:
        """Serve one HTML page, e.g. ``dashboard/overview``; resolved inside ``templates/`` only.

        Args:
            page (str): Page path without the ``.html`` suffix, from the URL.

        Returns:
            response (FileResponse): The matching HTML file.

        Raises:
            HTTPException: 404 if the file is outside ``templates/`` or does not exist.
        """
        target = (templates_dir / f"{page}.html").resolve()
        if not target.is_relative_to(templates_dir.resolve()) or not target.is_file():
            raise HTTPException(status_code=404)
        return FileResponse(target)
    return app


app = create_app()
```

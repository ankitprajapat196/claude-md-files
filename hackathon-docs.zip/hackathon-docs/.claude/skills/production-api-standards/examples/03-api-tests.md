# Example 3 — API tests (happy AND failure paths)

Isolated in-memory DB per test via dependency override; asserts envelope, headers, problem+json codes, BOLA (404 for another user's object), idempotent replay, pagination walk, 428/412 locking, business-rule 422.

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `tests/conftest.py`

```python
"""Shared fixtures: isolated in-memory DB per test and an authenticated client.

This module is loaded automatically by pytest; the fixtures and the ``auth`` helper
are used by every API test.
"""

import os
from collections.abc import AsyncIterator

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import StaticPool

os.environ.setdefault("APP_ENVIRONMENT", "test")

from src.core.database import Base, get_db_session
from app.main import create_app


@pytest.fixture
async def client() -> AsyncIterator[AsyncClient]:
    """HTTP client against the app with a fresh in-memory database.

    Yields:
        http (AsyncClient): ``httpx.AsyncClient`` bound to the ASGI app.

    Raises:
        Exception: Setup errors (engine, schema creation) propagate to pytest.
    """
    engine = create_async_engine(
        "sqlite+aiosqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    factory = async_sessionmaker(engine, expire_on_commit=False)

    async def override_session() -> AsyncIterator[AsyncSession]:
        async with factory() as session:
            yield session

    app = create_app()
    app.dependency_overrides[get_db_session] = override_session
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as http:
        yield http
    await engine.dispose()


def auth(user: str = "alice") -> dict[str, str]:
    """Build an Authorization header for a dev user.

    Args:
        user (str): Dev user id. Defaults to ``"alice"``.

    Returns:
        headers (dict[str, str]): Header dict.

    Example:
        >>> auth("bob")
        {'Authorization': 'Bearer dev-bob'}
    """
    return {"Authorization": f"Bearer dev-{user}"}
```

## `tests/integration/test_task_api.py`

```python
"""Contract tests for the tasks API: happy paths AND failure paths.

This module is run by pytest as part of the integration suite.

Attributes:
    PROBLEM (str): Media type ``application/problem+json`` expected on error responses.
"""

from httpx import AsyncClient

from tests.conftest import auth

PROBLEM = "application/problem+json"


async def _create(client: AsyncClient, title: str, key: str, user: str = "alice") -> dict:
    res = await client.post(
        "/api/v1/tasks", json={"title": title}, headers={**auth(user), "Idempotency-Key": key}
    )
    assert res.status_code in (200, 201), res.text
    return res.json()


async def test_create_returns_envelope_location_and_etag(client: AsyncClient) -> None:
    res = await client.post(
        "/api/v1/tasks",
        json={"title": "  Write PRD  "},
        headers={**auth(), "Idempotency-Key": "key-0001"},
    )
    assert res.status_code == 201
    body = res.json()
    assert body["data"]["title"] == "Write PRD"
    assert body["data"]["status"] == "todo"
    assert "owner_id" not in body["data"]
    assert body["meta"]["request_id"] == res.headers["X-Request-ID"]
    assert res.headers["Location"] == f"/api/v1/tasks/{body['data']['id']}"
    assert res.headers["ETag"] == '"1"'


async def test_idempotent_replay_and_key_reuse(client: AsyncClient) -> None:
    first = await _create(client, "A", "key-0002")
    replay = await client.post(
        "/api/v1/tasks", json={"title": "A"}, headers={**auth(), "Idempotency-Key": "key-0002"}
    )
    assert replay.headers.get("Idempotent-Replayed") == "true"
    assert replay.json()["data"]["id"] == first["data"]["id"]
    reuse = await client.post(
        "/api/v1/tasks", json={"title": "B"}, headers={**auth(), "Idempotency-Key": "key-0002"}
    )
    assert reuse.status_code == 409
    assert reuse.headers["content-type"].startswith(PROBLEM)
    assert reuse.json()["code"] == "IDEMPOTENCY_KEY_REUSED"


async def test_validation_errors_are_problem_json_with_fields(client: AsyncClient) -> None:
    res = await client.post(
        "/api/v1/tasks",
        json={"title": "", "owner_id": "mallory"},
        headers={**auth(), "Idempotency-Key": "key-0003"},
    )
    assert res.status_code == 422
    body = res.json()
    assert body["code"] == "VALIDATION_FAILED"
    fields = {e["field"] for e in body["errors"]}
    assert {"title", "owner_id"} <= fields


async def test_missing_auth_is_401(client: AsyncClient) -> None:
    res = await client.get("/api/v1/tasks")
    assert res.status_code == 401
    assert res.json()["code"] == "UNAUTHENTICATED"
    assert res.headers["WWW-Authenticate"] == "Bearer"


async def test_other_users_task_is_404_not_403(client: AsyncClient) -> None:
    task = await _create(client, "secret", "key-0004", user="alice")
    res = await client.get(f"/api/v1/tasks/{task['data']['id']}", headers=auth("bob"))
    assert res.status_code == 404
    assert res.json()["code"] == "RESOURCE_NOT_FOUND"


async def test_cursor_pagination_walks_all_pages(client: AsyncClient) -> None:
    for i in range(5):
        await _create(client, f"t{i}", f"key-page-{i:03d}")
    seen: list[str] = []
    cursor = None
    while True:
        params = {"limit": 2, **({"cursor": cursor} if cursor else {})}
        res = await client.get("/api/v1/tasks", params=params, headers=auth())
        page = res.json()
        seen += [t["id"] for t in page["data"]]
        cursor = page["meta"]["pagination"]["next_cursor"]
        if not page["meta"]["pagination"]["has_more"]:
            break
    assert len(seen) == 5 and len(set(seen)) == 5
    bad = await client.get("/api/v1/tasks", params={"cursor": "%%%"}, headers=auth())
    assert bad.status_code == 422


async def test_patch_requires_if_match_and_rejects_stale_version(client: AsyncClient) -> None:
    task = await _create(client, "lock me", "key-0005")
    url = f"/api/v1/tasks/{task['data']['id']}"
    missing = await client.patch(url, json={"title": "x"}, headers=auth())
    assert missing.status_code == 428
    ok = await client.patch(
        url, json={"status": "in_progress"}, headers={**auth(), "If-Match": '"1"'}
    )
    assert ok.status_code == 200 and ok.headers["ETag"] == '"2"'
    stale = await client.patch(url, json={"title": "y"}, headers={**auth(), "If-Match": '"1"'})
    assert stale.status_code == 412
    assert stale.json()["code"] == "VERSION_MISMATCH"


async def test_business_rule_done_is_terminal(client: AsyncClient) -> None:
    task = await _create(client, "finish", "key-0006")
    url = f"/api/v1/tasks/{task['data']['id']}"
    await client.patch(url, json={"status": "done"}, headers={**auth(), "If-Match": '"1"'})
    res = await client.patch(url, json={"status": "todo"}, headers={**auth(), "If-Match": '"2"'})
    assert res.status_code == 422
    assert res.json()["code"] == "INVALID_STATUS_TRANSITION"


async def test_delete_then_404(client: AsyncClient) -> None:
    task = await _create(client, "bye", "key-0007")
    url = f"/api/v1/tasks/{task['data']['id']}"
    assert (await client.delete(url, headers=auth())).status_code == 204
    assert (await client.delete(url, headers=auth())).status_code == 404
```

## `pyproject.toml (root; excerpt used by tests and ruff)`

```toml
[tool.pytest.ini_options]
asyncio_mode = "auto"
asyncio_default_fixture_loop_scope = "function"
pythonpath = ["."]
testpaths = ["tests"]

[tool.ruff]
line-length = 100
target-version = "py312"

[tool.ruff.lint]
select = ["E", "F", "W", "I", "B", "UP", "S", "D", "ANN", "BLE", "RUF"]
ignore = ["D104", "D105", "D107", "S101", "ANN401", "RUF012"]

[tool.ruff.lint.pydocstyle]
convention = "google"

[tool.ruff.lint.per-file-ignores]
"tests/**" = ["D", "ANN", "S"]
```

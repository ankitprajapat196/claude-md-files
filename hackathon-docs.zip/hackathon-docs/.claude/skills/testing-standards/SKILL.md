---
name: testing-standards
description: Testing rules for this project - pytest layout, fixtures, naming, coverage of acceptance criteria and failure paths (401, 404 other user, 422, 409, 412, timeouts, empty/partial tool results), agent/workflow tests with fake models, node --test for frontend, and the test report format. Use whenever writing, running, or reviewing tests or producing a test report.
---

# Testing standards

Examples: `../production-api-standards/examples/03-api-tests.md`, `../agentic-workflow-standards/examples/05-agentic-tests.md`, `../vanilla-frontend-standards/examples/04-frontend-tests.md`.

## Layout and commands
- `tests/unit/` (services with fake DAOs, validators, pure logic), `tests/integration/` (HTTP via `httpx.AsyncClient` + `ASGITransport`, in-memory SQLite with `StaticPool`, dependency overrides), `tests/agents/` (fake Messages API; never call the real model in tests), `tests/agents/evals/` (jsonl eval sets), `tests/frontend/` (node:test), `tests/cases.py` + `tests/run_tests.py` (8-10 scored end-to-end demo cases, printed as a score table).
- Run: `uv run pytest -q` (pytest config in `pyproject.toml`, `asyncio_mode = "auto"`).
- Frontend: `node --test tests/frontend/`.
- File names `test_<feature>_<layer>.py`; test names `test_<behaviour>_<expected>()`.

## What every feature must prove
1. Each acceptance criterion from the plan has at least one test, referenced by AC id in the test docstring or name.
2. Failure paths: missing auth 401, another user's object 404, validation 422 with field list, business rule 422 with its code, idempotency replay + key reuse 409 (if POST creates), stale version 412 / missing If-Match 428 (if updates), pagination bounds, empty list.
3. Agents/workflows: transient vs permanent error handling, invalid structured output retried then failing, budget stop, spinning stop, empty vs access-failure tool results, resume from checkpoint, prompt-injection text in inputs does not change behaviour (eval).
4. Deterministic data: mock data with fixed seeds; no network; no real secrets.

## Test report
Write with the template in the workflow-artifacts skill. First line after the title must be exactly `**Overall result:** PASS` or `**Overall result:** FAIL` (the approval hook reads it). PASS only if every test passes and every acceptance criterion is covered; otherwise FAIL with the failures table filled.

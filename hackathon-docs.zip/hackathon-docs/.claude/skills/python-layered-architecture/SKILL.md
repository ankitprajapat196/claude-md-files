---
name: python-layered-architecture
description: Mandatory backend code structure for this project - Controller -> Service -> DAO -> Schema/Model layering, composition root, Google-style docstrings, type hints, Pydantic validation in and out, logging, naming. Use whenever writing, refactoring, or reviewing any Python file under app/ or src/, including agent and workflow code.
---

# Python layered architecture (Controller-Service-DAO-Schema)

Stack: Python 3.12, uv, FastAPI, Pydantic v2, SQLAlchemy 2.0 async, PostgreSQL (SQLite+aiosqlite in tests), Alembic, pytest, ruff (config: root `pyproject.toml`).

## Folder layout (project root)

```text
app/main.py                    # demo layer: app factory (middleware, handlers, routers, health, static files + pages); nothing else in app/
src/                           # all other application code, folders directly in src/
  config.py                    # Settings (env APP_*): model names, limits, thresholds in ONE place
  core/                        # errors, responses, middleware, exception_handlers, database, pagination, security
  dependencies/providers.py    # COMPOSITION ROOT: session -> DAOs -> service (only place that knows wiring)
  api/v1/router.py             # includes every controller router
  api/v1/controllers/<x>_controller.py
  services/<x>_service.py
  dao/<x>_dao.py
  models/<x>_model.py          # SQLAlchemy ORM (imported only by DAOs and migrations)
  schemas.py                   # ALL Pydantic models: request/response DTOs + agent I/O (nullable fields, enums), one section per feature
  agents/common/               # tool contract, resilience, budget, llm_client, agent loop (see agentic skill)
  agents/<name>.py             # one file per agent: coordinator.py, extractor.py
  tools/<tool>.py + registry.py  # one file per tool; external API clients live here (timeouts, retries, untrusted responses)
  guardrails/                  # code gates: validation, sign-off rules, hooks
  prompts/<name>.md            # prompt text, not buried in code
  observability/trace.py       # logs every tool call, cost, latency to logs/
templates/  static/{css,js,images}/   # frontend (see vanilla-frontend-standards)
data/sample/  data/fixtures/  data/seed_mock_data.py
tests/ unit/ integration/ agents/ frontend/ conftest.py cases.py run_tests.py
migrations/                    # Alembic, only once PostgreSQL is used
mcp_server/  .mcp.json         # only if the case builds/uses an MCP server
```

`app` imports `src`; `src` never imports `app`. Agents, tools, guardrails and `observability` never import `src.api` or `src.dependencies`; services call agents, controllers never do.

## Layer contract (enforced by the quality-gate hook)

| Layer | Does | Never does | May import |
|---|---|---|---|
| Controller | parse/validate HTTP input via schemas, auth dependency, call ONE service method, set headers, wrap in `SuccessResponse` | business rules, queries, try/except for flow control | fastapi, core, schemas, services (types), dependencies |
| Service | business rules, transactions (`async with session.begin()`), idempotency, orchestration, raise typed `AppError` | import FastAPI/Starlette, build HTTP responses, raw SQL | config, core, schemas, dao, agents, tools, sqlalchemy (session/exc only) |
| DAO | all queries; scope every query by owner/tenant; return models or `None`/`bool` | commit, raise HTTP errors, business decisions | sqlalchemy, models, core.database |
| Schema | request DTOs (`extra="forbid"`, limits, enums) and response DTOs (`from_attributes=True`, only public fields) | DB or HTTP logic | pydantic, enum, datetime |
| Model | ORM mapping, indexes, constraints | logic | sqlalchemy, core.database |
| Provider | `get_<x>_service(session=Depends(get_db_session))` | logic | everything above |

## Validation in AND out
- Input: request schemas with `Field(min_length, max_length, ge, le)`, enums, `extra="forbid"`, `str_strip_whitespace=True`; cross-field rules in `model_validator`; business rules in the service (raise `BusinessRuleError` with a specific `code`).
- Output: every endpoint declares `response_model=SuccessResponse[XResponse]`; services return response DTOs, never ORM objects; LLM/third-party outputs are validated with Pydantic before use.

## Code style
- OOP, single responsibility: one class per service/DAO, constructor injection, no module-level mutable state.
- Type hints on every parameter and return (`-> None` included). `from __future__` not needed on 3.12.
- Google-style docstrings on every module, public class, and public function/method, in the format of "Docstring format" below: summary line, `Args:`, `Returns:`/`Yields:`, `Raises:`, plus `Example:`/`Attributes:` where they apply.
- Naming: `snake_case` files/functions, `PascalCase` classes, suffixes `Controller` (router module), `Service`, `DAO`, `Model`, `Request`, `Response`; error codes `UPPER_SNAKE_CASE`.
- Logging: `logger = logging.getLogger("src.<layer>.<feature>")`; structured fields via `extra={...}`; never log secrets, tokens, or full PII; no `print()`.
- Errors: raise subclasses of `src.core.errors.AppError`; never `except:`; never swallow exceptions; re-raise with `from exc`.
- Config only via `src.config.Settings` (env vars `APP_*`; model names, limits and thresholds live there and nowhere else); no hard-coded URLs, keys, or model ids.
- Async everywhere on the request path; no blocking calls (use `httpx.AsyncClient`, `asyncio.to_thread` for CPU/blocking work).
- DB: parameterised queries only (SQLAlchemy expressions / `text()` with bound params), indexes for every filter/sort, keyset pagination, Alembic migration per schema change (`create_all` only in dev/test).

## Docstring format (module, class, method)

Every section is Google style. Types go in parentheses after the name in `Args:`, `Attributes:` and `Returns:`. The quality-gate hook requires `Args:`, `Returns:`/`Yields:` and (as a warning) `Raises:`; `Example:` and `Attributes:` are part of the house style. Examples use `>>>` only when they are true and cheap to run; for DB/HTTP/LLM code show a short illustrative call or omit `Example:`.

**Module level** — what the module does, who uses it, then `Example:` and `Attributes:` (module constants) when present:

```python
"""Helpers for loading, validating, and normalizing user CSV imports.

This module reads CSV files, checks that required columns are present,
and normalizes values such as whitespace and email casing before the
data is stored. It is used by the data import pipeline and is not
meant to be run as a standalone script.

Example:
    >>> from csv_import import load_rows
    >>> rows = load_rows("users.csv")
    >>> len(rows)
    42

Attributes:
    DEFAULT_ENCODING (str): Encoding used when a file does not specify one.
"""
```

**Class level** — responsibility and invariants, `Example:`, and `Attributes:` with types; document `__init__` arguments and `Raises:` on `__init__`:

```python
class BankAccount:
    """Represents a bank account that supports deposits and withdrawals.

    The account tracks its owner and current balance. Operations that
    would make the balance negative are rejected, so the balance never
    drops below zero.

    Example:
        >>> account = BankAccount("Alice", opening_balance=100.00)
        >>> account.deposit(50.00)
        150.0
        >>> account.balance
        150.0

    Attributes:
        owner (str): Name of the account holder.
        balance (float): Current balance in dollars.
    """

    def __init__(self, owner: str, opening_balance: float = 0.0) -> None:
        """Create a new bank account.

        Args:
            owner (str): Name of the account holder. Must not be empty.
            opening_balance (float): Starting balance in dollars.
                Defaults to 0.0.

        Raises:
            ValueError: If owner is empty or opening_balance is negative.
        """
        ...
```

**Method / function level** — summary, behaviour paragraph, `Args:` (with defaults), `Returns:` as `name (type): meaning`, `Raises:`, `Example:`:

```python
def withdraw(self, amount: float, note: str = "") -> float:
    """Withdraw money from the account.

    Subtracts the requested amount from the balance when enough funds are
    available. The withdrawal is recorded in the transaction history along
    with the optional note.

    Args:
        amount (float): Amount to withdraw. Must be greater than zero.
        note (str): Optional description stored with the transaction.
            Defaults to an empty string.

    Returns:
        new_balance (float): The account balance after the withdrawal.

    Raises:
        ValueError: If amount is zero or negative.
        InsufficientFundsError: If amount is greater than the current balance.

    Example:
        >>> account = BankAccount("Alice", opening_balance=100.00)
        >>> account.withdraw(30.00, note="groceries")
        70.0
    """
    ...
```

Pydantic schemas list their fields under `Attributes:` with types (`title (str): ...`). Private helpers and `_validators` may keep a one-line docstring.

## Before writing code
1. Read the approved plan's sections 6-8 (API contract, data model, layer design).
2. Read `../production-api-standards/examples/01-core-infrastructure.md` once; build `src/core/` in the FIRST feature only, reuse afterwards.
3. Follow `../production-api-standards/examples/02-resource-endpoint-end-to-end.md` for each new resource.

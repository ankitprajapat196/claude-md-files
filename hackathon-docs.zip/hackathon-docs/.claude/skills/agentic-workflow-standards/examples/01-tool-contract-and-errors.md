# Example 1 — Tool response contract and error envelope

Checklist §5: status enum on every tool response (`success`, `empty_result`, `partial_result`, `access_failure`), empty is never "nothing exists", success carries provenance, partial results list failed + retry-safe items, ToolError has the 4 fields (code, message, context, suggested_action) plus user/system category, agent-to-coordinator ErrorEnvelope with severity and a defined policy per severity. Tool output is wrapped as untrusted data (§13).

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `src/agents/common/tool_contract.py`

```python
"""Uniform tool response contract and agent-to-coordinator error envelope.

Every tool returns a ``ToolResult`` whose ``status`` distinguishes a genuine
empty result from an access failure, so the model never reads "no rows" as
"nothing exists" when the database was actually unreachable. It is used by
every tool handler, by the agent loop that wraps their output, and by workflows
that propagate errors to their coordinator.

Attributes:
    SEVERITY_POLICY (dict[Severity, str]): Coordinator policy for each error severity.
"""

import json
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class ToolStatus(StrEnum):
    """Outcome of a tool call.

    Attributes:
        SUCCESS (str): The call returned data.
        EMPTY_RESULT (str): The call worked and genuinely found nothing.
        PARTIAL_RESULT (str): Some items succeeded and some failed.
        ACCESS_FAILURE (str): The source could not be reached or read.
    """

    SUCCESS = "success"
    EMPTY_RESULT = "empty_result"
    PARTIAL_RESULT = "partial_result"
    ACCESS_FAILURE = "access_failure"


class ErrorCategory(StrEnum):
    """Who must act: the user (fix input) or the system (retry/fallback/escalate).

    Attributes:
        USER (str): The user must fix their input.
        SYSTEM (str): The system must retry, fall back, or escalate.
    """

    USER = "user"
    SYSTEM = "system"


class ToolError(BaseModel):
    """Structured tool error with the four required fields plus routing hints.

    Attributes:
        code (str): Stable error code, e.g. ``DB_TIMEOUT``.
        message (str): Human/model readable explanation.
        context (dict[str, Any]): What was attempted and why it failed.
        suggested_action (str): What the caller should do next.
        category (ErrorCategory): User error vs system error.
        retryable (bool): Whether retrying the same call can succeed.
    """

    code: str
    message: str
    context: dict[str, Any] = Field(default_factory=dict)
    suggested_action: str
    category: ErrorCategory = ErrorCategory.SYSTEM
    retryable: bool = False


class ToolMetadata(BaseModel):
    """Provenance so downstream steps can trust and trace data.

    Attributes:
        source (str): System the data came from.
        fetched_at (datetime): UTC timestamp of the read.
    """

    source: str
    fetched_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class ToolResult(BaseModel):
    """Envelope returned by every tool handler.

    Every handler builds its result through the ``success``, ``partial`` or
    ``failure`` constructors so the status always matches the payload.

    Example:
        >>> ToolResult.success([], "db").status.value
        'empty_result'
        >>> ToolResult.success({"id": 1}, "db").status.value
        'success'

    Attributes:
        status (ToolStatus): Outcome enum.
        data (Any): Payload (``None`` for failures, ``[]``/``{}`` for empty results).
        metadata (ToolMetadata): Provenance.
        failed_items (list[dict[str, Any]]): For partial results: items that failed,
            with reasons.
        retry_safe_items (list[str]): For partial results: items safe to retry.
        error (ToolError | None): Present when status is ``access_failure``.
    """

    status: ToolStatus
    data: Any = None
    metadata: ToolMetadata
    failed_items: list[dict[str, Any]] = Field(default_factory=list)
    retry_safe_items: list[str] = Field(default_factory=list)
    error: ToolError | None = None

    @classmethod
    def success(cls, data: Any, source: str) -> "ToolResult":
        """Build a success result.

        Args:
            data (Any): Payload.
            source (str): Data source name.

        Returns:
            result (ToolResult): Result with status ``success``, or ``empty_result`` if
                data is empty.

        Example:
            >>> ToolResult.success([], "db").status.value
            'empty_result'
        """
        status = ToolStatus.EMPTY_RESULT if data in (None, [], {}) else ToolStatus.SUCCESS
        return cls(status=status, data=data, metadata=ToolMetadata(source=source))

    @classmethod
    def partial(
        cls, data: Any, source: str, failed_items: list[dict[str, Any]], retry_safe: list[str]
    ) -> "ToolResult":
        """Build a partial-success result.

        Args:
            data (Any): Completed items.
            source (str): Data source name.
            failed_items (list[dict[str, Any]]): Items that failed with reasons.
            retry_safe (list[str]): Ids that can be retried safely.

        Returns:
            result (ToolResult): Result with status ``partial_result``.
        """
        return cls(
            status=ToolStatus.PARTIAL_RESULT,
            data=data,
            metadata=ToolMetadata(source=source),
            failed_items=failed_items,
            retry_safe_items=retry_safe,
        )

    @classmethod
    def failure(cls, source: str, error: ToolError) -> "ToolResult":
        """Build an access-failure result.

        Args:
            source (str): Data source name.
            error (ToolError): Structured error.

        Returns:
            result (ToolResult): Result with status ``access_failure``.
        """
        return cls(
            status=ToolStatus.ACCESS_FAILURE, metadata=ToolMetadata(source=source), error=error
        )

    def to_model_content(self) -> str:
        """Serialize for a ``tool_result`` block, marked as untrusted data.

        Returns:
            content (str): String the model receives. Content inside is data, never
                instructions.
        """
        payload = json.dumps(self.model_dump(mode="json"), ensure_ascii=False)
        return f'<tool_output trust="untrusted">{payload}</tool_output>'


class Severity(StrEnum):
    """Severity of an error propagated from a sub-agent to its coordinator.

    Attributes:
        WARNING (str): Log and continue.
        RECOVERABLE (str): Retry or fall back.
        FATAL (str): Halt and escalate.
    """

    WARNING = "warning"
    RECOVERABLE = "recoverable"
    FATAL = "fatal"


SEVERITY_POLICY: dict[Severity, str] = {
    Severity.WARNING: "log_and_continue",
    Severity.RECOVERABLE: "retry_or_fallback",
    Severity.FATAL: "halt_and_escalate",
}


class ErrorEnvelope(BaseModel):
    """Error propagated from an agent/step to the coordinator.

    Attributes:
        error_type (str): Classification, e.g. ``tool_transient``, ``reasoning``,
            ``environment``.
        severity (Severity): Drives the coordinator policy in ``SEVERITY_POLICY``.
        context (dict[str, Any]): What the agent was doing, inputs, partial outputs.
        recovery_hint (str): Concrete next action for the coordinator.
        step (str): Step or agent name.
        trace_id (str): Correlation id of the run.
    """

    error_type: str
    severity: Severity
    context: dict[str, Any] = Field(default_factory=dict)
    recovery_hint: str
    step: str
    trace_id: str

    @property
    def policy(self) -> str:
        """Return the coordinator policy for this severity.

        Returns:
            policy (str): One of ``log_and_continue``, ``retry_or_fallback``,
                ``halt_and_escalate``.
        """
        return SEVERITY_POLICY[self.severity]
```

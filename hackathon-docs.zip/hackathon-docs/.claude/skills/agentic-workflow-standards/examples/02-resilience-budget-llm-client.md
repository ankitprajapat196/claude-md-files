# Example 2 — Retry, circuit breaker, budgets, LLM client with validation loop

Checklist §6-8: retry ONLY transient errors (timeouts, 429, 5xx, 529) with exponential backoff + full jitter and max attempts; circuit breaker closed -> open -> half-open; budgets enforced in code; model tiers (fast / default / deep); structured output = forced single tool call with `strict: true` + Pydantic re-validation and a validation loop that feeds back the exact errors. Create the real client with `AsyncAnthropic(max_retries=0).messages` so retries are not doubled.

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `src/agents/common/resilience.py`

```python
"""Retry with exponential backoff + jitter (transient errors only) and a circuit breaker.

This module classifies errors as transient or permanent, retries only the transient
ones, and short-circuits calls to an unhealthy dependency. It is used by the LLM
client and by any tool handler that calls an external service.

Attributes:
    logger (logging.Logger): Module logger (``src.agents.resilience``).
    T (TypeVar): Result type of the wrapped operation.
    TRANSIENT_STATUS (set[int]): HTTP status codes treated as transient.
"""

import asyncio
import logging
import random
import time
from collections.abc import Awaitable, Callable
from enum import StrEnum
from typing import TypeVar

import anthropic

logger = logging.getLogger("src.agents.resilience")
T = TypeVar("T")
TRANSIENT_STATUS = {408, 409, 429, 500, 502, 503, 504, 529}


def is_transient(exc: BaseException) -> bool:
    """Classify an exception as transient (retryable) or permanent.

    Args:
        exc (BaseException): Raised exception.

    Returns:
        transient (bool): True for timeouts, connection errors, rate limits, overload,
            and 5xx.

    Example:
        >>> is_transient(TimeoutError())
        True
        >>> is_transient(ValueError("bad"))
        False
    """
    if isinstance(exc, (anthropic.APIConnectionError, anthropic.APITimeoutError, TimeoutError)):
        return True
    if isinstance(exc, anthropic.APIStatusError):
        return exc.status_code in TRANSIENT_STATUS
    return False


async def retry_async(
    operation: Callable[[], Awaitable[T]],
    *,
    max_attempts: int = 3,
    base_delay: float = 0.5,
    max_delay: float = 8.0,
    classify: Callable[[BaseException], bool] = is_transient,
) -> T:
    """Run ``operation`` and retry transient failures with full-jitter backoff.

    Args:
        operation (Callable[[], Awaitable[T]]): Zero-arg coroutine factory (must be
            idempotent or idempotency-keyed).
        max_attempts (int): Total attempts including the first. Defaults to 3.
        base_delay (float): Initial backoff in seconds. Defaults to 0.5.
        max_delay (float): Backoff cap in seconds. Defaults to 8.0.
        classify (Callable[[BaseException], bool]): Returns True if an exception is
            worth retrying. Defaults to ``is_transient``.

    Returns:
        result (T): The operation result.

    Raises:
        BaseException: The last error, immediately for permanent errors.
    """
    for attempt in range(1, max_attempts + 1):
        try:
            return await operation()
        except Exception as exc:
            if not classify(exc) or attempt == max_attempts:
                raise
            delay = random.uniform(0, min(max_delay, base_delay * 2 ** (attempt - 1)))  # noqa: S311
            logger.warning("retrying", extra={"attempt": attempt, "delay": round(delay, 2)})
            await asyncio.sleep(delay)
    raise RuntimeError("unreachable")  # pragma: no cover


class CircuitState(StrEnum):
    """Circuit breaker states.

    Attributes:
        CLOSED (str): Calls pass through normally.
        OPEN (str): Calls are short-circuited.
        HALF_OPEN (str): A trial call is allowed after the cool-down.
    """

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitOpenError(RuntimeError):
    """Raised when calls are short-circuited because the dependency is unhealthy."""


class CircuitBreaker:
    """Closed -> open after N consecutive failures -> half-open after a cool-down.

    A failed trial call in the half-open state reopens the circuit; a successful
    call closes it and resets the failure count.

    Attributes:
        name (str): Dependency name for logs.
        failure_threshold (int): Consecutive failures that open the circuit.
        reset_timeout (float): Seconds to wait before a half-open trial call.
        state (CircuitState): Current breaker state.
    """

    def __init__(self, name: str, failure_threshold: int = 5, reset_timeout: float = 30.0) -> None:
        """Configure the breaker.

        Args:
            name (str): Dependency name for logs.
            failure_threshold (int): Consecutive failures that open the circuit.
                Defaults to 5.
            reset_timeout (float): Seconds to wait before a half-open trial call.
                Defaults to 30.0.
        """
        self.name = name
        self.failure_threshold = failure_threshold
        self.reset_timeout = reset_timeout
        self.state = CircuitState.CLOSED
        self._failures = 0
        self._opened_at = 0.0

    async def call(self, operation: Callable[[], Awaitable[T]]) -> T:
        """Run ``operation`` through the breaker.

        Args:
            operation (Callable[[], Awaitable[T]]): Zero-arg coroutine factory.

        Returns:
            result (T): The operation result.

        Raises:
            CircuitOpenError: If the circuit is open and the cool-down has not elapsed.
        """
        if self.state is CircuitState.OPEN:
            if time.monotonic() - self._opened_at < self.reset_timeout:
                raise CircuitOpenError(f"circuit '{self.name}' is open")
            self.state = CircuitState.HALF_OPEN
        try:
            result = await operation()
        except Exception:
            self._record_failure()
            raise
        self._failures = 0
        self.state = CircuitState.CLOSED
        return result

    def _record_failure(self) -> None:
        self._failures += 1
        if self.state is CircuitState.HALF_OPEN or self._failures >= self.failure_threshold:
            self.state = CircuitState.OPEN
            self._opened_at = time.monotonic()
            logger.error("circuit_opened", extra={"dependency": self.name})
```

## `src/agents/common/budget.py`

```python
"""Run budgets enforced in code (turns, tokens), not only in the prompt.

This module holds the ``RunBudget`` counter. It is used by the LLM client to charge
every model call and by the agent loop and workflows to stop a run that has used up
its turns or tokens.
"""

from dataclasses import dataclass


@dataclass
class RunBudget:
    """Hard limits for one agent/workflow run.

    Example:
        >>> budget = RunBudget(max_turns=1)
        >>> budget.charge(10, 5)
        >>> budget.exhausted_reason()
        'max_turns'

    Attributes:
        max_turns (int): Maximum model calls.
        max_input_tokens (int): Cumulative input-token ceiling.
        max_output_tokens (int): Cumulative output-token ceiling.
        turns (int): Model calls used so far.
        input_tokens (int): Input tokens used so far.
        output_tokens (int): Output tokens used so far.
    """

    max_turns: int = 12
    max_input_tokens: int = 200_000
    max_output_tokens: int = 20_000
    turns: int = 0
    input_tokens: int = 0
    output_tokens: int = 0

    def charge(self, input_tokens: int, output_tokens: int) -> None:
        """Record usage of one model call.

        Args:
            input_tokens (int): Input tokens reported by the API.
            output_tokens (int): Output tokens reported by the API.

        Returns:
            None: The counters are updated in place.
        """
        self.turns += 1
        self.input_tokens += input_tokens
        self.output_tokens += output_tokens

    def exhausted_reason(self) -> str | None:
        """Return why the budget is exhausted, if it is.

        Returns:
            reason (str | None): Reason string, or ``None`` while budget remains.
        """
        if self.turns >= self.max_turns:
            return "max_turns"
        if self.input_tokens >= self.max_input_tokens:
            return "max_input_tokens"
        if self.output_tokens >= self.max_output_tokens:
            return "max_output_tokens"
        return None
```

## `src/agents/common/llm_client.py`

```python
"""Thin, testable wrapper around the Anthropic Messages API.

Adds: model tiers, explicit retry of transient errors only, a circuit breaker,
usage accounting against a ``RunBudget``, trace-id logging, and
``extract_structured`` = forced strict tool call + Pydantic validation loop.
It is used by every workflow and agent as the single gateway to the model.

Attributes:
    logger (logging.Logger): Module logger (``src.agents.llm``).
    M (TypeVar): Pydantic output model type for structured extraction.
    MODEL_FAST (str): Cheapest model tier, from ``LLM_MODEL_FAST``.
    MODEL_DEFAULT (str): Default model tier, from ``LLM_MODEL_DEFAULT``.
    MODEL_DEEP (str): Most capable model tier, from ``LLM_MODEL_DEEP``.
"""

import json
import logging
import os
from typing import Any, Protocol, TypeVar

from pydantic import BaseModel, ValidationError

from src.agents.common.budget import RunBudget
from src.agents.common.resilience import CircuitBreaker, retry_async

logger = logging.getLogger("src.agents.llm")
M = TypeVar("M", bound=BaseModel)

MODEL_FAST = os.getenv("LLM_MODEL_FAST", "claude-haiku-5-5")
MODEL_DEFAULT = os.getenv("LLM_MODEL_DEFAULT", "claude-sonnet-5-5")
MODEL_DEEP = os.getenv("LLM_MODEL_DEEP", "claude-opus-5-5")


class MessagesAPI(Protocol):
    """Subset of ``AsyncAnthropic().messages`` used here (lets tests inject fakes).

    The client depends on this protocol rather than on the SDK class, so tests pass
    a scripted fake and never call the real model.
    """

    async def create(self, **kwargs: Any) -> Any:
        """Create a message.

        Args:
            **kwargs (Any): Messages API parameters.

        Returns:
            message (Any): The API message object.
        """


class StructuredOutputError(RuntimeError):
    """Model output still invalid after the validation loop's retry budget.

    The message holds the last validation error so callers can log or escalate it.
    """


class LLMClient:
    """Model gateway used by every workflow and agent.

    Wraps a Messages API object with transient-error retry, a circuit breaker, budget
    charging, and trace-id logging.
    """

    def __init__(
        self, messages_api: MessagesAPI, breaker: CircuitBreaker | None = None, timeout: float = 60
    ) -> None:
        """Create the client.

        Args:
            messages_api (MessagesAPI): ``AsyncAnthropic(max_retries=0).messages`` or a
                fake in tests.
            breaker (CircuitBreaker | None): Optional shared circuit breaker for the LLM
                dependency. Defaults to a new breaker named ``anthropic``.
            timeout (float): Per-request timeout in seconds. Defaults to 60.
        """
        self._api = messages_api
        self._breaker = breaker or CircuitBreaker("anthropic")
        self._timeout = timeout

    async def create(self, *, budget: RunBudget, trace_id: str, **request: Any) -> Any:
        """Call the Messages API with retry, breaker, budget accounting, and logging.

        Args:
            budget (RunBudget): Run budget to charge.
            trace_id (str): Correlation id for logs.
            **request (Any): Messages API parameters (model, system, messages, tools, ...).

        Returns:
            message (Any): The API message object.

        Raises:
            CircuitOpenError: If the circuit breaker is open.
            Exception: A permanent error, or a transient one after retries are exhausted.
        """

        async def attempt() -> Any:
            return await self._breaker.call(
                lambda: self._api.create(timeout=self._timeout, **request)
            )

        message = await retry_async(attempt)
        budget.charge(message.usage.input_tokens, message.usage.output_tokens)
        logger.info(
            json.dumps(
                {
                    "event": "llm_call",
                    "trace_id": trace_id,
                    "model": request.get("model"),
                    "stop_reason": message.stop_reason,
                    "input_tokens": message.usage.input_tokens,
                    "output_tokens": message.usage.output_tokens,
                }
            )
        )
        return message

    async def extract_structured(
        self,
        *,
        output_model: type[M],
        system: str,
        user_content: str,
        budget: RunBudget,
        trace_id: str,
        model: str = MODEL_DEFAULT,
        max_attempts: int = 2,
        strict: bool = True,
    ) -> M:
        """Force a single tool call whose input must validate against ``output_model``.

        Schema guarantees structure; Pydantic re-validates semantics and constraints
        the API does not enforce. On failure the exact validation errors are fed back
        and the call is retried, up to ``max_attempts``.

        Args:
            output_model (type[M]): Pydantic model describing the expected output.
            system (str): System prompt.
            user_content (str): User message (documents first, question last).
            budget (RunBudget): Run budget.
            trace_id (str): Correlation id.
            model (str): Model id (pick the cheapest tier that passes evals).
                Defaults to ``MODEL_DEFAULT``.
            max_attempts (int): Validation-loop attempts. Defaults to 2.
            strict (bool): Enable strict tool use; set False if the API rejects a schema
                keyword. Defaults to True.

        Returns:
            output (M): A validated ``output_model`` instance.

        Raises:
            StructuredOutputError: If output is still invalid after all attempts.
        """
        tool_name = f"record_{output_model.__name__.lower()}"
        schema = output_model.model_json_schema()
        schema.setdefault("additionalProperties", False)
        tool = {
            "name": tool_name,
            "description": (
                f"Record the final {output_model.__name__}. Always call this exactly once."
            ),
            "input_schema": schema,
            **({"strict": True} if strict else {}),
        }
        messages: list[dict[str, Any]] = [{"role": "user", "content": user_content}]
        last_error = ""
        for _ in range(max_attempts):
            message = await self.create(
                budget=budget,
                trace_id=trace_id,
                model=model,
                max_tokens=2048,
                system=system,
                tools=[tool],
                tool_choice={"type": "tool", "name": tool_name},
                messages=messages,
            )
            block = next((b for b in message.content if b.type == "tool_use"), None)
            if block is None:
                last_error = "Model did not call the output tool."
                continue
            try:
                return output_model.model_validate(block.input)
            except ValidationError as exc:
                last_error = exc.json(include_url=False)
                messages += [
                    {"role": "assistant", "content": message.content},
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": block.id,
                                "is_error": True,
                                "content": f"Validation failed, fix exactly: {last_error}",
                            }
                        ],
                    },
                ]
        raise StructuredOutputError(last_error)
```

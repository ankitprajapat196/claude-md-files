# Example 5 — Testing agents and workflows without calling the model

Checklist §14: scripted fake Messages API; tests cover failure paths first (permanent vs transient errors, breaker, spinning, budget, invalid structured output, resume from checkpoint). Add an eval set (typical / edge / adversarial) for prompt quality on top of these.

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `tests/agents/fakes.py`

```python
"""Fake Messages API so agent/workflow tests never call the real model."""

from types import SimpleNamespace
from typing import Any


def text_message(text: str) -> SimpleNamespace:
    return SimpleNamespace(
        content=[SimpleNamespace(type="text", text=text)],
        stop_reason="end_turn",
        usage=SimpleNamespace(input_tokens=10, output_tokens=5),
    )


def tool_message(name: str, tool_input: dict[str, Any], tool_id: str = "tu_1") -> SimpleNamespace:
    return SimpleNamespace(
        content=[SimpleNamespace(type="tool_use", id=tool_id, name=name, input=tool_input)],
        stop_reason="tool_use",
        usage=SimpleNamespace(input_tokens=10, output_tokens=5),
    )


class ScriptedMessages:
    """Returns scripted responses in order and records every request."""

    def __init__(self, responses: list[Any]) -> None:
        self._responses = list(responses)
        self.requests: list[dict[str, Any]] = []

    async def create(self, **kwargs: Any) -> Any:
        self.requests.append(kwargs)
        item = self._responses.pop(0)
        if isinstance(item, Exception):
            raise item
        return item
```

## `tests/agents/test_agentic_patterns.py`

```python
"""Tests for the agentic building blocks: failure paths first."""

import anthropic
import httpx
import pytest

from src.agents.common.agent_loop import AgentLoop, RegisteredTool, RunStatus
from src.agents.common.budget import RunBudget
from src.agents.common.fact_block import FactBlock
from src.agents.common.llm_client import LLMClient, StructuredOutputError
from src.agents.common.resilience import (
    CircuitBreaker,
    CircuitOpenError,
    CircuitState,
    is_transient,
    retry_async,
)
from src.agents.common.tool_contract import ToolError, ToolResult, ToolStatus
from src.agents.ticket_triage import Classification, TicketTriageWorkflow
from tests.agents.fakes import ScriptedMessages, text_message, tool_message

LOOKUP_TOOL = {
    "name": "lookup_order",
    "description": "Fetch one order by id. Use when the user gives an order id. "
    "Do NOT use for searching by customer name.",
    "input_schema": {
        "type": "object",
        "properties": {"order_id": {"type": "string"}},
        "required": ["order_id"],
        "additionalProperties": False,
    },
}


def _status_error(code: int) -> anthropic.APIStatusError:
    request = httpx.Request("POST", "https://api.anthropic.com/v1/messages")
    response = httpx.Response(code, request=request)
    return anthropic.APIStatusError("boom", response=response, body=None)


def test_empty_result_is_not_access_failure() -> None:
    assert ToolResult.success([], "db").status is ToolStatus.EMPTY_RESULT
    failure = ToolResult.failure(
        "db", ToolError(code="DB_TIMEOUT", message="t", suggested_action="retry", retryable=True)
    )
    assert failure.status is ToolStatus.ACCESS_FAILURE
    assert 'trust="untrusted"' in failure.to_model_content()


def test_transient_classification() -> None:
    assert is_transient(_status_error(529))
    assert is_transient(_status_error(429))
    assert not is_transient(_status_error(400))
    assert not is_transient(ValueError("bad"))


async def test_retry_only_transient_errors() -> None:
    calls = {"n": 0}

    async def flaky() -> str:
        calls["n"] += 1
        if calls["n"] < 3:
            raise _status_error(503)
        return "ok"

    assert await retry_async(flaky, base_delay=0) == "ok"
    calls["n"] = 0

    async def permanent() -> str:
        calls["n"] += 1
        raise _status_error(400)

    with pytest.raises(anthropic.APIStatusError):
        await retry_async(permanent, base_delay=0)
    assert calls["n"] == 1


async def test_circuit_breaker_opens_then_half_opens() -> None:
    breaker = CircuitBreaker("dep", failure_threshold=2, reset_timeout=0)

    async def fail() -> None:
        raise RuntimeError("down")

    for _ in range(2):
        with pytest.raises(RuntimeError):
            await breaker.call(fail)
    assert breaker.state is CircuitState.OPEN
    breaker.reset_timeout = 60
    with pytest.raises(CircuitOpenError):
        await breaker.call(fail)


async def test_agent_completes_and_uses_tool() -> None:
    api = ScriptedMessages([tool_message("lookup_order", {"order_id": "A1"}), text_message("Done")])

    async def lookup(tool_input: dict) -> ToolResult:
        return ToolResult.success({"id": tool_input["order_id"], "state": "shipped"}, "orders_db")

    loop = AgentLoop(LLMClient(api), "<role>support</role>", [RegisteredTool(LOOKUP_TOOL, lookup)])
    result = await loop.run("Where is order A1?", RunBudget(), FactBlock())
    assert result.status is RunStatus.COMPLETED and result.final_text == "Done"
    assert result.steps == ["lookup_order -> success"]


async def test_agent_stops_on_repeated_identical_call() -> None:
    api = ScriptedMessages(
        [
            tool_message("lookup_order", {"order_id": "A1"}),
            tool_message("lookup_order", {"order_id": "A1"}),
        ]
    )

    async def lookup(tool_input: dict) -> ToolResult:
        return ToolResult.success([], "orders_db")

    loop = AgentLoop(LLMClient(api), "s", [RegisteredTool(LOOKUP_TOOL, lookup)])
    result = await loop.run("Where is A1?", RunBudget(), FactBlock())
    assert result.status is RunStatus.ESCALATED and result.stop_reason == "no_progress"
    assert result.handoff and result.handoff.triggering_question == "Where is A1?"


async def test_agent_respects_budget() -> None:
    api = ScriptedMessages([tool_message("lookup_order", {"order_id": str(i)}) for i in range(5)])

    async def lookup(tool_input: dict) -> ToolResult:
        return ToolResult.success({"ok": True}, "orders_db")

    loop = AgentLoop(LLMClient(api), "s", [RegisteredTool(LOOKUP_TOOL, lookup)])
    result = await loop.run("loop", RunBudget(max_turns=2), FactBlock())
    assert result.stop_reason == "budget_exhausted"


async def test_structured_output_validation_loop_retries_then_fails() -> None:
    bad = tool_message("record_classification", {"category": "billing", "confidence": 7})
    good = tool_message("record_classification", {"category": "billing", "confidence": 0.9})
    client = LLMClient(ScriptedMessages([bad, good]))
    out = await client.extract_structured(
        output_model=Classification, system="s", user_content="u", budget=RunBudget(), trace_id="t"
    )
    assert out.confidence == 0.9
    failing = LLMClient(ScriptedMessages([bad, bad]))
    with pytest.raises(StructuredOutputError):
        await failing.extract_structured(
            output_model=Classification,
            system="s",
            user_content="u",
            budget=RunBudget(),
            trace_id="t",
        )


class MemoryCheckpoints:
    def __init__(self) -> None:
        self.data: dict[tuple[str, str], dict] = {}

    async def load(self, run_id: str, step: str) -> dict | None:
        return self.data.get((run_id, step))

    async def save(self, run_id: str, step: str, payload: dict) -> None:
        self.data[(run_id, step)] = payload


async def test_workflow_routes_low_confidence_and_ungrounded_fields() -> None:
    ticket = "My order #A-77 was charged twice. Contact me at a@b.co"
    api = ScriptedMessages(
        [
            tool_message("record_classification", {"category": "billing", "confidence": 0.95}),
            tool_message(
                "record_extraction",
                {
                    "order_id": {"value": "A-77", "confidence": 0.97, "evidence": "#A-77"},
                    "customer_email": {"value": "a@b.co", "confidence": 0.5, "evidence": "a@b.co"},
                    "summary": {
                        "value": "Double charge",
                        "confidence": 0.9,
                        "evidence": "invented",
                    },
                },
            ),
        ]
    )
    store = MemoryCheckpoints()
    result = await TicketTriageWorkflow(LLMClient(api), store).run(ticket, run_id="r1")
    assert result.fields_for_review == ["customer_email", "summary"]
    assert result.handoff is not None
    resumed = await TicketTriageWorkflow(LLMClient(ScriptedMessages([])), store).run(ticket, "r1")
    assert resumed.category == result.category
```

# Example 4 — Deterministic workflow (prefer this before an agent)

Checklist §1-2, §6, §11-12: fixed steps -> workflow, not agent; cheapest model tier per step; XML-tagged prompts with documents first and the question last; nullable fields + per-field confidence + verbatim evidence (hallucination control); semantic grounding check in code; per-FIELD routing to human review; checkpoint after each step so a crashed run resumes.

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `src/agents/ticket_triage.py`

```python
"""Example deterministic WORKFLOW (not an agent): classify -> extract -> validate -> route.

Chosen because the steps are fixed and predictable (checklist §1: start simple).
Each LLM step uses the cheapest model tier that passes evals, returns validated
structured output, and the run is checkpointed so it can resume after a crash.
"""

import uuid
from enum import StrEnum
from typing import Protocol

from pydantic import BaseModel, Field

from src.agents.common.budget import RunBudget
from src.agents.common.escalation import EscalationReason, HandoffPayload
from src.agents.common.llm_client import MODEL_DEFAULT, MODEL_FAST, LLMClient
from src.agents.common.tool_contract import ErrorEnvelope, Severity

CLASSIFY_SYSTEM = """<role>You triage customer support tickets.</role>
<instructions>Pick exactly one category.
If unsure, choose "other" and lower confidence.</instructions>
<constraints>Never invent facts that are not in the ticket.</constraints>"""

EXTRACT_SYSTEM = """<role>You extract fields from a support ticket.</role>
<instructions>Copy values exactly as written.
Use null when a value is not present.
For every field give a confidence between 0 and 1
and a short verbatim quote as evidence.</instructions>
<constraints>Do not guess order ids, emails, or amounts. null is always allowed.</constraints>"""


class Category(StrEnum):
    """Ticket categories."""

    BILLING = "billing"
    TECHNICAL = "technical"
    ACCOUNT = "account"
    OTHER = "other"


class Classification(BaseModel):
    """Output of step 1."""

    category: Category
    confidence: float = Field(ge=0, le=1)


class ExtractedField(BaseModel):
    """One extracted value with per-field confidence and provenance."""

    value: str | None
    confidence: float = Field(ge=0, le=1)
    evidence: str | None = Field(default=None, description="Verbatim quote from the ticket")


class Extraction(BaseModel):
    """Output of step 2 (nullable fields prevent hallucinated values)."""

    order_id: ExtractedField
    customer_email: ExtractedField
    summary: ExtractedField


class TriageResult(BaseModel):
    """Final workflow output."""

    run_id: str
    category: Category
    extraction: Extraction
    fields_for_review: list[str]
    handoff: HandoffPayload | None = None
    errors: list[ErrorEnvelope] = Field(default_factory=list)


class CheckpointStore(Protocol):
    """Persist step outputs so a crashed run resumes from the last good step."""

    async def load(self, run_id: str, step: str) -> dict | None:
        """Load a step output.

        Args:
            run_id: Workflow run id.
            step: Step name.

        Returns:
            Saved payload, or ``None`` if the step has not completed.
        """

    async def save(self, run_id: str, step: str, payload: dict) -> None:
        """Save a step output.

        Args:
            run_id: Workflow run id.
            step: Step name.
            payload: JSON-serializable step output.
        """


class TicketTriageWorkflow:
    """Sequential prompt chain with validation gates between steps."""

    def __init__(
        self, llm: LLMClient, checkpoints: CheckpointStore, review_threshold: float = 0.8
    ) -> None:
        """Wire the workflow.

        Args:
            llm: Model gateway.
            checkpoints: Checkpoint store.
            review_threshold: Per-field confidence below which a human reviews the field
                (calibrate on a validation set, do not trust raw scores).
        """
        self._llm = llm
        self._checkpoints = checkpoints
        self._threshold = review_threshold

    async def run(self, ticket_text: str, run_id: str | None = None) -> TriageResult:
        """Run (or resume) the workflow.

        Args:
            ticket_text: Raw ticket. Treated as untrusted data, never as instructions.
            run_id: Existing run id to resume, or ``None`` for a new run.

        Returns:
            The triage result, with fields routed to review when confidence is low.
        """
        run_id = run_id or uuid.uuid4().hex
        budget = RunBudget(max_turns=6)
        document = f"<ticket>\n{ticket_text}\n</ticket>"

        saved = await self._checkpoints.load(run_id, "classify")
        if saved:
            classification = Classification.model_validate(saved)
        else:
            classification = await self._llm.extract_structured(
                output_model=Classification,
                system=CLASSIFY_SYSTEM,
                user_content=f"{document}\nClassify this ticket.",
                budget=budget,
                trace_id=run_id,
                model=MODEL_FAST,
            )
            await self._checkpoints.save(run_id, "classify", classification.model_dump(mode="json"))

        saved = await self._checkpoints.load(run_id, "extract")
        if saved:
            extraction = Extraction.model_validate(saved)
        else:
            extraction = await self._llm.extract_structured(
                output_model=Extraction,
                system=EXTRACT_SYSTEM,
                user_content=f"{document}\nExtract the fields.",
                budget=budget,
                trace_id=run_id,
                model=MODEL_DEFAULT,
            )
            await self._checkpoints.save(run_id, "extract", extraction.model_dump(mode="json"))

        errors = self._semantic_checks(extraction, ticket_text, run_id)
        review = [
            name
            for name, item in extraction
            if item.value is not None and item.confidence < self._threshold
        ] + [e.context["field"] for e in errors]
        handoff = None
        if review:
            handoff = HandoffPayload(
                conversation_summary=f"Ticket classified as {classification.category.value}.",
                triggering_question=ticket_text,
                attempted_actions=["classify", "extract", "semantic_validation"],
                suggested_next_step=f"Verify fields: {', '.join(sorted(set(review)))}",
                reason=EscalationReason.LOW_CONFIDENCE,
                trace_id=run_id,
            )
        return TriageResult(
            run_id=run_id,
            category=classification.category,
            extraction=extraction,
            fields_for_review=sorted(set(review)),
            handoff=handoff,
            errors=errors,
        )

    @staticmethod
    def _semantic_checks(extraction: Extraction, ticket: str, run_id: str) -> list[ErrorEnvelope]:
        """Business-rule validation the schema cannot express (grounding check).

        Args:
            extraction: Model output.
            ticket: Source text.
            run_id: Trace id.

        Returns:
            Warnings for values whose evidence is not found verbatim in the source.
        """
        problems = []
        for name, item in extraction:
            if item.value is not None and (not item.evidence or item.evidence not in ticket):
                problems.append(
                    ErrorEnvelope(
                        error_type="ungrounded_value",
                        severity=Severity.WARNING,
                        context={"field": name, "value": item.value},
                        recovery_hint="Route field to human review.",
                        step="semantic_validation",
                        trace_id=run_id,
                    )
                )
        return problems
```

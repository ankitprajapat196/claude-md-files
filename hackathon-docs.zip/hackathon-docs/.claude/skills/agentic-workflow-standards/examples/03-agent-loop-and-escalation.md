# Example 3 — Bounded agent loop, fact block, human escalation

Checklist §8, §10, §12: the 4 stop conditions (complete, error threshold, budget, stop signal) in code; spinning detection (identical repeated call -> escalate); persistent fact block rendered into the system prompt every turn; unknown tools and tool exceptions converted into the contract instead of crashing; handoff payload with summary, verbatim triggering question, attempted actions, suggested next step.

> Verified: these files pass `pytest`, `ruff` (config in `pyproject.toml`) and the kit's quality gate. Copy the PATTERN, rename for your domain; never ship the `tasks` example itself.

## `src/agents/common/fact_block.py`

```python
"""Persistent fact block: critical facts kept OUTSIDE summaries so they never drift.

This module provides ``FactBlock``, which stores exact values (ids, amounts, decisions)
and renders them as XML. It is used by the agent loop, which renders the block into
the system prompt on every turn.
"""

from html import escape


class FactBlock:
    """Ordered key/value facts (ids, amounts, decisions, constraints) rendered as XML.

    Values are stored verbatim and HTML-escaped only when rendered.

    Example:
        >>> facts = FactBlock()
        >>> facts.set("customer_id", "C-1")
        >>> print(facts.render())
        <facts>
          <fact name="customer_id">C-1</fact>
        </facts>
    """

    def __init__(self) -> None:
        """Create an empty fact block.

        Returns:
            None: The block starts with no facts.
        """
        self._facts: dict[str, str] = {}

    def set(self, key: str, value: str) -> None:
        """Add or update a fact (extract facts BEFORE summarizing history).

        Args:
            key (str): Stable fact name, e.g. ``customer_id``.
            value (str): Exact value; never paraphrased.

        Returns:
            None: The fact is stored in place.
        """
        self._facts[key] = value

    def as_dict(self) -> dict[str, str]:
        """Return a copy of the facts.

        Returns:
            facts (dict[str, str]): Fact dictionary.
        """
        return dict(self._facts)

    def render(self) -> str:
        """Render facts for the system prompt.

        Returns:
            xml (str): ``<facts>...</facts>`` XML block (empty string when no facts).
        """
        if not self._facts:
            return ""
        rows = "\n".join(
            f'  <fact name="{escape(k)}">{escape(v)}</fact>' for k, v in self._facts.items()
        )
        return f"<facts>\n{rows}\n</facts>"
```

## `src/agents/common/escalation.py`

```python
"""Human-in-the-loop: escalation triggers and the 4-field handoff payload.

This module defines why a run is handed to a human, the payload the reviewer receives,
and the rules that trigger an escalation. It is used by the agent loop and by
workflows that route uncertain results to review.

Attributes:
    HIGH_RISK_TOOLS (frozenset[str]): Tool names that always require human approval.
"""

from enum import StrEnum

from pydantic import BaseModel, Field


class EscalationReason(StrEnum):
    """Why a run was handed to a human.

    Attributes:
        POLICY (str): A policy requires human review.
        HIGH_RISK_ACTION (str): The next action is high-risk.
        LOW_CONFIDENCE (str): Confidence is below the calibrated threshold.
        REPEATED_FAILURE (str): Too many failures in a row.
        BUDGET_EXHAUSTED (str): The run budget is used up.
        NO_PROGRESS (str): The run is spinning without progress.
    """

    POLICY = "policy"
    HIGH_RISK_ACTION = "high_risk_action"
    LOW_CONFIDENCE = "low_confidence"
    REPEATED_FAILURE = "repeated_failure"
    BUDGET_EXHAUSTED = "budget_exhausted"
    NO_PROGRESS = "no_progress"


class HandoffPayload(BaseModel):
    """Everything a human reviewer needs without re-reading the transcript.

    Attributes:
        conversation_summary (str): Short neutral summary of what happened.
        triggering_question (str): The user's original request, verbatim.
        attempted_actions (list[str]): What the system already tried, in order.
        suggested_next_step (str): The single most useful next action for the human.
        reason (EscalationReason): Escalation reason.
        trace_id (str): Correlation id for logs.
    """

    conversation_summary: str
    triggering_question: str
    attempted_actions: list[str] = Field(default_factory=list)
    suggested_next_step: str
    reason: EscalationReason
    trace_id: str


HIGH_RISK_TOOLS = frozenset({"send_email", "issue_refund", "delete_record"})


def should_escalate(
    *, tool_name: str | None, confidence: float | None, consecutive_failures: int, threshold: float
) -> EscalationReason | None:
    """Evaluate hard and soft escalation triggers.

    Checks run in order: high-risk tool, three or more consecutive failures, then
    confidence below the threshold.

    Args:
        tool_name (str | None): Tool about to run (hard trigger if high-risk).
        confidence (float | None): Calibrated confidence of the current output, if any.
        consecutive_failures (int): Failures in a row in this run.
        threshold (float): Confidence threshold calibrated on a validation set.

    Returns:
        reason (EscalationReason | None): The escalation reason, or ``None`` to continue
            automatically.

    Example:
        >>> should_escalate(
        ...     tool_name="issue_refund", confidence=None, consecutive_failures=0, threshold=0.8
        ... ).value
        'high_risk_action'
    """
    if tool_name in HIGH_RISK_TOOLS:
        return EscalationReason.HIGH_RISK_ACTION
    if consecutive_failures >= 3:
        return EscalationReason.REPEATED_FAILURE
    if confidence is not None and confidence < threshold:
        return EscalationReason.LOW_CONFIDENCE
    return None
```

## `src/agents/common/agent_loop.py`

```python
"""Bounded agent loop: dynamic tool choice with 4 stop conditions enforced in code.

Stop conditions: (1) task complete (``end_turn``), (2) error threshold,
(3) budget exhausted, (4) external stop signal. Also stops when it detects
spinning (the same tool call with the same input repeated). It is used by the
service layer to run any tool-using agent.

Attributes:
    ToolHandler (type): Async callable taking a tool input dict and returning a
        ``ToolResult``.
"""

import json
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from src.agents.common.budget import RunBudget
from src.agents.common.escalation import EscalationReason, HandoffPayload
from src.agents.common.fact_block import FactBlock
from src.agents.common.llm_client import MODEL_DEFAULT, LLMClient
from src.agents.common.tool_contract import ToolError, ToolResult, ToolStatus

ToolHandler = Callable[[dict[str, Any]], Awaitable[ToolResult]]


@dataclass
class RegisteredTool:
    """Tool definition sent to the model plus its async handler.

    Attributes:
        definition (dict[str, Any]): ``{"name", "description", "input_schema", "strict"?}``.
        handler (ToolHandler): Coroutine returning a ``ToolResult``.
    """

    definition: dict[str, Any]
    handler: ToolHandler


class RunStatus(StrEnum):
    """Final state of a run.

    Attributes:
        COMPLETED (str): The model finished the task.
        ESCALATED (str): The run was handed to a human.
        STOPPED (str): An external stop signal ended the run.
    """

    COMPLETED = "completed"
    ESCALATED = "escalated"
    STOPPED = "stopped"


@dataclass
class AgentRunResult:
    """Outcome returned to the service layer.

    Attributes:
        status (RunStatus): Completed, escalated, or stopped.
        stop_reason (str): Machine-readable reason.
        final_text (str): Model's final answer (completed runs only).
        facts (dict[str, str]): Fact block snapshot.
        handoff (HandoffPayload | None): Present when escalated.
        trace_id (str): Correlation id.
        steps (list[str]): Ordered log of tool calls with statuses.
    """

    status: RunStatus
    stop_reason: str
    final_text: str = ""
    facts: dict[str, str] = field(default_factory=dict)
    handoff: HandoffPayload | None = None
    trace_id: str = ""
    steps: list[str] = field(default_factory=list)


class AgentLoop:
    """Runs a tool-using agent until one of the stop conditions fires.

    Unknown tools and tool exceptions are converted into ``ToolResult`` failures
    instead of crashing the loop.
    """

    def __init__(
        self,
        llm: LLMClient,
        system_prompt: str,
        tools: list[RegisteredTool],
        *,
        model: str = MODEL_DEFAULT,
        max_consecutive_errors: int = 3,
        stop_signal: Callable[[], bool] | None = None,
    ) -> None:
        """Configure the loop.

        Args:
            llm (LLMClient): Model gateway.
            system_prompt (str): 5-section system prompt (role, context, instructions,
                constraints, examples).
            tools (list[RegisteredTool]): Narrow, non-overlapping tool set for this
                agent only.
            model (str): Model tier for reasoning steps. Defaults to ``MODEL_DEFAULT``.
            max_consecutive_errors (int): Error threshold stop condition. Defaults to 3.
            stop_signal (Callable[[], bool] | None): Callable returning True when an
                operator requests a stop. Defaults to never stopping.
        """
        self._llm = llm
        self._system = system_prompt
        self._tools = {t.definition["name"]: t for t in tools}
        self._model = model
        self._max_errors = max_consecutive_errors
        self._stop_signal = stop_signal or (lambda: False)

    async def run(self, user_request: str, budget: RunBudget, facts: FactBlock) -> AgentRunResult:
        """Execute the loop.

        Args:
            user_request (str): The user's request (kept verbatim for handoffs).
            budget (RunBudget): Hard limits for this run.
            facts (FactBlock): Persistent fact block (rendered into the system prompt
                each turn).

        Returns:
            result (AgentRunResult): Describes how the run ended.

        Raises:
            CircuitOpenError: If the LLM circuit breaker is open.
            Exception: A permanent or retry-exhausted model API error.
        """
        trace_id = uuid.uuid4().hex
        messages: list[dict[str, Any]] = [{"role": "user", "content": user_request}]
        steps: list[str] = []
        consecutive_errors = 0
        last_call: str | None = None

        def escalate(reason: EscalationReason, hint: str) -> AgentRunResult:
            handoff = HandoffPayload(
                conversation_summary=f"Agent ran {budget.turns} turns; last steps: {steps[-3:]}",
                triggering_question=user_request,
                attempted_actions=steps,
                suggested_next_step=hint,
                reason=reason,
                trace_id=trace_id,
            )
            return AgentRunResult(
                status=RunStatus.ESCALATED,
                stop_reason=reason.value,
                facts=facts.as_dict(),
                handoff=handoff,
                trace_id=trace_id,
                steps=steps,
            )

        while True:
            if self._stop_signal():
                return AgentRunResult(
                    RunStatus.STOPPED, "stop_signal", facts=facts.as_dict(), trace_id=trace_id
                )
            if reason := budget.exhausted_reason():
                return escalate(EscalationReason.BUDGET_EXHAUSTED, f"Budget hit ({reason}).")
            system = f"{self._system}\n\n{facts.render()}".strip()
            message = await self._llm.create(
                budget=budget,
                trace_id=trace_id,
                model=self._model,
                max_tokens=2048,
                system=system,
                tools=[t.definition for t in self._tools.values()],
                messages=messages,
            )
            messages.append({"role": "assistant", "content": message.content})
            tool_uses = [b for b in message.content if b.type == "tool_use"]
            if message.stop_reason != "tool_use" or not tool_uses:
                text = "".join(b.text for b in message.content if b.type == "text")
                return AgentRunResult(
                    RunStatus.COMPLETED,
                    "task_complete",
                    final_text=text,
                    facts=facts.as_dict(),
                    trace_id=trace_id,
                    steps=steps,
                )
            results = []
            for block in tool_uses:
                signature = f"{block.name}:{json.dumps(block.input, sort_keys=True)}"
                if signature == last_call:
                    return escalate(EscalationReason.NO_PROGRESS, f"Repeated call {block.name}.")
                last_call = signature
                result = await self._execute(block.name, block.input)
                steps.append(f"{block.name} -> {result.status.value}")
                is_error = result.status is ToolStatus.ACCESS_FAILURE
                consecutive_errors = consecutive_errors + 1 if is_error else 0
                results.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": result.to_model_content(),
                        "is_error": is_error,
                    }
                )
            if consecutive_errors >= self._max_errors:
                return escalate(EscalationReason.REPEATED_FAILURE, "Check the failing dependency.")
            messages.append({"role": "user", "content": results})

    async def _execute(self, name: str, tool_input: dict[str, Any]) -> ToolResult:
        tool = self._tools.get(name)
        if tool is None:
            return ToolResult.failure(
                "agent_loop",
                ToolError(
                    code="UNKNOWN_TOOL",
                    message=f"Tool '{name}' does not exist.",
                    suggested_action=f"Use one of: {sorted(self._tools)}",
                ),
            )
        try:
            return await tool.handler(tool_input)
        except Exception as exc:  # noqa: BLE001 - convert to contract, never crash the loop
            return ToolResult.failure(
                name,
                ToolError(
                    code="TOOL_EXCEPTION",
                    message=type(exc).__name__,
                    context={"input": tool_input},
                    suggested_action="Retry once; if it fails again, escalate.",
                    retryable=True,
                ),
            )
```

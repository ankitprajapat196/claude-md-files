# P08 — Single agent (agentic loop) 🟡 agent

The model picks tools in a bounded loop until done. Use only after P01-P07 and P10 cannot do the job.

**Use when:** steps are unpredictable, the model must choose tools from what it observes, or must try another approach after a failure.
**Avoid when:** you can write the steps down (P02/P04), or only one step needs tools (P10). Agents cost more, vary more and are harder to audit.
**Cost / audit:** unbounded without budgets; every turn and tool call is logged.

> Same pattern as `AgentLoop` in `examples/03`. This version runs on the project's current `MessagesAPI`. If `src/agents/common/agent_loop.py` exists, use it and keep these rules.

## Checklist coverage
| § | How this pattern meets it |
|---|---|
| 1 | Justify in the design why the steps cannot be fixed (otherwise P02/P04/P10). |
| 4 | Tool definitions say what / when / when NOT; strict schemas with enums; only this agent's tools; `tool_choice` set per step. |
| 5 | Every tool returns `ToolResult`; unknown tool or crash -> `access_failure` with code, message, suggested action, and `is_error` sent to the model. |
| 7 | Per-tool timeout; consecutive failures stop the run; unexpected model `stop_reason` (`max_tokens`, `refusal`) is a stop reason, not a silent answer. |
| 8 | 4 stop conditions in code: complete, error threshold, budget, stop signal; plus spinning (identical call repeated). |
| 9 | Tools allow-list; `HIGH_RISK` tools require approval (escalate before running). |
| 10 | Frozen system prompt sent with a cache breakpoint (`cached_system`); facts never go into `system`. Tool output is trimmed with a notice (`trim_tool_output`). Optional `ContextManager` (examples/06): before each call, checks the context budget and runs simple compaction (facts first, then summary; never mid tool round). For live long sessions use server-side compaction instead. |
| 12 | Every non-complete stop returns a 4-field `HandoffPayload`. |
| 13 | Tool output is wrapped as untrusted (`to_model_content`); never followed as instructions. |
| 15 | Log per tool call: name, status, latency (no inputs, may hold PII); per run: stop reason, turns, tokens. |

## Code
```python
"""Bounded agent loop: allow-listed tools, ToolResult contract, 4 stop conditions, handoff."""

import asyncio
import json
import logging
import time
from collections.abc import Awaitable, Callable
from enum import StrEnum
from typing import Any

from pydantic import BaseModel

from src.agents.common.budget import RunBudget
from src.agents.common.context import ContextManager, cached_system, trim_tool_output
from src.agents.common.escalation import EscalationReason, HandoffPayload
from src.agents.common.llm_client import MessagesAPI
from src.agents.common.tool_contract import ToolError, ToolResult, ToolStatus

logger = logging.getLogger("src.agents.agent_loop")
HIGH_RISK: frozenset[str] = frozenset({"place_order", "send_email"})
DEFAULT_MAX_TOOL_CHARS = 4000

# Example tool definition: what / when / when NOT, strict schema, enum for fixed values.
GET_PRICE_TOOL: dict[str, Any] = {
    "name": "get_price",
    "description": (
        "Return the latest close price for one stock ticker from the price database. "
        "Use when the user asks about a current or recent price. "
        "Do NOT use for news or company facts."
    ),
    "strict": True,
    "input_schema": {
        "type": "object",
        "properties": {
            "ticker": {"type": "string", "description": "Exchange ticker, e.g. INFY"},
            "period": {"type": "string", "enum": ["1d", "5d", "1m"]},
        },
        "required": ["ticker", "period"],
        "additionalProperties": False,
    },
}


class StopReason(StrEnum):
    """Why the loop ended."""

    COMPLETE = "complete"
    ERROR_THRESHOLD = "error_threshold"
    BUDGET = "budget"
    STOP_SIGNAL = "stop_signal"
    SPINNING = "spinning"
    MODEL_STOPPED = "model_stopped"
    NEEDS_APPROVAL = "needs_approval"


class AgentResult(BaseModel):
    """Final answer (complete runs) or a handoff (every other stop)."""

    stop_reason: StopReason
    answer: str | None = None
    turns: int
    steps: list[str]
    handoff: HandoffPayload | None = None


Tool = Callable[[dict[str, Any]], Awaitable[ToolResult]]


async def _call_tool(
    tool: Tool | None, name: str, args: dict[str, Any], timeout_s: float
) -> ToolResult:
    if tool is None:
        error = ToolError(
            code="UNKNOWN_TOOL",
            message=f"No tool named {name}",
            suggested_action="Use a listed tool.",
        )
        return ToolResult.failure("agent_loop", error)
    try:
        async with asyncio.timeout(timeout_s):
            return await tool(args)
    except Exception as exc:  # noqa: BLE001 - a crash becomes a structured result, never a loop crash
        error = ToolError(
            code="TOOL_ERROR",
            message=type(exc).__name__,
            suggested_action="Try another approach or finish with what you have.",
            retryable=isinstance(exc, TimeoutError),
        )
        return ToolResult.failure(name, error)


async def run_agent(
    api: MessagesAPI,
    *,
    model: str,
    system: str,
    tool_schemas: list[dict[str, Any]],
    tools: dict[str, Tool],
    question: str,
    budget: RunBudget,
    trace_id: str,
    context: ContextManager | None = None,
    stop_event: asyncio.Event | None = None,
    max_consecutive_errors: int = 3,
    tool_timeout_s: float = 15.0,
) -> AgentResult:
    """Run the tool loop until a stop condition fires.

    Args:
        api (MessagesAPI): ``AsyncAnthropic().messages`` (a fake in tests).
        model (str): Model id from ``Settings.model_for``.
        system (str): 5-section system prompt (stable -> cacheable).
        tool_schemas (list[dict]): Definitions for this agent's tools only.
        tools (dict[str, Tool]): Allow-list: tool name -> implementation.
        question (str): User task (kept verbatim for the handoff).
        budget (RunBudget): Turn/token limits enforced in code.
        trace_id (str): Correlation id for logs.
        context (ContextManager | None): Context budget + compaction (examples/06); None for
            short runs that stay well inside the window.
        stop_event (asyncio.Event | None): Set by the caller to stop the run.
        max_consecutive_errors (int): Error-threshold stop condition. Defaults to 3.
        tool_timeout_s (float): Per tool call timeout. Defaults to 15.

    Returns:
        result (AgentResult): Answer, or stop reason with a handoff.
    """
    max_tool_chars = context.policy.max_tool_chars if context else DEFAULT_MAX_TOOL_CHARS
    messages: list[dict[str, Any]] = [{"role": "user", "content": question}]
    steps: list[str] = []
    seen: set[str] = set()
    errors = 0

    def stop(reason: StopReason, hint: str, why: EscalationReason | None = None) -> AgentResult:
        logger.info(
            json.dumps(
                {
                    "event": "agent_stopped",
                    "trace_id": trace_id,
                    "reason": reason.value,
                    "turns": budget.turns,
                    "input_tokens": budget.input_tokens,
                }
            )
        )
        handoff = HandoffPayload(
            conversation_summary=f"{budget.turns} turns; last steps: {steps[-3:]}",
            triggering_question=question,
            attempted_actions=steps,
            suggested_next_step=hint,
            reason=why or EscalationReason.NO_PROGRESS,
            trace_id=trace_id,
        )
        return AgentResult(stop_reason=reason, turns=budget.turns, steps=steps, handoff=handoff)

    while True:
        if stop_event is not None and stop_event.is_set():
            return stop(StopReason.STOP_SIGNAL, "Run was stopped by the operator.")
        if reason := budget.exhausted_reason():
            return stop(
                StopReason.BUDGET, f"Budget hit ({reason}).", EscalationReason.BUDGET_EXHAUSTED
            )
        if context is not None:
            messages = await context.prepare(messages, system, budget)  # never mid tool round
        response = await api.create(
            model=model,
            max_tokens=1024,
            system=cached_system(system),  # frozen + cached; facts never go into system
            tools=tool_schemas,
            tool_choice={"type": "auto"},
            messages=messages,
        )
        budget.charge(response.usage.input_tokens, response.usage.output_tokens)
        calls = [b for b in response.content if b.type == "tool_use"]
        if response.stop_reason not in ("end_turn", "tool_use"):
            return stop(StopReason.MODEL_STOPPED, f"Model stopped with {response.stop_reason}.")
        if not calls:
            text = "".join(b.text for b in response.content if b.type == "text")
            logger.info(
                json.dumps({"event": "agent_complete", "trace_id": trace_id, "turns": budget.turns})
            )
            return AgentResult(
                stop_reason=StopReason.COMPLETE, answer=text, turns=budget.turns, steps=steps
            )
        messages.append({"role": "assistant", "content": response.content})
        results: list[dict[str, Any]] = []
        for call in calls:
            if call.name in HIGH_RISK:
                return stop(
                    StopReason.NEEDS_APPROVAL,
                    f"Approve {call.name} before it runs.",
                    EscalationReason.HIGH_RISK_ACTION,
                )
            key = f"{call.name}:{json.dumps(call.input, sort_keys=True)}"
            if key in seen:
                return stop(
                    StopReason.SPINNING, f"Repeated call to {call.name}; check the data source."
                )
            seen.add(key)
            started = time.perf_counter()
            outcome = await _call_tool(tools.get(call.name), call.name, call.input, tool_timeout_s)
            logger.info(
                json.dumps(
                    {
                        "event": "tool_call",
                        "trace_id": trace_id,
                        "tool": call.name,
                        "status": outcome.status.value,
                        "latency_ms": round((time.perf_counter() - started) * 1000, 1),
                    }
                )
            )
            steps.append(f"{call.name} -> {outcome.status.value}")
            failed = outcome.status is ToolStatus.ACCESS_FAILURE
            errors = errors + 1 if failed else 0
            content = trim_tool_output(outcome.to_model_content(), max_tool_chars)
            results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": call.id,
                    "content": content,
                    "is_error": failed,
                }
            )
        if errors >= max_consecutive_errors:
            return stop(
                StopReason.ERROR_THRESHOLD,
                "Check the failing dependency.",
                EscalationReason.REPEATED_FAILURE,
            )
        messages.append({"role": "user", "content": results})
```

## Tests (scripted fake messages from `tests/agents/fakes.py`)
- tool_use then text -> `complete`; the tool result sent back is wrapped as untrusted.
- Same call twice -> `spinning`; 3 failing calls in a row -> `error_threshold`; unknown tool -> `access_failure` with `is_error`.
- `max_turns=1` -> `budget`; event set -> `stop_signal`; `stop_reason="max_tokens"` -> `model_stopped`; high-risk tool -> `needs_approval` without running it.
- Every non-complete result has a 4-field handoff.
- System is sent as one cached block and never changes between turns; with a `ContextManager` and a tiny policy, the history is compacted to one message (original request + facts + summary) before the next call.

## Eval cases (§14)
Questions that need 0, 1 and several tools; a tool that returns empty vs fails; tool output containing "ignore previous instructions"; questions outside scope (must decline, not call tools). Grade in code: tools chosen (routing), stop reason, answer fields.

## Upgrade path
Several roles or contexts -> P11. The plan must change mid-run -> P14. Only one step needs an agent -> P10.

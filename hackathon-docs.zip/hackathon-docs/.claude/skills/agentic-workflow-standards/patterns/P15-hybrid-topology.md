# P15 — Hybrid topology (hub + pipeline + P2P) 🔴 multi-agent

The hub sits on top. Each spoke uses the topology that fits its work: a fixed pipeline, a peer pair, or a single call.

**Use when:** one system really contains different shapes of work (a fixed ingest pipeline, an author/critic exchange, open delegation), and eval evidence shows simpler topologies fail.
**Avoid when:** any single topology does the job. This is the most expensive pattern and the hardest to debug.
**Cost / audit:** hub calls + each spoke's cost; one trace id across all layers.

## Checklist coverage
| § | How this pattern meets it |
|---|---|
| 2 | Hybrid topology. Every spoke speaks the same typed, versioned `TaskMessage` / `ReportMessage` (P11), whatever runs inside. Internals never leak to the hub. |
| 5 | Pipeline spoke reports which stage failed; peer spoke reports why it did not agree. |
| 7 | Stage timeout inside the pipeline spoke; a spoke failure becomes a failed report and the hub decides (P11 error threshold). |
| 8 | Each layer has its own caps: hub `max_steps` / `max_failures`, pipeline stage timeout, peers `max_messages` / `max_hops` + their own budget slice. |
| 11 | Only the hub writes the ledger; spokes are stateless between tasks. |
| 15 | One `trace_id` is passed into every layer; each layer logs with it (P11, P13). |

## Code (reuses P11 as `src/agents/hub.py` and P13 as `src/agents/peers.py`)
```python
"""Hybrid topology: hub (P11) delegating to a pipeline spoke and a peer-pair spoke (P13)."""

import asyncio
import json
import logging
from collections.abc import Awaitable, Callable

from src.agents.common.budget import RunBudget
from src.agents.common.llm_client import LLMPort
from src.agents.hub import HubResult, ReportMessage, Spoke, TaskMessage, run_hub
from src.agents.peers import PeerMessage, PeerStop, llm_peer, run_peers

logger = logging.getLogger("src.agents.topology")

Stage = tuple[str, Callable[[str], Awaitable[str]]]


def pipeline_spoke(stages: list[Stage], trace_id: str, stage_timeout_s: float = 20.0) -> Spoke:
    """Spoke that runs fixed stages in order (pipeline topology).

    Args:
        stages (list[Stage]): ``(name, async str -> str)`` stages, run sequentially.
        trace_id (str): Correlation id shared with the hub.
        stage_timeout_s (float): Timeout per stage. Defaults to 20.

    Returns:
        spoke (Spoke): Handler for the hub.
    """

    async def run(task: TaskMessage) -> ReportMessage:
        value = task.input
        for name, stage in stages:
            try:
                async with asyncio.timeout(stage_timeout_s):
                    value = await stage(value)
            except Exception as exc:  # noqa: BLE001 - reported to the hub as a failed report
                logger.info(
                    json.dumps(
                        {"event": "pipeline_stage_failed", "trace_id": trace_id, "stage": name}
                    )
                )
                return ReportMessage(
                    task_id=task.task_id,
                    spoke=task.spoke,
                    status="failed",
                    error=f"{name}: {type(exc).__name__}",
                )
        return ReportMessage(task_id=task.task_id, spoke=task.spoke, status="ok", summary=value)

    return run


def peer_pair_spoke(llm: LLMPort, trace_id: str, max_messages: int = 8) -> Spoke:
    """Spoke where an author and a critic exchange messages until they agree (P2P topology).

    Args:
        llm (LLMPort): Model gateway.
        trace_id (str): Correlation id shared with the hub.
        max_messages (int): Message cap for the exchange. Defaults to 8.

    Returns:
        spoke (Spoke): Handler for the hub.
    """

    async def run(task: TaskMessage) -> ReportMessage:
        budget = RunBudget(max_turns=max_messages)  # this spoke's own budget slice
        peers = {
            "author": llm_peer(
                "author", "critic", "You write and improve the text.", llm, budget, trace_id
            ),
            "critic": llm_peer(
                "critic", "author", "You critique the text strictly.", llm, budget, trace_id
            ),
        }
        first = PeerMessage(sender="critic", to="author", kind="propose", body=task.input)
        outcome = await run_peers(
            peers,
            first,
            trace_id=trace_id,
            budget=budget,
            max_messages=max_messages,
            max_hops=max_messages,
        )
        proposals = [
            m.body for m in outcome.transcript if m.sender == "author" and m.kind == "propose"
        ]
        if outcome.stop_reason is not PeerStop.AGREED:
            return ReportMessage(
                task_id=task.task_id,
                spoke=task.spoke,
                status="failed",
                error=outcome.stop_reason.value,
            )
        return ReportMessage(
            task_id=task.task_id,
            spoke=task.spoke,
            status="ok",
            summary=proposals[-1] if proposals else task.input,
        )

    return run


async def run_topology(
    llm: LLMPort, ingest_stages: list[Stage], goal: str, *, trace_id: str
) -> HubResult:
    """Run the hub with a pipeline spoke and a peer-pair spoke.

    Args:
        llm (LLMPort): Model gateway.
        ingest_stages (list[Stage]): Stages of the fixed ingest pipeline spoke.
        goal (str): The overall goal.
        trace_id (str): Correlation id shared by every layer.

    Returns:
        result (HubResult): Hub result with the ledger of spoke reports.
    """
    spokes: dict[str, Spoke] = {
        "ingest": pipeline_spoke(ingest_stages, trace_id),
        "refine": peer_pair_spoke(llm, trace_id),
    }
    return await run_hub(llm, spokes, goal, trace_id=trace_id, max_steps=6, max_failures=2)
```

## Tests (fake `LLMPort`)
- Hub: delegate `ingest`, delegate `refine`, finish; the critic agrees -> two `ok` reports. The `refine` summary is the author's last proposal, not the critic's "agree" text.
- An ingest stage raises -> failed report naming the stage.
- Peers never agree -> `refine` report `failed` with the peer stop reason; the hub continues.

## Eval cases (§14)
End-to-end goals that use each spoke alone and both together; compare the cost and quality against P09/P11 on the same cases to justify keeping this topology.

## Upgrade path
None above this. If the topology keeps failing evals, simplify instead.

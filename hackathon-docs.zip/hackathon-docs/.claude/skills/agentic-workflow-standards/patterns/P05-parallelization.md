# P05 — Parallelization (fan-out / fan-in) 🟡 workflow

Independent branches run at once; a deterministic merge combines them; partial success is explicit.

**Use when:** branches do not depend on each other (price data + news, N documents, N sources). Latency = slowest branch, not the sum.
**Avoid when:** a branch needs another's output (P04), or the caller cannot handle partial results.
**Cost / audit:** same tokens, lower latency; every branch outcome is reported.

## Checklist coverage
| § | How this pattern meets it |
|---|---|
| 2 | Dependency graph: only branches with no edges between them fan out. |
| 5 | Each branch returns a `ToolResult` (success / empty_result / partial_result / access_failure). The fan-in says `complete` / `partial` / `failed`, lists failed branches with reasons and which are safe to retry. Empty is never treated as failure, and failure never as empty. |
| 7 | Per-branch timeout; transient errors retried with backoff + jitter (`retry_async`); one failing branch never cancels its siblings. |
| 9 | `min_success` enforced in code: below it the run is `failed`, not silently partial. |
| 12 | Provenance per value (`sources`); conflicting values are annotated, never silently overwritten. |
| 15 | Concurrency cap; one log line per branch (status, latency) under one trace id. |

## Code
```python
"""Fan-out / fan-in: per-branch timeout + transient retry, ToolResult contract, provenance merge."""

import asyncio
import json
import logging
import time
from collections.abc import Awaitable, Callable

from pydantic import BaseModel, Field

from src.agents.common.resilience import is_transient, retry_async
from src.agents.common.tool_contract import ToolError, ToolResult, ToolStatus

logger = logging.getLogger("src.agents.fan_out")


class MergedValue(BaseModel):
    """One merged field with the branches that reported it."""

    value: str
    sources: list[str]


class FanInResult(BaseModel):
    """Merged result; ``status`` is complete | partial | failed."""

    status: str
    merged: dict[str, MergedValue]
    conflicts: dict[str, dict[str, str]] = Field(default_factory=dict)
    empty: list[str] = Field(default_factory=list)
    failed: dict[str, ToolError] = Field(default_factory=dict)
    retry_safe: list[str] = Field(default_factory=list)


Branch = Callable[[], Awaitable[dict[str, str]]]


async def _run_branch(
    name: str, branch: Branch, sem: asyncio.Semaphore, timeout_s: float, trace_id: str
) -> ToolResult:
    async def attempt() -> dict[str, str]:
        async with asyncio.timeout(timeout_s):
            return await branch()

    started = time.perf_counter()
    async with sem:
        try:
            result = ToolResult.success(await retry_async(attempt, max_attempts=2), source=name)
        except Exception as exc:  # noqa: BLE001 - a branch failure must not kill its siblings
            transient = is_transient(exc)
            result = ToolResult.failure(
                name,
                ToolError(
                    code="BRANCH_TIMEOUT" if isinstance(exc, TimeoutError) else "BRANCH_FAILED",
                    message=type(exc).__name__,
                    context={"branch": name},
                    suggested_action="Retry later." if transient else "Check the source.",
                    retryable=transient,
                ),
            )
    logger.info(
        json.dumps(
            {
                "event": "branch_done",
                "trace_id": trace_id,
                "branch": name,
                "status": result.status.value,
                "latency_ms": round((time.perf_counter() - started) * 1000, 1),
            }
        )
    )
    return result


async def fan_out_fan_in(
    branches: dict[str, Branch],
    *,
    trace_id: str,
    timeout_s: float = 10.0,
    max_concurrency: int = 4,
    min_success: int = 1,
) -> FanInResult:
    """Run independent branches concurrently and merge their outputs with provenance.

    Args:
        branches (dict[str, Branch]): Branch name -> async callable returning flat fields.
        trace_id (str): Correlation id shared by all branches.
        timeout_s (float): Per-attempt timeout in seconds. Defaults to 10.
        max_concurrency (int): Max branches running at once. Defaults to 4.
        min_success (int): Fewer successful branches than this -> ``failed``. Defaults to 1.

    Returns:
        result (FanInResult): Merged fields, conflicts, empty and failed branches.
    """
    sem = asyncio.Semaphore(max_concurrency)
    names = list(branches)
    results = await asyncio.gather(
        *(_run_branch(n, branches[n], sem, timeout_s, trace_id) for n in names)
    )
    merged: dict[str, MergedValue] = {}
    conflicts: dict[str, dict[str, str]] = {}
    empty: list[str] = []
    failed: dict[str, ToolError] = {}
    for name, result in zip(names, results, strict=True):
        if result.status is ToolStatus.ACCESS_FAILURE and result.error is not None:
            failed[name] = result.error
        elif result.status is ToolStatus.EMPTY_RESULT:
            empty.append(name)
        else:
            for key, value in result.data.items():
                if key not in merged:
                    merged[key] = MergedValue(value=value, sources=[name])
                elif merged[key].value == value:
                    merged[key].sources.append(name)
                else:
                    known = {s: merged[key].value for s in merged[key].sources}
                    conflicts.setdefault(key, known)[name] = value
    status = "failed"
    if len(names) - len(failed) >= min_success:
        status = "partial" if failed else "complete"
    # Build the result last: Pydantic copies containers on construction.
    return FanInResult(
        status=status,
        merged=merged,
        conflicts=conflicts,
        empty=empty,
        failed=failed,
        retry_safe=[n for n, e in failed.items() if e.retryable],
    )
```

## Tests
- One branch raises `ValueError`, one sleeps past the timeout, one succeeds -> `partial`; the timeout is `retry_safe`, the `ValueError` is not.
- A branch returning `{}` is listed in `empty`, not in `failed`.
- Two branches disagree on a key -> both values in `conflicts`; agreeing branches -> both in `sources`.
- All fail, or fewer than `min_success` succeed -> `failed`.

## Eval cases (§14)
Every combination of {success, empty, transient failure, permanent failure} for 2 branches; conflicting values; slow branch at the timeout edge.

## Upgrade path
Branches are agents with their own tools -> P09. Work is discovered at runtime -> P12.

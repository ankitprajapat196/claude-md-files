# P04 — Sequential pipeline (checkpointed) 🟢 workflow / topology

Fixed stages in strict order; typed state; checkpoint after every stage; resume after a crash.

**Use when:** stages depend on each other, the run is slow (202 + job resource), and a crash must not redo finished or side-effecting work.
**Avoid when:** stages are independent (P05) or the order is decided at runtime (P14).
**Cost / audit:** no extra model calls; the checkpoint record is the audit trail.

## Checklist coverage
| § | How this pattern meets it |
|---|---|
| 2 | Pipeline topology: each stage has one job and a clear handoff (the typed state). |
| 5 | Run status enum (`running` / `completed` / `failed`); a failure is stored with an `ErrorEnvelope`. |
| 7 | Transient stage errors retried with backoff + jitter (`retry_async`); permanent errors are not retried. Each stage receives an idempotency key (`run_id:stage`) for its side effects. |
| 11 | Durable state outside the context window; checkpoint after each successful stage; resume skips completed stages. |
| 15 | Log per stage: trace id, stage, status, latency. |

## Code
```python
"""Sequential pipeline: checkpoint per stage, transient retry, idempotency key, resumable."""

import json
import logging
import time
from collections.abc import Awaitable, Callable
from enum import StrEnum
from typing import Protocol

from pydantic import BaseModel, Field

from src.agents.common.resilience import retry_async
from src.agents.common.tool_contract import ErrorEnvelope, Severity

logger = logging.getLogger("src.agents.pipeline")


class RunStatus(StrEnum):
    """Pipeline run status."""

    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class PipelineState(BaseModel):
    """Everything a run needs; persisted after every stage."""

    run_id: str
    status: RunStatus = RunStatus.RUNNING
    completed: list[str] = Field(default_factory=list)
    data: dict[str, str] = Field(default_factory=dict)
    error: ErrorEnvelope | None = None


Stage = tuple[str, Callable[[PipelineState, str], Awaitable[None]]]


class CheckpointStore(Protocol):
    """Durable checkpoint storage (DB row or JSON file in production)."""

    async def load(self, run_id: str) -> PipelineState | None:
        """Return the saved state, or None for a new run.

        Args:
            run_id (str): Run id.

        Returns:
            state (PipelineState | None): Saved state, or None for a new run.
        """

    async def save(self, state: PipelineState) -> None:
        """Persist the state.

        Args:
            state (PipelineState): State to persist.
        """


class InMemoryStore:
    """Test/demo store."""

    def __init__(self) -> None:
        """Create an empty store."""
        self._states: dict[str, PipelineState] = {}

    async def load(self, run_id: str) -> PipelineState | None:
        """Return a copy of the saved state, if any.

        Args:
            run_id (str): Run id.

        Returns:
            state (PipelineState | None): Saved state, or None for a new run.
        """
        state = self._states.get(run_id)
        return state.model_copy(deep=True) if state else None

    async def save(self, state: PipelineState) -> None:
        """Store a copy of the state.

        Args:
            state (PipelineState): State to persist.
        """
        self._states[state.run_id] = state.model_copy(deep=True)


async def run_pipeline(
    run_id: str, stages: list[Stage], store: CheckpointStore, *, max_attempts: int = 3
) -> PipelineState:
    """Run ``stages`` in order, resuming from the last checkpoint.

    Args:
        run_id (str): Stable run id (also the trace id and idempotency-key prefix).
        stages (list[Stage]): Ordered ``(name, async fn(state, idempotency_key))``; unique names.
        store (CheckpointStore): Durable store.
        max_attempts (int): Attempts per stage for transient errors. Defaults to 3.

    Returns:
        state (PipelineState): Final state (``completed``).

    Raises:
        Exception: The failing stage's error after the failure is checkpointed.
    """
    state = await store.load(run_id) or PipelineState(run_id=run_id)
    state.status, state.error = RunStatus.RUNNING, None
    for name, stage in stages:
        if name in state.completed:
            continue
        started = time.perf_counter()
        try:
            await retry_async(
                lambda s=stage, n=name: s(state, f"{run_id}:{n}"), max_attempts=max_attempts
            )
        except Exception as exc:
            state.status = RunStatus.FAILED
            state.error = ErrorEnvelope(
                error_type=type(exc).__name__,
                severity=Severity.FATAL,
                context={"stage": name},
                recovery_hint="Fix the cause, then rerun with the same run_id to resume.",
                step=name,
                trace_id=run_id,
            )
            await store.save(state)
            logger.error(json.dumps({"event": "stage_failed", "trace_id": run_id, "stage": name}))
            raise
        state.completed.append(name)
        await store.save(state)
        logger.info(
            json.dumps(
                {
                    "event": "stage_done",
                    "trace_id": run_id,
                    "stage": name,
                    "latency_ms": round((time.perf_counter() - started) * 1000, 1),
                }
            )
        )
    state.status = RunStatus.COMPLETED
    await store.save(state)
    return state
```

## Tests
- Stage 2 raises a permanent error -> state saved as `failed` with the envelope and only stage 1 completed; rerun runs stage 1 zero times and finishes.
- Stage raises `TimeoutError` once -> retried, run completes (patch `asyncio.sleep` to keep tests fast).
- Each stage receives `"<run_id>:<stage>"` as its idempotency key.

## Eval cases (§14)
Crash/resume at every stage boundary; transient vs permanent failure per stage; same run id twice must not repeat side effects.

## Upgrade path
Independent stages -> P05 inside a stage. Unknown step order -> P14.

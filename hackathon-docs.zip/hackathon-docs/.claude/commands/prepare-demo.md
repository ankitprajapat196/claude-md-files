---
description: Produce the demo script, pitch outline, and judges README from accepted features (demo-pitch-writer subagent)
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
Delegate to `demo-pitch-writer` with the status above pasted verbatim, plus paths of the PRD, implementation notes, test reports, agent designs, and mock-data reports. Wait for it.

## Output
Files written, the 60-second pitch, and the pre-demo checklist. Stop.

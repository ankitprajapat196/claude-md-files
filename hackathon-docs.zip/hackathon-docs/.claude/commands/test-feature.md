---
description: Write and run the full test suite for one implemented feature (F##) or agent build (AD##) and produce the test report (test-engineer subagent)
argument-hint: "<F##|AD##>"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Id = first token of `$ARGUMENTS`. It must already have an implementation note in `docs/05-implementation-notes/`; if not, say which command builds it and stop.
2. Delegate to `test-engineer` with `Feature ID: F##` (or `Design ID: AD##`), the plan/design path, and the implementation note path.
3. Wait for it to finish.

## Output
Show: Overall result (PASS/FAIL), totals, acceptance-criteria coverage, failures. If PASS: next `/approve-stage feature F##` (or `agent AD##`), ideally after `/review-feature`. If FAIL: suggest `/debug-issue` or `/revise-artifact feature F## <fixes>`. Then search for `DEP-MOCK` markers and, if any belong to this feature, show the mock-removal reminder from `.claude/rules/80-team-parallel-work.md` (it overrides the "approve" suggestion until the mocks are gone). Stop.

---
description: Root-cause and fix a bug, failing test, or error with the debugger subagent, then write a debug report
argument-hint: "<symptom, failing test id, or request_id>"
disable-model-invocation: true
---

## Task
Delegate to `debugger` with `Symptom: $ARGUMENTS` plus any failing test output or request id already in this conversation (paste it verbatim; the subagent cannot see this chat). Wait for it.

## Output
Root cause (1-2 lines), fix summary (files), verification result, report path. If it is blocked by an approved plan, show the proposed plan change and suggest `/revise-artifact plan F## <change>`. Stop.

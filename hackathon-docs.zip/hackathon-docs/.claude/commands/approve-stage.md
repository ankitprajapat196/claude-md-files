---
description: HUMAN ONLY - approve a stage artifact (prd, moscow, plan F##, feature F##, design AD##, agent AD##) so the next stage unlocks
argument-hint: "<prd|moscow|plan|feature|design|agent> [F##|AD##] [--force]"
disable-model-invocation: true
---

The `approval_gate.py` hook has already processed `/approve-stage $ARGUMENTS` before this message reached you, and its result is in the context as a system reminder starting with "APPROVED by the human".

## Task
- If that context is present: reply in at most 4 lines: what was approved, the file(s) covered, and the suggested next command exactly as the hook gave it.
- If a `feature` or `agent` was approved: search for `DEP-MOCK` markers. If any belong to it, add a warning: "This feature still runs on mocks of <F##>; it should not have been accepted yet." Then show the mock-removal reminder from `.claude/rules/80-team-parallel-work.md` and suggest `/revoke-stage feature <ID>` until the mocks are removed.
- If a `feature` or `agent` was approved and nothing is mocked: add one line: "Commit the code with `.workflow/approvals/` and push, so teammates who depend on <ID> can pull it."
- If that context is NOT present: say the approval hook did not run (check `/hooks`, workspace trust, and that `python3` works), and give the terminal fallback `python3 .claude/hooks/workflow_state.py approve $ARGUMENTS`. Do not try to record the approval yourself.

## Constraints
- Do not start the next stage. The human runs the next command.

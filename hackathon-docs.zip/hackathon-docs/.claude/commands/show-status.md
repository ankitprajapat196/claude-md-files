---
description: Show where the workflow is (approvals, features, in-progress work) and the exact next command
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

Summarise the status above in at most 8 lines: current stage, what is waiting for the human's review, anything stale ("changed-since-approval") and how to fix it, and the NEXT command exactly as shown. Then search for `DEP-MOCK` markers (Grep tool, read-only); if any exist, add the mock-removal reminder from `.claude/rules/80-team-parallel-work.md` for each mocked dependency. Do not run any other command.

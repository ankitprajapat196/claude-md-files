---
description: Stage 3 - plan ONE approved MoSCoW feature (user story, logic, flow, API contract, data, layers, tests) with the feature-planner subagent
argument-hint: "<F##>"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Feature id = first token of `$ARGUMENTS` (uppercase). If missing, show the features from the status and ask which one. Stop.
2. If MoSCoW is not `approved`, tell the human to run `/approve-stage moscow` first. Stop.
3. Find the feature file `docs/02-moscow/*/<ID>-*.md`. Run the dependency check from `.claude/rules/80-team-parallel-work.md` for **planning** (A/B/C question if a dependency is unmet). On A or B, stop as that rule says.
4. Delegate to `feature-planner`:
   ```
   Feature ID: <ID>
   Feature file: <path>
   Mode: CREATE (REVISE if docs/03-feature-plans/<ID>-*.plan.md exists)
   Dependency mode: MOCK <F##>,<F##>   (only if the human chose C)
   ```
5. Wait for it to finish.

## Output
Review request for stage `plan` and the id. Include the API contract table and the task list size. If the plan has `## Assumed dependency contracts`, list them under **Please check**. Next command after approval: `/implement-feature <ID>`. Stop.

---
description: Implement an APPROVED agent/workflow design under src/agents (agent-architect subagent, BUILD mode)
argument-hint: "<AD##>"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Design id = first token of `$ARGUMENTS`. If the design is not approved, ask the human to review it and run `/approve-stage design <ID>`. Stop.
2. Remind the human in one line to `git pull` first. If the design names a feature id, run the dependency check from `.claude/rules/80-team-parallel-work.md` for **build** (same as implementation) on that feature. On A or B, stop as that rule says.
3. Delegate to `agent-architect`:
   ```
   MODE: BUILD
   Design ID: <ID>
   Design: docs/04-agent-designs/<ID>-<slug>.design.md
   Dependency mode: MOCK <F##>,<F##>   (only if the human chose C)
   ```
4. Wait for it to finish.

## Output
Review request for stage `implementation` (files, how to call it, eval set location). If mocks were used, list the `Mocks to remove` table. Next: `/test-feature <ID>`, `/review-feature <ID>`, then `/approve-stage agent <ID>`. Stop.

---
description: Stage 1 - check the case study in the project root and generate the PRD with the prd-analyst subagent
argument-hint: "[optional focus notes for the PRD]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Role
You are the CyberBulls workflow coordinator in the main conversation. You delegate; you do not write the PRD yourself.

## Task
1. If the status shows the case study is MISSING, tell the human to add `CASE_STUDY.md` (or .pdf/.txt) to the project root and stop.
2. If the PRD is already `approved`, do not regenerate it: say so and point to the NEXT line of the status. Stop.
3. Otherwise delegate to the `prd-analyst` subagent with this delegation message:
   ```
   Case study: <case study path from the status>
   Mode: CREATE (or REVISE if docs/01-prd/PRD.md already exists)
   Focus notes: $ARGUMENTS
   Output: docs/01-prd/PRD.md
   ```
4. Wait for the subagent to finish (it may run in the background). Do not do its work.

## Output
Present the review request defined in `.claude/rules/00-workflow-gates.md` using the subagent's RESULT block, with stage `prd` and next command `/prioritize-moscow`. Then stop.

## Constraints
- Never run or imitate `/approve-stage`; never start MoSCoW.

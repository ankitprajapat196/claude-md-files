---
description: HUMAN ONLY - withdraw an approval (downstream approvals become stale) or park the in-progress feature with "active"
argument-hint: "<prd|moscow|plan|feature|design|agent|active> [F##|AD##]"
disable-model-invocation: true
---

The `approval_gate.py` hook has already processed `/revoke-stage $ARGUMENTS`; its result is in the context ("REVOKED by the human").

Reply in at most 3 lines: what was revoked, what is now stale or unlocked, and the NEXT command from the status in that context. If the context is missing, say the hook did not run and give the fallback `python3 .claude/hooks/workflow_state.py revoke $ARGUMENTS`. Do nothing else.

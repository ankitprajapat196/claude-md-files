---
description: UI track - plan the UI for ONE feature from its feature plan and DESIGN.md (ui-designer subagent, MODE UI-PLAN)
argument-hint: "<F##> [path/to/DESIGN.md]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Feature id = first token of `$ARGUMENTS`; design file = second token or `DESIGN.md` (project root).
2. Find `docs/03-feature-plans/<ID>-*.plan.md`. If it does not exist, tell the human to run `/plan-feature <ID>` first. Stop. If the plan exists but is not `approved`, say in one line that the UI plan will follow an unapproved plan and may need a redo.
3. If the design file does not exist, tell the human to add it (brand, colours, typography, spacing, component style, tone) and rerun. Stop.
4. If `docs/11-ui-designs/<ID>-*.ui-plan.md` already exists, tell the human to use `/revise-ui <ID> plan <feedback>` instead. Stop.
5. Delegate to `ui-designer`:
   ```
   MODE: UI-PLAN
   Feature ID: <ID>
   Plan: docs/03-feature-plans/<ID>-<slug>.plan.md
   Design file: <design file>
   ```
6. Wait for it to finish.

## Output
Review request from `.claude/rules/00-workflow-gates.md` for stage `ui-plan`, with these actions instead of `/approve-stage`:
- Approve and build: `/build-ui <ID>` (typing it is your approval of the UI plan)
- Request changes: `/revise-ui <ID> plan <your feedback>`

Then stop.

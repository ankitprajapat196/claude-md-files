---
description: Stage 2 - split the APPROVED PRD into independently testable Must/Should/Could/Won't features (moscow-prioritizer subagent)
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. If the PRD is not `approved` in the status, tell the human to review `docs/01-prd/PRD.md` and run `/approve-stage prd` (or `/revise-artifact prd <feedback>`). Stop.
2. Delegate to `moscow-prioritizer`:
   ```
   PRD: docs/01-prd/PRD.md
   Mode: CREATE (REVISE if docs/02-moscow/00-MOSCOW-INDEX.md exists)
   Output: docs/02-moscow/
   ```
3. Wait for it to finish.

## Output
Review request (`.claude/rules/00-workflow-gates.md`) for stage `moscow`, listing the features table (ID, name, category, depends on, effort) from the index. Next command after approval: `/plan-feature F01`. Stop.

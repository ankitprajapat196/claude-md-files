---
description: Stage 4 - implement ONE feature whose plan the human approved (feature-implementer subagent), following the production API checklist
argument-hint: "<F##> [full|backend|frontend]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Feature id = first token of `$ARGUMENTS`; scope = second token or `full`.
2. If the plan for that id is not `approved`, tell the human to review it and run `/approve-stage plan <ID>`. Stop.
3. Remind the human in one line to `git pull` first if they have not. Run the dependency check from `.claude/rules/80-team-parallel-work.md` for **implementation** (A/B/C question if a dependency is not accepted). On A or B, stop as that rule says.
4. Delegate to `feature-implementer`:
   ```
   Feature ID: <ID>
   Plan: docs/03-feature-plans/<ID>-<slug>.plan.md
   Scope: <scope>
   Mode: CREATE
   Dependency mode: MOCK <F##>,<F##>   (only if the human chose C)
   ```
   If the stage gate asks the human to confirm unmet dependencies, let the human decide (after choosing C, the answer is yes).
5. Wait for it to finish.

## Output
Review request for stage `implementation` (files changed, how to try it in 2 minutes, deviations from the plan). If mocks were used, list the `Mocks to remove` table and say: "Remove these mocks after testing, once the dependency is accepted; `/test-feature` will remind you with the exact command." Next commands: `/test-feature <ID>` and `/review-feature <ID>`, then `/approve-stage feature <ID>`. Stop.

---
description: Design an LLM agent or workflow for a need - recommends single call vs workflow vs agent vs hybrid with reasons, per the course checklist (agent-architect subagent, DESIGN mode)
argument-hint: "<what the agent/workflow must do> [for F##]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. If `$ARGUMENTS` is empty, ask what the agent/workflow should do. Stop.
2. If a feature id is mentioned, run the dependency check from `.claude/rules/80-team-parallel-work.md` for **design** (same as planning) on that feature. On A or B, stop as that rule says.
3. Delegate to `agent-architect`:
   ```
   MODE: DESIGN
   Need: $ARGUMENTS
   Feature ID: <F## if mentioned, else none>
   Output: docs/04-agent-designs/AD##-<slug>.design.md (next free number)
   Dependency mode: MOCK <F##>,<F##>   (only if the human chose C)
   ```
4. Wait for it to finish.

## Output
Review request for stage `design`: the recommendation (workflow/agent/hybrid) with the top 3 reasons, the architecture diagram, estimated cost/latency per run. Next command after approval: `/build-agent AD##`. Stop.

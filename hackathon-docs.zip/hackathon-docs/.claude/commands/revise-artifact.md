---
description: Send human feedback back to the owning subagent to revise a stage artifact (prd, moscow, plan F##, feature F##, design AD##, agent AD##)
argument-hint: "<prd|moscow|plan|feature|design|agent> [F##|AD##] <feedback>"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
Parse `$ARGUMENTS` as: stage, optional id (F## or AD##), then the feedback text (keep it verbatim).

Delegate to the owning subagent with the matching delegation message:

| Stage | Subagent | Delegation message |
|---|---|---|
| prd | prd-analyst | `Case study: <path>` / `Mode: REVISE` / `Feedback: <verbatim>` |
| moscow | moscow-prioritizer | `PRD: docs/01-prd/PRD.md` / `Mode: REVISE` / `Feedback: <verbatim>` |
| plan | feature-planner | `Feature ID: F##` / `Mode: REVISE` / `Feedback: <verbatim>` |
| feature | feature-implementer | `Feature ID: F##` / `Plan: <plan path>` / `Scope: full` / `Mode: REVISE` / `Feedback: <verbatim>` |
| design | agent-architect | `MODE: REVISE-DESIGN` / `Design ID: AD##` / `Feedback: <verbatim>` |
| agent | agent-architect | `MODE: REVISE-BUILD` / `Design ID: AD##` / `Feedback: <verbatim>` |

If the stage or id is missing or unknown, show the usage line and stop. Wait for the subagent to finish.

## Output
Present the review request from `.claude/rules/00-workflow-gates.md`. Add one line: "Any earlier approval of this artifact is now invalid (its content changed); approve again after review." Then stop.

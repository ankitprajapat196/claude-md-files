---
description: UI track - send human feedback to the ui-designer to revise a UI plan or a built UI for ONE feature
argument-hint: "<F##> <plan|build> <feedback>"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Parse `$ARGUMENTS` as: feature id, target (`plan` or `build`), then the feedback text (keep it verbatim). If any part is missing, show the usage line and stop.
2. Find `docs/11-ui-designs/<ID>-*.ui-plan.md`. If it does not exist, tell the human to run `/plan-ui <ID>` first. Stop. For `build`, the feature plan must be `approved`; if not, tell the human to run `/approve-stage plan <ID>`. Stop.
3. Delegate to `ui-designer`:
   ```
   MODE: REVISE-UI-PLAN   (or REVISE-UI-BUILD for "build")
   Feature ID: <ID>
   Plan: docs/03-feature-plans/<ID>-<slug>.plan.md
   UI plan: docs/11-ui-designs/<ID>-<slug>.ui-plan.md
   Design file: DESIGN.md
   Feedback: <verbatim>
   ```
4. Wait for it to finish.

## Output
Review request for stage `ui-plan` or `ui-build`. Next actions: for a plan, `/build-ui <ID>` or another `/revise-ui <ID> plan …`; for a build, another `/revise-ui <ID> build …` or `/test-feature <ID>`. Then stop.

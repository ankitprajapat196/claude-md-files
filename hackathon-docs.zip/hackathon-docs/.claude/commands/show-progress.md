---
description: Show MoSCoW completion - accepted/in-progress counts and effort-weighted % per Must/Should/Could bucket, plus per-feature stage
allowed-tools: Bash(python3 .claude/scripts/moscow_progress.py)
---

## MoSCoW progress
!`python3 .claude/scripts/moscow_progress.py`

Show the report above to the human as is. Then add at most 4 lines: whether the Must-have bucket is on track, any FAIL test results or "plan changed" rows and how to fix them, and the NEXT command exactly as shown. Do not run any other command and do not start any stage.

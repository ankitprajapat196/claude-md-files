---
description: UI track - build or improve the UI for ONE feature from its reviewed UI plan (ui-designer subagent, MODE UI-BUILD). Typing this command approves the UI plan.
argument-hint: "<F##> [page names to limit scope] [design=path/to/DESIGN.md]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Feature id = first token of `$ARGUMENTS`. Optional `design=<path>` (default `DESIGN.md`); any other tokens are the page scope.
2. Find `docs/11-ui-designs/<ID>-*.ui-plan.md`. If it does not exist, tell the human to run `/plan-ui <ID>` first. Stop. If its status is still `Draft`, tell the human the UI plan is unfinished and stop.
3. The feature plan for `<ID>` must be `approved` (application code is locked otherwise). If not, tell the human to run `/approve-stage plan <ID>`. Stop.
4. Remind the human in one line to `git pull` first if they have not.
5. Delegate to `ui-designer`:
   ```
   MODE: UI-BUILD
   Feature ID: <ID>
   Plan: docs/03-feature-plans/<ID>-<slug>.plan.md
   UI plan: docs/11-ui-designs/<ID>-<slug>.ui-plan.md
   Design file: <design file>
   Scope: <page names or "all">
   ```
6. Wait for it to finish.

## Output
Review request for stage `ui-build`: pages created or improved, files changed, the page URL, deviations from the UI plan. Actions:
- Request changes: `/revise-ui <ID> build <your feedback>`
- Then run: `/test-feature <ID>` and `/review-feature <ID>` (the UI is part of the feature), then `/approve-stage feature <ID>`

Then stop.

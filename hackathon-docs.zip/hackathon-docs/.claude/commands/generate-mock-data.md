---
description: Generate deterministic mock data (typical, edge, invalid, adversarial, demo story) plus a seed script (mock-data-generator subagent)
argument-hint: "<F## | entity names | demo>"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
Delegate to `mock-data-generator` with `Scope: $ARGUMENTS` (default `demo` if empty) and the relevant PRD/plan paths. Wait for it.

## Output
List the files created, record counts per case type, and the seed command. Mock data needs no approval; tell the human which stage command to continue with (from the status NEXT line). Stop.

#!/usr/bin/env python3
"""UserPromptExpansion hook for /approve-stage and /revoke-stage.

This event fires only when a HUMAN types the command, so approvals cannot be
forged by Claude or a subagent. The hook records (or revokes) the approval and
tells Claude what happened; on any problem it blocks the command with a reason.
"""

from __future__ import annotations

import shlex
import sys

from _hooklib import emit, read_input, ws


def block(reason: str) -> None:
    """Stop the command from running and show the reason to the user."""
    emit({"decision": "block", "reason": reason})


def context(text: str) -> None:
    """Let the command run with extra context for Claude."""
    emit({"hookSpecificOutput": {"hookEventName": "UserPromptExpansion", "additionalContext": text}})


def main() -> int:
    """Handle /approve-stage <stage> [ID] [--force] and /revoke-stage <stage> [ID]."""
    event = read_input()
    command = (event.get("command_name") or "").split(":")[-1]
    try:
        tokens = shlex.split(event.get("command_args") or "")
    except ValueError:
        tokens = (event.get("command_args") or "").split()
    force = "--force" in tokens
    tokens = [t for t in tokens if t != "--force"]
    if not tokens:
        block(
            "Usage: /approve-stage <prd|moscow|plan|feature|design|agent> [F01|AD01] [--force] "
            "or /revoke-stage <stage> [id] (or /revoke-stage active)."
        )
    stage, item_id = tokens[0], (tokens[1] if len(tokens) > 1 else None)
    try:
        if command == "revoke-stage":
            message = ws.revoke(stage, item_id)
            context(f"REVOKED by the human: {message}\n\n{ws.status_text()}")
        record = ws.approve(stage, item_id, force=force)
    except ws.WorkflowError as exc:
        block(f"Not approved: {exc}")
    nxt = ws.next_command_after(record["stage"], record["id"])
    context(
        f"APPROVED by the human ({record['approved_by']}): '{record['key']}' "
        f"covering {', '.join(record['files'])}"
        f"{' (FORCED despite test report)' if record['forced'] else ''}.\n"
        f"Suggested next command: {nxt}\n\n{ws.status_text()}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

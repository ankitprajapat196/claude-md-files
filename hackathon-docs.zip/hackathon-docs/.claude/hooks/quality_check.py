#!/usr/bin/env python3
"""PostToolUse hook on file writes: auto-format + enforce code standards.

Python under src/backend/:
  * ``ruff format`` + ``ruff check --fix`` when ruff is installed (config in
    src/backend/pyproject.toml), then remaining ruff findings are reported.
  * Layering (Controller -> Service -> DAO -> Model/Schema) import rules.
  * Google-style docstrings (Args/Returns/Raises) and type hints on public API.
  * No print(), bare except, eval/exec, or f-string SQL.
JS/HTML/CSS under template/frontend/: XSS-prone DOM APIs, fetch outside the
API client, inline handlers/scripts, raw colors outside tokens.css.

Errors -> exit 2 (Claude must fix). Warnings -> additionalContext (non-blocking).
"""

from __future__ import annotations

import ast
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

from _hooklib import project_relative, read_input, ws

LAYER_RULES = {
    "src/api/": (["src.dao", "src.models", "sqlalchemy"], "controllers call services only"),
    "src/services/": (["src.api", "fastapi", "starlette"], "services are HTTP-agnostic"),
    "src/dao/": (["src.api", "src.services", "fastapi"], "DAOs only persist data"),
    "src/schemas.py": (["src.api", "src.services", "src.dao", "sqlalchemy"], "schemas are pure DTOs"),
    "src/models/": (["src.api", "src.services", "src.schemas"], "models are ORM only"),
}
SQL_FSTRING = re.compile(r"(execute|text)\(\s*f[\"']", re.IGNORECASE)


def _imports(tree: ast.AST) -> list[str]:
    names = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names += [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            names.append(node.module)
    return names


def _public_api(tree: ast.Module) -> list[ast.AST]:
    """Top-level classes/functions and methods of top-level classes (nested closures are exempt)."""
    nodes: list[ast.AST] = []
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and not node.name.startswith("_"):
            nodes.append(node)
            nodes += [n for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            nodes.append(node)
    return nodes


def _raises(func: ast.AST) -> bool:
    return any(isinstance(n, ast.Raise) for n in ast.walk(func))


def check_python(path: Path, rel_path: str) -> tuple[list[str], list[str]]:
    """Return (errors, warnings) for one backend Python file."""
    errors: list[str] = []
    warnings: list[str] = []
    source = path.read_text(encoding="utf-8", errors="replace")
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        return [f"SyntaxError line {exc.lineno}: {exc.msg}"], []
    is_test = "/tests/" in f"/{rel_path}" or Path(rel_path).name.startswith("test_")

    for prefix, (banned, why) in LAYER_RULES.items():
        if rel_path.startswith(prefix):
            for name in _imports(tree):
                if any(name == b or name.startswith(b + ".") for b in banned):
                    errors.append(f"Layer violation: imports '{name}' ({why}).")

    if not is_test:
        if not ast.get_docstring(tree) and path.name != "__init__.py":
            errors.append("Missing module docstring.")
        for node in _public_api(tree):
            if isinstance(node, ast.ClassDef):
                if not ast.get_docstring(node):
                    errors.append(f"Class '{node.name}' (line {node.lineno}) needs a docstring.")
                continue
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name.startswith("_"):
                    continue
                doc = ast.get_docstring(node) or ""
                params = [a.arg for a in node.args.args + node.args.kwonlyargs if a.arg not in ("self", "cls")]
                where = f"'{node.name}' (line {node.lineno})"
                if not doc:
                    errors.append(f"Function {where} needs a Google-style docstring.")
                    continue
                if params and "Args:" not in doc:
                    errors.append(f"Docstring of {where} needs an 'Args:' section.")
                returns_value = node.returns is not None and not (
                    isinstance(node.returns, ast.Constant) and node.returns.value is None
                )
                if returns_value and "Returns:" not in doc and "Yields:" not in doc:
                    errors.append(f"Docstring of {where} needs a 'Returns:' section.")
                if _raises(node) and "Raises:" not in doc:
                    warnings.append(f"Docstring of {where} should list 'Raises:'.")
                missing = [a.arg for a in node.args.args + node.args.kwonlyargs
                           if a.annotation is None and a.arg not in ("self", "cls")]
                if missing:
                    errors.append(f"Function {where} is missing type hints for: {', '.join(missing)}.")
                if node.returns is None and node.name != "__init__":
                    errors.append(f"Function {where} is missing a return type hint.")
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler) and node.type is None:
            errors.append(f"Bare 'except:' on line {node.lineno}; catch specific exceptions.")
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in {"eval", "exec"}:
                errors.append(f"'{node.func.id}()' on line {node.lineno} is forbidden.")
            if node.func.id == "print" and not is_test:
                warnings.append(f"print() on line {node.lineno}; use the logger.")
    for lineno, line in enumerate(source.splitlines(), 1):
        if SQL_FSTRING.search(line):
            errors.append(f"Line {lineno}: SQL built with an f-string; use bound parameters.")
    return errors, warnings


def run_ruff(path: Path) -> list[str]:
    """Format + autofix with ruff if available; return remaining findings."""
    ruff = shutil.which("ruff")
    if not ruff:
        return []
    cwd = ws.ROOT / "src" / "backend"
    cwd = cwd if cwd.is_dir() else ws.ROOT
    try:
        subprocess.run([ruff, "format", str(path)], cwd=cwd, capture_output=True, timeout=30)
        subprocess.run([ruff, "check", "--fix", str(path)], cwd=cwd, capture_output=True, timeout=30)
        out = subprocess.run(
            [ruff, "check", "--output-format", "concise", str(path)],
            cwd=cwd, capture_output=True, text=True, timeout=30,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    return [ln for ln in out.stdout.splitlines() if ln.strip() and ":" in ln and "Found" not in ln][:25]


def check_frontend(path: Path, rel_path: str) -> tuple[list[str], list[str]]:
    """Return (errors, warnings) for one frontend file."""
    errors: list[str] = []
    warnings: list[str] = []
    text = path.read_text(encoding="utf-8", errors="replace")
    suffix = path.suffix.lower()
    if suffix == ".js":
        node = shutil.which("node")
        if node:
            res = subprocess.run([node, "--check", str(path)], capture_output=True, text=True, timeout=30)
            if res.returncode != 0:
                errors.append("JavaScript syntax error: " + (res.stderr.strip().splitlines() or ["?"])[-1])
        for lineno, line in enumerate(text.splitlines(), 1):
            if re.search(r"\.(innerHTML|outerHTML)\s*\+?=\s*(?!['\"]\s*['\"])", line):
                errors.append(f"Line {lineno}: innerHTML with dynamic content (XSS). Use h()/textContent.")
            if re.search(r"\b(eval|new\s+Function)\s*\(|document\.write\s*\(", line):
                errors.append(f"Line {lineno}: eval/new Function/document.write are forbidden.")
            if re.search(r"(?<![.\w])fetch\s*\(", line) and not rel_path.endswith("js/core/api-client.js"):
                errors.append(f"Line {lineno}: call the API through js/core/api-client.js, not fetch().")
            if re.search(r"localStorage\.setItem\([^)]*(token|password|secret)", line, re.IGNORECASE):
                warnings.append(f"Line {lineno}: avoid persisting secrets in localStorage.")
    elif suffix == ".html":
        if re.search(r"\son[a-z]+\s*=\s*[\"']", text, re.IGNORECASE):
            errors.append("Inline event handler (onclick=...) found; attach listeners in JS modules.")
        if re.search(r"<script(?![^>]*\bsrc=)[^>]*>\s*\S", text, re.IGNORECASE):
            errors.append("Inline <script> found; put code in js/ modules (CSP: script-src 'self').")
    elif suffix == ".css" and not rel_path.endswith("css/tokens.css"):
        raw = re.findall(r"#[0-9a-fA-F]{3,8}\b|rgba?\(", text)
        if raw:
            warnings.append(f"{len(raw)} raw color value(s); use var(--color-*) tokens from css/tokens.css.")
    return errors, warnings


def main() -> int:
    """Entry point."""
    event = read_input()
    tool_input = event.get("tool_input") or {}
    rel_path = project_relative(tool_input.get("file_path") or "", event.get("cwd"))
    if not rel_path:
        return 0
    path = ws.ROOT / rel_path
    if not path.is_file():
        return 0
    errors: list[str] = []
    warnings: list[str] = []
    if rel_path.startswith(("app/", "src/", "tests/")) and path.suffix == ".py":
        e, w = check_python(path, rel_path)
        errors += e
        warnings += w
        errors += [f"ruff: {line}" for line in run_ruff(path)]
    elif rel_path.startswith(("templates/", "static/")) and path.suffix in {".js", ".html", ".css"}:
        e, w = check_frontend(path, rel_path)
        errors += e
        warnings += w
    if errors:
        bullet = "\n".join(f"- {e}" for e in dict.fromkeys(errors))
        print(f"Quality gate: {len(errors)} issue(s) in {rel_path}. Fix them now:\n{bullet}", file=sys.stderr)
        return 2
    if warnings:
        print(json.dumps({
            "hookSpecificOutput": {
                "hookEventName": "PostToolUse",
                "additionalContext": f"Quality warnings for {rel_path}: " + " | ".join(warnings),
            }
        }))
    return 0


if __name__ == "__main__":
    sys.exit(main())

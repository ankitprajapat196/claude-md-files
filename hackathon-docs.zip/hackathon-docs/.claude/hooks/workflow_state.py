#!/usr/bin/env python3
"""Workflow state and approval ledger for the CyberBulls hackathon kit.

Standard library only (hooks must run on any laptop). Used by every hook and
runnable by HUMANS from a terminal:

    python3 .claude/hooks/workflow_state.py status
    python3 .claude/hooks/workflow_state.py approve plan F01   # fallback if /approve-stage fails
    python3 .claude/hooks/workflow_state.py bypass on|off       # emergency only

Approvals live in ``.workflow/approvals/<key>.json`` (commit them so teammates
see them). Each approval stores a SHA-256 of the approved artifact(s) and of its
upstream approval, so editing an approved file (or its parent) automatically
invalidates the approval until a human approves again.
"""

from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(os.environ.get("CLAUDE_PROJECT_DIR") or Path(__file__).resolve().parents[2])
DOCS = ROOT / "docs"
PRD_FILE = DOCS / "01-prd" / "PRD.md"
MOSCOW_DIR = DOCS / "02-moscow"
MOSCOW_INDEX = MOSCOW_DIR / "00-MOSCOW-INDEX.md"
PLANS_DIR = DOCS / "03-feature-plans"
DESIGNS_DIR = DOCS / "04-agent-designs"
IMPL_DIR = DOCS / "05-implementation-notes"
TEST_REPORTS_DIR = DOCS / "07-test-reports"
WORKFLOW_DIR = ROOT / ".workflow"
APPROVALS_DIR = WORKFLOW_DIR / "approvals"
LOCAL_DIR = WORKFLOW_DIR / "local"
ACTIVE_FILE = LOCAL_DIR / "active.json"
BYPASS_FILE = LOCAL_DIR / "BYPASS"

FEATURE_RE = re.compile(r"\bF\d{2}\b")
DESIGN_RE = re.compile(r"\bAD\d{2}\b")
CASE_STUDY_RE = re.compile(r"^case[-_ ]?study.*\.(md|txt|pdf)$", re.IGNORECASE)
CATEGORIES = [("must-have", "Must"), ("should-have", "Should"), ("could-have", "Could")]
STAGES = {
    "prd": {"id": None, "upstream": None},
    "moscow": {"id": None, "upstream": "prd"},
    "plan": {"id": "F", "upstream": "moscow"},
    "feature": {"id": "F", "upstream": "plan"},
    "design": {"id": "AD", "upstream": None},
    "agent": {"id": "AD", "upstream": "design"},
}
NEXT_AFTER = {
    "prd": "/prioritize-moscow",
    "moscow": "/plan-feature <first feature id shown in /show-status>",
    "plan": "/implement-feature {id}",
    "feature": "/show-status  (then /plan-feature for the next feature)",
    "design": "/build-agent {id}",
    "agent": "/show-status",
}


class WorkflowError(Exception):
    """A workflow rule was violated; the message is shown to the user."""


# ----------------------------------------------------------------- helpers
def rel(path: Path) -> str:
    """Return a POSIX path relative to the project root."""
    try:
        return path.resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def now_iso() -> str:
    """Return the current UTC time in ISO 8601."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def actor_name() -> str:
    """Best-effort human name for the approval record."""
    try:
        out = subprocess.run(
            ["git", "config", "user.name"], capture_output=True, text=True, timeout=2, cwd=ROOT
        )
        if out.stdout.strip():
            return out.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    try:
        return getpass.getuser()
    except Exception:  # noqa: BLE001
        return "unknown"


def hash_files(paths: list[Path]) -> str:
    """SHA-256 over relative paths + contents with normalized line endings."""
    digest = hashlib.sha256()
    for path in sorted(paths, key=rel):
        digest.update(rel(path).encode())
        digest.update(b"\0")
        digest.update(path.read_bytes().replace(b"\r\n", b"\n"))
        digest.update(b"\0")
    return digest.hexdigest()


def find_case_study() -> Path | None:
    """Return the case study file in the project root, if present."""
    for entry in sorted(ROOT.iterdir()):
        if entry.is_file() and CASE_STUDY_RE.match(entry.name):
            return entry
    return None


def normalize(stage: str, item_id: str | None) -> tuple[str, str | None]:
    """Validate a stage name and id; return (stage, ID)."""
    stage = (stage or "").strip().lower()
    if stage not in STAGES:
        raise WorkflowError(f"Unknown stage '{stage}'. Use one of: {', '.join(STAGES)}.")
    kind = STAGES[stage]["id"]
    if kind is None:
        return stage, None
    item_id = (item_id or "").strip().upper()
    pattern = FEATURE_RE if kind == "F" else DESIGN_RE
    if not pattern.fullmatch(item_id):
        example = "F01" if kind == "F" else "AD01"
        raise WorkflowError(f"Stage '{stage}' needs an id like {example}.")
    return stage, item_id


def key_for(stage: str, item_id: str | None) -> str:
    """Approval key, e.g. ``prd`` or ``plan-F01``."""
    return stage if item_id is None else f"{stage}-{item_id}"


def _single(directory: Path, pattern: str, label: str) -> Path:
    matches = sorted(directory.glob(pattern)) if directory.is_dir() else []
    if not matches:
        raise WorkflowError(f"Missing {label}: expected {rel(directory)}/{pattern}")
    if len(matches) > 1:
        names = ", ".join(rel(m) for m in matches)
        raise WorkflowError(f"More than one {label} matches {pattern}: {names}")
    return matches[0]


def artifact_files(stage: str, item_id: str | None) -> list[Path]:
    """Return the file(s) a human approves for this stage."""
    if stage == "prd":
        if not PRD_FILE.is_file():
            raise WorkflowError(f"Missing {rel(PRD_FILE)}. Run /start-workflow first.")
        return [PRD_FILE]
    if stage == "moscow":
        if not MOSCOW_INDEX.is_file():
            raise WorkflowError(f"Missing {rel(MOSCOW_INDEX)}. Run /prioritize-moscow first.")
        return sorted(p for p in MOSCOW_DIR.rglob("*.md") if p.is_file())
    if stage == "plan":
        return [_single(PLANS_DIR, f"{item_id}-*.plan.md", "feature plan")]
    if stage == "design":
        return [_single(DESIGNS_DIR, f"{item_id}-*.design.md", "agent design")]
    impl = _single(IMPL_DIR, f"{item_id}-*.impl.md", "implementation note")
    report = _single(TEST_REPORTS_DIR, f"{item_id}-*.test-report.md", "test report")
    return [impl, report]


def approval_path(key: str) -> Path:
    """Path of the approval record for ``key``."""
    return APPROVALS_DIR / f"{key}.json"


def load_approval(key: str) -> dict | None:
    """Load an approval record or ``None``."""
    path = approval_path(key)
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def upstream_key(stage: str, item_id: str | None) -> str | None:
    """Key of the approval this stage depends on."""
    parent = STAGES[stage]["upstream"]
    if parent is None:
        return None
    return key_for(parent, item_id if STAGES[parent]["id"] else None)


def check(stage: str, item_id: str | None, _depth: int = 0) -> tuple[bool, str]:
    """Return (valid, reason) for an approval, including upstream staleness."""
    key = key_for(stage, item_id)
    record = load_approval(key)
    if record is None:
        return False, f"'{key}' is not approved yet"
    try:
        current = hash_files(artifact_files(stage, item_id))
    except WorkflowError as exc:
        return False, f"'{key}' artifact problem: {exc}"
    if current != record.get("sha256"):
        return False, f"'{key}' changed after approval; review it and approve again"
    parent = upstream_key(stage, item_id)
    if parent and _depth < 5:
        p_stage, _, p_id = parent.partition("-")
        ok, reason = check(p_stage, p_id or None, _depth + 1)
        if not ok:
            return False, reason if reason.startswith("upstream") else f"upstream {reason}"
        parent_record = load_approval(parent) or {}
        if record.get("upstream", {}).get(parent) != parent_record.get("sha256"):
            return False, f"'{key}' was approved against an older '{parent}'; re-approve '{key}'"
    return True, f"'{key}' approved by {record.get('approved_by')} at {record.get('approved_at')}"


def is_approved(stage: str, item_id: str | None = None) -> bool:
    """Shortcut for ``check(...)[0]``."""
    return check(stage, item_id)[0]


def bypass_on() -> bool:
    """True when a human enabled emergency bypass for this clone."""
    return BYPASS_FILE.is_file()


# ----------------------------------------------------------------- features
def list_features() -> list[dict]:
    """Parse MoSCoW feature files into dicts ordered Must -> Should -> Could, then id."""
    features = []
    for folder, label in CATEGORIES:
        directory = MOSCOW_DIR / folder
        if not directory.is_dir():
            continue
        for path in sorted(directory.glob("F[0-9][0-9]-*.md")):
            text = path.read_text(encoding="utf-8", errors="replace")
            depends = []
            for line in text.splitlines():
                if "depends on" in line.lower():
                    depends = [d for d in FEATURE_RE.findall(line) if d != path.name[:3]]
                    break
            features.append(
                {
                    "id": path.name[:3],
                    "slug": path.stem[4:],
                    "category": label,
                    "path": rel(path),
                    "depends_on": depends,
                }
            )
    return features


def feature_by_id(feature_id: str) -> dict | None:
    """Return the MoSCoW feature with this id (Won't-have items are not features)."""
    return next((f for f in list_features() if f["id"] == feature_id), None)


def list_designs() -> list[str]:
    """Return agent design ids found on disk."""
    if not DESIGNS_DIR.is_dir():
        return []
    return sorted({p.name[:4] for p in DESIGNS_DIR.glob("AD[0-9][0-9]-*.design.md")})


# ----------------------------------------------------------------- active work
def get_active() -> dict | None:
    """Feature currently being implemented in THIS clone (one at a time)."""
    try:
        return json.loads(ACTIVE_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def set_active(feature_id: str) -> None:
    """Mark a feature as in progress in this clone."""
    LOCAL_DIR.mkdir(parents=True, exist_ok=True)
    ACTIVE_FILE.write_text(
        json.dumps({"kind": "feature", "id": feature_id, "started_at": now_iso()}), encoding="utf-8"
    )


def clear_active(feature_id: str | None = None) -> None:
    """Clear the active marker (optionally only if it matches ``feature_id``)."""
    active = get_active()
    if active and (feature_id is None or active.get("id") == feature_id):
        ACTIVE_FILE.unlink(missing_ok=True)


# ----------------------------------------------------------------- mutations
def _test_report_passed(paths: list[Path]) -> bool:
    for path in paths:
        if path.name.endswith(".test-report.md"):
            text = path.read_text(encoding="utf-8", errors="replace")
            match = re.search(r"overall result\W*\s*(PASS|FAIL)", text, re.IGNORECASE)
            return bool(match and match.group(1).upper() == "PASS")
    return False


def approve(stage: str, item_id: str | None, force: bool = False) -> dict:
    """Record a HUMAN approval. Raises WorkflowError with a user-facing reason."""
    stage, item_id = normalize(stage, item_id)
    if stage == "plan" and feature_by_id(item_id) is None:
        raise WorkflowError(f"{item_id} is not a Must/Should/Could feature in {rel(MOSCOW_DIR)}.")
    parent = upstream_key(stage, item_id)
    upstream = {}
    if parent:
        p_stage, _, p_id = parent.partition("-")
        ok, reason = check(p_stage, p_id or None)
        if not ok:
            raise WorkflowError(f"Cannot approve '{key_for(stage, item_id)}': {reason}.")
        upstream[parent] = (load_approval(parent) or {}).get("sha256")
    files = artifact_files(stage, item_id)
    if stage in {"feature", "agent"} and not force and not _test_report_passed(files):
        raise WorkflowError(
            "The test report does not say 'Overall result: PASS'. Fix and re-test, or run "
            f"/approve-stage {stage} {item_id} --force to accept anyway."
        )
    record = {
        "key": key_for(stage, item_id),
        "stage": stage,
        "id": item_id,
        "files": [rel(p) for p in files],
        "sha256": hash_files(files),
        "upstream": upstream,
        "approved_by": actor_name(),
        "approved_at": now_iso(),
        "forced": force,
    }
    APPROVALS_DIR.mkdir(parents=True, exist_ok=True)
    approval_path(record["key"]).write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    if stage == "feature":
        clear_active(item_id)
    return record


def revoke(stage: str, item_id: str | None) -> str:
    """Delete an approval record; downstream approvals become stale automatically."""
    if (stage or "").lower() == "active":
        clear_active()
        return "Cleared the active-feature marker for this clone."
    stage, item_id = normalize(stage, item_id)
    key = key_for(stage, item_id)
    path = approval_path(key)
    if not path.is_file():
        raise WorkflowError(f"'{key}' has no approval to revoke.")
    path.unlink()
    return f"Revoked approval '{key}'. Anything approved on top of it is now stale."


def next_command_after(stage: str, item_id: str | None) -> str:
    """Suggested command after approving ``stage``."""
    return NEXT_AFTER[stage].format(id=item_id or "")


# ----------------------------------------------------------------- status
def next_step() -> tuple[str, str]:
    """Return (explanation, command) for what the team should do next."""
    if find_case_study() is None:
        return "Add your case study to the project root as CASE_STUDY.md (or .pdf/.txt).", ""
    if not PRD_FILE.is_file():
        return "Generate the PRD from the case study.", "/start-workflow"
    if not is_approved("prd"):
        return f"Review {rel(PRD_FILE)}, then approve or request changes.", "/approve-stage prd"
    if not MOSCOW_INDEX.is_file():
        return "Split the approved PRD into MoSCoW features.", "/prioritize-moscow"
    if not is_approved("moscow"):
        return f"Review {rel(MOSCOW_DIR)}/, then approve or request changes.", "/approve-stage moscow"
    active = get_active()
    if active:
        fid = active["id"]
        if not list(IMPL_DIR.glob(f"{fid}-*.impl.md")):
            return f"{fid} implementation is in progress in this clone.", f"/implement-feature {fid}"
        if not list(TEST_REPORTS_DIR.glob(f"{fid}-*.test-report.md")):
            return f"{fid} is in progress here. Test it before acceptance.", f"/test-feature {fid}"
        return f"Review {fid}'s test report and review, then accept it.", f"/approve-stage feature {fid}"
    for feature in list_features():
        fid = feature["id"]
        if is_approved("feature", fid):
            continue
        if not list(PLANS_DIR.glob(f"{fid}-*.plan.md")):
            return f"Plan the next feature ({fid}, {feature['category']} have).", f"/plan-feature {fid}"
        if not is_approved("plan", fid):
            return f"Review the {fid} plan, then approve or request changes.", f"/approve-stage plan {fid}"
        if not list(IMPL_DIR.glob(f"{fid}-*.impl.md")):
            return f"Implement {fid}.", f"/implement-feature {fid}"
        if not list(TEST_REPORTS_DIR.glob(f"{fid}-*.test-report.md")):
            return f"Test {fid}.", f"/test-feature {fid}"
        return f"Review {fid}'s test report, then accept it.", f"/approve-stage feature {fid}"
    return "All planned features are accepted. Prepare the demo.", "/prepare-demo"


def _mark(stage: str, item_id: str | None = None) -> str:
    ok, reason = check(stage, item_id)
    if ok:
        return "approved"
    return "changed-since-approval" if "changed" in reason or "older" in reason else "pending"


def status_dict() -> dict:
    """Machine-readable status."""
    case = find_case_study()
    features = []
    for f in list_features():
        fid = f["id"]
        features.append(
            {
                **f,
                "plan": _mark("plan", fid) if list(PLANS_DIR.glob(f"{fid}-*.plan.md")) else "missing",
                "implemented": bool(list(IMPL_DIR.glob(f"{fid}-*.impl.md"))),
                "tested": bool(list(TEST_REPORTS_DIR.glob(f"{fid}-*.test-report.md"))),
                "accepted": is_approved("feature", fid),
            }
        )
    message, command = next_step()
    return {
        "case_study": rel(case) if case else None,
        "prd": _mark("prd") if PRD_FILE.is_file() else "missing",
        "moscow": _mark("moscow") if MOSCOW_INDEX.is_file() else "missing",
        "features": features,
        "agent_designs": [
            {"id": d, "design": _mark("design", d), "accepted": is_approved("agent", d)}
            for d in list_designs()
        ],
        "active": get_active(),
        "gates": "BYPASSED" if bypass_on() else "ON",
        "next": {"message": message, "command": command},
    }


def status_text() -> str:
    """Human-readable status used by SessionStart and /show-status."""
    s = status_dict()
    lines = [
        "CyberBulls workflow status",
        f"- Case study: {s['case_study'] or 'MISSING (add CASE_STUDY.md to the project root)'}",
        f"- PRD: {s['prd']}",
        f"- MoSCoW: {s['moscow']}",
    ]
    if s["features"]:
        lines.append("- Features (id | priority | plan | built | tested | accepted):")
        for f in s["features"]:
            lines.append(
                f"    {f['id']} {f['slug']} | {f['category']} | {f['plan']} | "
                f"{'yes' if f['implemented'] else 'no'} | {'yes' if f['tested'] else 'no'} | "
                f"{'YES' if f['accepted'] else 'no'}"
            )
    for d in s["agent_designs"]:
        lines.append(f"- Agent design {d['id']}: design {d['design']}, accepted {d['accepted']}")
    if s["active"]:
        lines.append(f"- In progress in this clone: {s['active']['id']} (since {s['active']['started_at']})")
    lines.append(f"- Approval gates: {s['gates']}")
    nxt = s["next"]
    lines.append(f"NEXT: {nxt['message']}" + (f"  ->  {nxt['command']}" if nxt["command"] else ""))
    return "\n".join(lines)


# ----------------------------------------------------------------- CLI
def main(argv: list[str]) -> int:
    """Command-line entry point for humans."""
    parser = argparse.ArgumentParser(description="CyberBulls workflow state")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status")
    sub.add_parser("json")
    for name in ("approve", "revoke", "check"):
        p = sub.add_parser(name)
        p.add_argument("stage")
        p.add_argument("item_id", nargs="?")
        if name == "approve":
            p.add_argument("--force", action="store_true")
    by = sub.add_parser("bypass")
    by.add_argument("mode", choices=["on", "off"])
    args = parser.parse_args(argv)
    try:
        if args.cmd == "status":
            print(status_text())
        elif args.cmd == "json":
            print(json.dumps(status_dict(), indent=2))
        elif args.cmd == "approve":
            record = approve(args.stage, args.item_id, args.force)
            print(f"Approved {record['key']}. Next: {next_command_after(record['stage'], record['id'])}")
        elif args.cmd == "revoke":
            print(revoke(args.stage, args.item_id))
        elif args.cmd == "check":
            stage, item_id = normalize(args.stage, args.item_id)
            ok, reason = check(stage, item_id)
            print(reason)
            return 0 if ok else 1
        elif args.cmd == "bypass":
            LOCAL_DIR.mkdir(parents=True, exist_ok=True)
            if args.mode == "on":
                BYPASS_FILE.write_text(now_iso(), encoding="utf-8")
                print("Gates BYPASSED for this clone. Turn off with: bypass off")
            else:
                BYPASS_FILE.unlink(missing_ok=True)
                print("Gates ON.")
    except WorkflowError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

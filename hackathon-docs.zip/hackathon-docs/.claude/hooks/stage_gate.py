#!/usr/bin/env python3
"""PreToolUse hook on the Agent tool: a subagent may start only if its stage is unlocked.

This is the deterministic enforcement of "no stage moves without human approval".
Prompts guide; this code enforces.
"""

from __future__ import annotations

import re
import sys

from _hooklib import ask_user, deny_tool, read_input, ws


def feature_id_from(prompt: str) -> str | None:
    """Extract the first feature id (F01) from the delegation prompt."""
    match = re.search(r"Feature ID:\s*(F\d{2})", prompt) or ws.FEATURE_RE.search(prompt)
    return match.group(1) if match else None


def design_id_from(prompt: str) -> str | None:
    """Extract the first agent design id (AD01) from the delegation prompt."""
    match = re.search(r"Design ID:\s*(AD\d{2})", prompt) or ws.DESIGN_RE.search(prompt)
    return match.group(1) if match else None


def require(stage: str, item_id: str | None, hint: str) -> None:
    """Deny unless the given approval is valid."""
    ok, reason = ws.check(stage, item_id)
    if not ok:
        if "not approved yet" in reason and not reason.startswith("upstream"):
            deny_tool(f"Stage locked: {reason}. {hint}")
        deny_tool(
            f"Stage locked: {reason}. Re-review and re-approve the changed artifact(s) in "
            "order (PRD -> MoSCoW -> plan); run /show-status to see which."
        )


def gate(agent: str, prompt: str) -> None:
    """Apply the gate for one subagent type (returns normally when allowed)."""
    if agent == "prd-analyst":
        if ws.find_case_study() is None:
            deny_tool("No case study found. Add CASE_STUDY.md (or .pdf/.txt) to the project root.")
        return
    if agent in {"moscow-prioritizer", "mock-data-generator", "demo-pitch-writer"}:
        require("prd", None, "The human must review the PRD and run /approve-stage prd.")
        return
    if agent == "feature-planner":
        require("moscow", None, "The human must run /approve-stage moscow first.")
        fid = feature_id_from(prompt)
        if not fid or ws.feature_by_id(fid) is None:
            deny_tool("Pass 'Feature ID: F##' for a Must/Should/Could feature from docs/02-moscow/.")
        return
    if agent in {"feature-implementer", "test-engineer", "code-reviewer"}:
        fid = feature_id_from(prompt)
        if fid is None:
            if agent == "feature-implementer":
                deny_tool("Pass 'Feature ID: F##'. Implementation is one approved feature at a time.")
            return  # ad-hoc review/test without a feature id is allowed
        require("plan", fid, f"The human must run /approve-stage plan {fid}.")
        if agent == "feature-implementer":
            active = ws.get_active()
            if active and active.get("id") != fid and not ws.is_approved("feature", active["id"]):
                deny_tool(
                    f"{active['id']} is still in progress in this clone. Finish and accept it "
                    f"(/approve-stage feature {active['id']}) or the human can run "
                    "/revoke-stage active to park it."
                )
            feature = ws.feature_by_id(fid) or {}
            missing = [d for d in feature.get("depends_on", []) if not ws.is_approved("feature", d)]
            ws.set_active(fid)
            if missing:
                ask_user(
                    f"{fid} depends on {', '.join(missing)} which is not accepted yet. "
                    "Continue anyway (e.g. a teammate is building it in parallel)?"
                )
        return
    if agent == "agent-architect":
        if re.search(r"MODE:\s*(REVISE-)?BUILD", prompt):
            did = design_id_from(prompt)
            if not did:
                deny_tool("BUILD mode needs 'Design ID: AD##'.")
            require("design", did, f"The human must run /approve-stage design {did}.")
        return


def main() -> int:
    """Entry point."""
    event = read_input()
    if ws.bypass_on():
        return 0
    tool_input = event.get("tool_input") or {}
    agent = str(tool_input.get("subagent_type") or "")
    prompt = str(tool_input.get("prompt") or "")
    gate(agent, prompt)
    return 0


if __name__ == "__main__":
    sys.exit(main())

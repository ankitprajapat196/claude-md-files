#!/usr/bin/env python3
"""PreToolUse hook on Bash: block destructive, secret-leaking, and gate-bypassing commands."""

from __future__ import annotations

import re
import sys

from _hooklib import deny_tool, read_input

RULES: list[tuple[str, str]] = [
    (r"\brm\s+-[a-zA-Z]*[rR][a-zA-Z]*\s+(/|~|\*|\.{1,2}(\s|$)|\$HOME)", "broad recursive delete"),
    (r"\bgit\s+push\b.*(\s--force\b|\s-f\b|--force-with-lease)", "force push"),
    (r"\bgit\s+reset\s+--hard\b", "hard reset (loses work)"),
    (r"\bgit\s+clean\s+-[a-zA-Z]*f", "git clean (deletes untracked files)"),
    (r"\b(DROP\s+(DATABASE|SCHEMA|TABLE)|TRUNCATE\s+TABLE)\b", "destructive SQL (run it yourself)"),
    (r"\b(curl|wget)\b[^|]*\|\s*(ba|z)?sh\b", "piping a download into a shell"),
    (r"\bsudo\b", "sudo"),
    (r"\bchmod\s+-R\s+777\b", "world-writable permissions"),
    (r"(^|[\s;&|])(cat|less|more|head|tail|bat|type)\s+[^|;&]*\.env(\s|$|[;&|])", "reading .env"),
    (r"(^|[\s;&|])(printenv|env)(\s*$|\s*[;&|])", "dumping environment variables"),
    (r"echo\s+[^|;&]*\$\{?[A-Z_]*(KEY|TOKEN|SECRET|PASSWORD)", "printing a secret"),
    (r"workflow_state\.py\s+(approve|revoke|bypass)", "approvals are human-only (/approve-stage)"),
    (r"\.workflow/(approvals|local)", "the approval ledger is human-only"),
    (r"(>|\btee\b|\bsed\s+-i|\bcp\b|\bmv\b|\brm\b)[^;&|]*\.claude/(hooks|settings\.json)", "editing hooks/settings"),
]


def main() -> int:
    """Entry point."""
    event = read_input()
    command = str((event.get("tool_input") or {}).get("command") or "")
    for pattern, label in RULES:
        if re.search(pattern, command, flags=re.IGNORECASE):
            deny_tool(
                f"Blocked by guard_bash ({label}). If this is truly needed, the human should run "
                "it manually in their own terminal."
            )
    return 0


if __name__ == "__main__":
    sys.exit(main())

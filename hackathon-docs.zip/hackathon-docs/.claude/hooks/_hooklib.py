"""Tiny shared helpers for hook scripts (stdin JSON in, decision JSON out)."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import workflow_state as ws  # noqa: E402


def read_input() -> dict[str, Any]:
    """Read the hook event JSON from stdin (empty dict on bad input)."""
    try:
        return json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return {}


def emit(payload: dict[str, Any]) -> None:
    """Print one JSON object to stdout and exit 0."""
    print(json.dumps(payload))
    sys.exit(0)


def deny_tool(reason: str) -> None:
    """PreToolUse: block the tool call; Claude sees the reason."""
    emit(
        {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": reason,
            }
        }
    )


def ask_user(reason: str) -> None:
    """PreToolUse: ask the human to confirm this tool call."""
    emit(
        {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "ask",
                "permissionDecisionReason": reason,
            }
        }
    )


def project_relative(path_str: str, cwd: str | None) -> str | None:
    """Return a POSIX path relative to the project root, or None if outside it."""
    if not path_str:
        return None
    path = Path(path_str)
    if not path.is_absolute():
        path = Path(cwd or ws.ROOT) / path
    try:
        return path.resolve().relative_to(ws.ROOT.resolve()).as_posix()
    except (ValueError, OSError):
        return None

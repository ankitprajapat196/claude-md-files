#!/usr/bin/env python3
"""SessionStart hook: inject the current workflow status as context (plain stdout)."""

from __future__ import annotations

import sys

from _hooklib import read_input, ws


def main() -> int:
    """Print status so Claude starts every session knowing the stage and next command."""
    read_input()
    try:
        print(ws.status_text())
        print(
            "Workflow rule: stages advance only after the human runs /approve-stage. "
            "After any stage finishes, present the review request and stop."
        )
    except Exception as exc:  # noqa: BLE001 - never break session start
        print(f"(workflow status unavailable: {exc})")
    return 0


if __name__ == "__main__":
    sys.exit(main())

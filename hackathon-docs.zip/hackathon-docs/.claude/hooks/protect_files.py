#!/usr/bin/env python3
"""PreToolUse hook on file writes: protected files + per-agent write scopes.

- Secrets, the approval ledger, hooks, settings, and the case study are never
  edited by Claude.
- Each subagent may only write inside its own folders (least privilege).
- Application code under src/ and template/frontend/ cannot be written before
  at least one feature plan or agent design has been approved by the human.
"""

from __future__ import annotations

import fnmatch
import sys

from _hooklib import deny_tool, project_relative, read_input, ws

ALWAYS_PROTECTED = [
    ".env",
    ".env.*",
    "*/.env",
    "*/.env.*",
    ".workflow/*",
    ".claude/hooks/*",
    ".claude/settings.json",
    ".git/*",
]
ALLOWED_EXCEPTIONS = [".env.example"]

AGENT_SCOPES = {
    "prd-analyst": ["docs/01-prd/*"],
    "moscow-prioritizer": ["docs/02-moscow/*"],
    "feature-planner": ["docs/03-feature-plans/*"],
    "agent-architect": [
        "docs/04-agent-designs/*",
        "docs/05-implementation-notes/AD*",
        "src/backend/*",
    ],
    "feature-implementer": ["src/*", "template/frontend/*", "docs/05-implementation-notes/F*", "app/*", "templates/*", "static/*", "migrations/*", "alembic.ini", "package.json", "tests/*"],
    "code-reviewer": ["docs/06-reviews/*"],
    "test-engineer": ["tests/*", "docs/07-test-reports/*"],
    "mock-data-generator": [
        "src/backend/mock_data/*",
        "src/backend/scripts/*",
        "docs/08-mock-data/*",
    ],
    "debugger": ["src/*", "template/frontend/*", "docs/09-debug-reports/*"],
    "demo-pitch-writer": ["docs/10-demo/*"],
}
CODE_AREAS = ["app/*", "src/*", "templates/*", "static/*"]
DATA_AREAS = ["src/backend/mock_data/*"]  # mock data is allowed once the PRD is approved


def matches(path: str, patterns: list[str]) -> bool:
    """fnmatch where '*' also crosses '/' (so 'src/*' covers nested files)."""
    return any(fnmatch.fnmatch(path, p) for p in patterns)


def planning_done() -> bool:
    """True once any feature plan or agent design has a valid human approval."""
    plans = [f["id"] for f in ws.list_features() if ws.is_approved("plan", f["id"])]
    designs = [d for d in ws.list_designs() if ws.is_approved("design", d)]
    return bool(plans or designs)


def main() -> int:
    """Entry point."""
    event = read_input()
    tool_input = event.get("tool_input") or {}
    raw = tool_input.get("file_path") or tool_input.get("notebook_path") or ""
    path = project_relative(raw, event.get("cwd"))
    if path is None:
        return 0
    exempt = any(path == e or path.endswith("/" + e) for e in ALLOWED_EXCEPTIONS)
    if matches(path, ALWAYS_PROTECTED) and not exempt:
        deny_tool(
            f"'{path}' is protected (secrets, approval ledger, hooks, settings, git). "
            "Ask the human to change it manually if really needed."
        )
    if ws.find_case_study() and path == ws.rel(ws.find_case_study()):
        deny_tool("The case study is read-only input. Record clarifications in the PRD instead.")
    if ws.bypass_on():
        return 0
    agent = event.get("agent_type") or ""
    scopes = AGENT_SCOPES.get(agent)
    if scopes is not None and not matches(path, scopes):
        deny_tool(f"Subagent '{agent}' may only write to: {', '.join(scopes)}. Refused: '{path}'.")
    if matches(path, CODE_AREAS) and not matches(path, DATA_AREAS) and not planning_done():
        deny_tool(
            "No feature plan or agent design is approved yet, so application code cannot be "
            "written. Finish PRD -> MoSCoW -> plan approvals first (see /show-status)."
        )
    return 0


if __name__ == "__main__":
    sys.exit(main())

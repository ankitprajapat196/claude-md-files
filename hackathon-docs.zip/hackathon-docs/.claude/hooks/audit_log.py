#!/usr/bin/env python3
"""SubagentStart/SubagentStop hook: append an audit line to .workflow/local/activity.log."""

from __future__ import annotations

import json
import sys

from _hooklib import read_input, ws


def main() -> int:
    """Log which subagent ran and when (never blocks)."""
    event = read_input()
    try:
        ws.LOCAL_DIR.mkdir(parents=True, exist_ok=True)
        line = {
            "ts": ws.now_iso(),
            "event": event.get("hook_event_name"),
            "agent_type": event.get("agent_type"),
            "agent_id": event.get("agent_id"),
            "session_id": event.get("session_id"),
        }
        with (ws.LOCAL_DIR / "activity.log").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(line) + "\n")
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())

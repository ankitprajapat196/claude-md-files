# Mini Case Study: Stock Insight Agent (Indian Stock Market)

## Problem

Retail investors want a quick, simple explanation of a stock without reading charts, news and results separately.

Build a small system where a user enters an NSE stock symbol (e.g., `TCS`). Multiple agents then gather data and produce a **one-page Stock Insight Report**.

The report gives information only. It must contain **no buy/sell advice** (SEBI rule).

## Required APIs (5)

| # | API | Purpose |
|---|---|---|
| 1 | `GET /stocks` | List supported stocks (keep it to 5–10 NSE symbols) |
| 2 | `GET /stocks/{symbol}/price` | Latest price and 1-month price trend |
| 3 | `GET /stocks/{symbol}/news` | Recent news headlines for the stock |
| 4 | `POST /reports` | Body `{ "symbol": "TCS" }`; starts the orchestrator and returns `report_id` |
| 5 | `GET /reports/{report_id}` | Report status and the final report |

APIs 2 and 3 can return mock JSON data. Live data is optional.

## Agents (1 Orchestrator + 3 Agents)

| Agent | Job |
|---|---|
| **Orchestrator** | Receives the symbol, calls the three agents, combines their results, and handles failures |
| **Price Agent** | Uses the price API and explains the trend in 2–3 lines |
| **News Agent** | Uses the news API and summarises the key news in 2–3 lines |
| **Report Writer Agent** | Writes the final report from both outputs and checks that it contains no advice |

## Workflow

```mermaid
flowchart LR
    U["POST /reports"] --> O["Orchestrator"]
    O --> P["Price Agent"]
    O --> N["News Agent"]
    P --> O
    N --> O
    O --> W["Report Writer Agent"]
    W --> R["GET /reports/id"]
```

## Rules

- No buy/sell/hold advice or price predictions.
- Every number in the report must show its source.
- If one agent fails (e.g., news is unavailable), the report should still be generated and should clearly say *"News data unavailable"*.

## End Result

A working demo in which the user enters a symbol and receives a short report like this:

> **TCS: Stock Insight (as of 22 Oct 2026)**
> **Price:** ₹X, up Y% in 1 month (source: price API)
> **News:** 2–3 key points (source: news API)
> **Summary:** a neutral, plain-language explanation
> *This is information only, not investment advice.*

Also show one failure case: the news API fails, and the report is still generated with a clear note.

# Workflow and Subagent Guide (Claude Code)

How to start the workflow, how to use the subagents, and which files the workflow needs.

The workflow runs **stage by stage, with your approval between every stage**:

**PRD → MoSCoW → per feature: plan → implement → test + review → accept**, plus a separate track for AI agents (design → build → test + review → accept).

---

## 1. Files the workflow needs

### Required to run the workflow

| File / folder | Why it is needed |
|---|---|
| `CASE_STUDY.md` (or `case-study.pdf` / `.txt`) in the project root | Input for `/start-workflow`. Template: `docs/00-workflow/CASE_STUDY.template.md` |
| `CLAUDE.md` | Project rules Claude Code loads every session |
| `.claude/settings.json` | Permissions and hook wiring |
| `.claude/agents/*.md` | The 11 subagent definitions (10 workflow agents + `ui-designer`) |
| `.claude/commands/*.md` | The slash commands (`/start-workflow`, `/plan-feature`, …) |
| `.claude/hooks/*.py` | Gates: approvals, stage order, write scopes, bash guard, quality check |
| `.claude/rules/*.md` | Always-on rules (workflow gates, security, team work) and path-scoped rules |
| `.claude/skills/*/` | Standards and templates the subagents preload |
| `docs/00-workflow/` | `WORKFLOW.md` (map) and `CASE_STUDY.template.md` |
| `docs/01-prd … docs/10-demo` | One numbered output folder per stage |
| `docs/11-ui-designs/` | UI plans and UI build notes from `ui-designer` (created on first use) |
| `DESIGN.md` in the project root | Only for the UI track: your design brief for `ui-designer` |
| `.workflow/approvals/` | Approval ledger. **Commit it** so teammates share approvals. `.workflow/local/` is per-clone and ignored |

### Tooling needed

- A recent Claude Code (`claude --version`). The approval hook relies on the `UserPromptExpansion` event and the `onFailure` hook option.
- `uv` (installs and pins Python 3.12), `git`, Node 18+ (optional, only for frontend tests).
- `pyproject.toml`, `uv.lock`, `.python-version` (hooks and the quality gate run through `uv`).

### Do not edit by hand or let Claude edit

`.workflow/`, `.claude/hooks/`, `.claude/settings.json`, `.env*`, and the case study are protected. Claude is blocked from changing them.

---

## 2. One-time setup

1. Install the tools listed above.
2. Open the project root and initialise git:
   ```bash
   git init && git add -A && git commit -m "chore(core): hackathon kit"
   uv sync
   ```
3. Start Claude Code in the project root with `claude`. Accept the **workspace trust** prompt. Without it, project hooks do not run.
4. Verify:
   - `/hooks` lists SessionStart, UserPromptExpansion, PreToolUse, PostToolUse, SubagentStart/Stop.
   - `/show-status` prints the workflow status (with a new project it says "Case study: MISSING").
   - Typing `/` shows the commands in section 4.
5. **Windows only:** in `.claude/settings.json` and `.claude/commands/*.md`, replace `python3` with `python` (or `py`).

---

## 3. How to start the workflow

Run these in order. Every stage ends with a **review request**; Claude stops and waits for you.

| # | You type | What happens | Output |
|---|---|---|---|
| 0 | Save the case study as `CASE_STUDY.md` in the root | — | — |
| 1 | `/start-workflow [focus notes]` | `prd-analyst` writes the PRD | `docs/01-prd/PRD.md` |
| 2 | Review, then `/approve-stage prd` (or `/revise-artifact prd <feedback>`) | Approval and SHA-256 recorded | `.workflow/approvals/prd.json` |
| 3 | `/prioritize-moscow` | `moscow-prioritizer` creates the feature files | `docs/02-moscow/` |
| 4 | Review, then `/approve-stage moscow` | — | — |
| 5 | `/plan-feature F01` | `feature-planner` writes the plan | `docs/03-feature-plans/F01-<slug>.plan.md` |
| 6 | Review, then `/approve-stage plan F01` | Unlocks implementation | — |
| 7 | `/implement-feature F01 [full\|backend\|frontend]` | `feature-implementer` builds the feature | code + `docs/05-implementation-notes/F01-<slug>.impl.md` |
| 8 | `/test-feature F01` | `test-engineer` writes and runs tests | `docs/07-test-reports/F01-<slug>.test-report.md` |
| 9 | `/review-feature F01` | `code-reviewer` gives a read-only verdict | `docs/06-reviews/F01-<slug>.review.md` |
| 10 | Fix if needed: `/revise-artifact feature F01 <fixes>` or `/debug-issue <symptom>` | — | `docs/09-debug-reports/BUG##-…` |
| 11 | `/approve-stage feature F01` | Accepted only if the test report says PASS (or `--force`). Frees the clone for the next feature | — |
| 12 | Repeat steps 5–11 for F02, F03, … | — | — |

**AI agent track** (when a feature needs an LLM agent or workflow):

| # | You type | Output |
|---|---|---|
| A | `/design-agent <need> [for F03]` | `docs/04-agent-designs/AD01-<slug>.design.md` |
| B | Review, `/approve-stage design AD01`, then `/build-agent AD01` | code + `docs/05-implementation-notes/AD01-…` |
| C | `/test-feature AD01`, `/review-feature AD01`, `/approve-stage agent AD01` | — |

**UI design track** (optional, per feature, details in section 5a):

| # | You type | Output |
|---|---|---|
| U1 | `/plan-ui F01 [DESIGN.md path]` | `docs/11-ui-designs/F01-<slug>.ui-plan.md` |
| U2 | Review, then `/build-ui F01` (approves the UI plan) or `/revise-ui F01 plan <feedback>` | UI in `templates/` + `static/`, `docs/11-ui-designs/F01-<slug>.ui-build.md` |
| U3 | `/revise-ui F01 build <feedback>` if needed, then `/test-feature F01`, `/review-feature F01` | — |

**Not sure what is next?** Run `/show-status`. It always prints the exact next command.

### Rules to remember

- A stage starts **only** when you type its slash command. Saying "looks good" in words does not advance anything.
- Only **you** can approve (`/approve-stage`). Claude and subagents cannot.
- One feature in progress per clone. Park it with `/revoke-stage active`.
- If you edit an approved file, that approval and everything built on it becomes stale. Re-approve in order (PRD → MoSCoW → plan).

---

## 4. Commands

| Command | Purpose |
|---|---|
| `/start-workflow [notes]` | Case study → PRD |
| `/prioritize-moscow` | PRD → MoSCoW feature files |
| `/plan-feature F##` | Detailed plan for one feature |
| `/implement-feature F## [scope]` | Build one feature |
| `/test-feature F##\|AD##` | Full tests + report |
| `/review-feature F##\|AD##\|diff` | Read-only review |
| `/design-agent <need>` | Agent or workflow design |
| `/build-agent AD##` | Implement an approved design |
| `/generate-mock-data <scope>` | Mock data + seed script |
| `/debug-issue <symptom>` | Root cause, minimal fix, test |
| `/prepare-demo` | Demo script, pitch, judges README |
| `/plan-ui F## [design file]` | UI plan for one feature from its plan + `DESIGN.md` |
| `/build-ui F## [pages] [design=path]` | Build or improve that feature's UI (typing it approves the UI plan) |
| `/revise-ui F## plan\|build <feedback>` | Send feedback on a UI plan or a built UI |
| `/revise-artifact <stage> [id] <feedback>` | Send your feedback to the owning subagent |
| `/approve-stage <stage> [id] [--force]` | **Human only.** Record approval |
| `/revoke-stage <stage> [id]` / `active` | **Human only.** Withdraw an approval / park the active feature |
| `/show-status` | Where you are and the next command |
| `/show-progress` | MoSCoW completion per Must/Should/Could |

Stage commands use `disable-model-invocation: true`, so only you can start them.

---

## 5. How to use the subagents

### The rule

Do not call a subagent freely. **Start it through its slash command.** The command sends the delegation message to the right subagent, and the hooks check it before the subagent starts.

### Subagents

| Subagent | Started by | Model | Writes to |
|---|---|---|---|
| `prd-analyst` | `/start-workflow`, `/revise-artifact prd` | `fable` (newest available) | `docs/01-prd/` |
| `moscow-prioritizer` | `/prioritize-moscow`, `/revise-artifact moscow` | opus | `docs/02-moscow/` |
| `feature-planner` | `/plan-feature`, `/revise-artifact plan` | opus | `docs/03-feature-plans/` |
| `feature-implementer` | `/implement-feature`, `/revise-artifact feature` | opus | `app/`, `src/`, `templates/`, `static/`, `docs/05-…/F*` |
| `agent-architect` | `/design-agent` (MODE DESIGN), `/build-agent` (MODE BUILD) | opus | `docs/04-…`, `docs/05-…/AD*`, `src/` |
| `test-engineer` | `/test-feature` | sonnet | `tests/`, `docs/07-test-reports/` |
| `code-reviewer` | `/review-feature` | opus | `docs/06-reviews/` only (read-only otherwise) |
| `mock-data-generator` | `/generate-mock-data` | sonnet | `data/`, `docs/08-…` |
| `debugger` | `/debug-issue` | opus | `app/`, `src/`, `templates/`, `static/`, `docs/09-…` |
| `demo-pitch-writer` | `/prepare-demo` | sonnet | `docs/10-demo/` |
| `ui-designer` | `/plan-ui` (UI-PLAN), `/build-ui` (UI-BUILD), `/revise-ui` | opus | `docs/11-ui-designs/`, `templates/`, `static/`, `tests/frontend/` |

### How a subagent run works

1. You type the slash command.
2. `stage_gate.py` checks that the subagent's stage is unlocked, the feature/design ID labels are present (`Feature ID:`, `Design ID:`, `MODE:`), only one feature is active, and dependencies are handled.
3. The subagent preloads its skills, does the work, and writes **only** into its own folders (`protect_files.py` enforces this).
4. It returns a structured **RESULT** block: status, artifacts, summary, review points, open questions, errors, next command.
5. The main conversation turns the RESULT into a **review request** and stops.

### Review request format

```markdown
### <Stage> ready for your review — <item id or "project">
**File(s):** `<path>`
**Summary:** <3-6 bullets>
**Please check:** <3-5 specific review points>
**Open questions:** <questions or "none">

- Approve: `/approve-stage <stage> [id]`
- Request changes: `/revise-artifact <stage> [id] <your feedback>`
- After approval, run: `<next command>`
```

If a subagent returns `blocked` or `error`, the reason and the fix are shown instead.

### Giving feedback to a subagent

Use `/revise-artifact <stage> [id] <feedback>`. The feedback is passed to the owning subagent. Subagents cannot see your chat, so put everything they need in the feedback text (error output, file names, the exact change).

### Do and don't

- Do let the owning subagent do its own stage work. The main conversation does not do a subagent's work.
- Do keep the `Feature ID:`, `Design ID:`, `MODE:` labels exact if you ever write a delegation message yourself. Hooks read them.
- Don't ask Claude to edit `.workflow/`, `.claude/hooks/`, `.claude/settings.json`, `.env*`, or the case study.
- Don't try to work around a denied hook. Read the reason it shows and run the command it suggests.

### Dependencies between features

Before `/plan-feature`, `/implement-feature`, `/design-agent`, `/build-agent`, Claude checks the feature's `Depends on:` line. If a dependency is not met, you choose:

- **A.** A teammate finished it: they push, you `git pull`, rerun the command.
- **B.** A teammate has not finished it: pick another feature meanwhile.
- **C.** Mock it: Claude continues with `Dependency mode: MOCK <F##>`. Mock code carries `DEP-MOCK(<F##>)` markers and must be removed before the feature is accepted.

---

## 5a. UI design agent (`ui-designer`)

A UI/UX specialist that reads your `DESIGN.md` and one feature plan, plans the screens from the feature's flows, and then builds a production-ready, styled UI (or improves the existing one) in plain HTML/CSS/JS.

### What it uses

| Source | Role |
|---|---|
| `DESIGN.md` (project root, or a path you pass) | Your brand and visual rules: colours, typography, spacing, radius, motion, tone, component style. Its values become tokens in `static/css/tokens.css` |
| Feature plan `docs/03-feature-plans/F##-*.plan.md` | Flows, user stories, states, and the API contract. The UI never adds behaviour the plan does not have |
| `ui-ux-pro-max` skill (`.claude/skills/ui-ux-pro-max/`) | UX, accessibility, layout, colour, typography, and chart guidance where `DESIGN.md` is silent |
| 21st MCP server | Component ideas (cards, tables, forms, empty states). Its React/Tailwind output is **translated** into vanilla HTML/CSS/JS, never pasted |

Project rules still win over all of them: no frameworks, no build step, tokens only in `tokens.css`, no `innerHTML` with data, CSP kept.

### One-time setup (each teammate)

1. Add a `DESIGN.md` to the project root. Suggested sections: brand and tone, colour palette (light + dark), typography (fonts, scale), spacing and radius, shadows, motion, component style (buttons, cards, tables, forms), do / don't, reference screenshots or links.
2. The `ui-ux-pro-max` skill is in the repo (`.claude/skills/ui-ux-pro-max/`). It needs only `python3`.
3. Add the 21st MCP server **in your own clone, with your own key**, in local scope (never `--scope project`, which would put the key in `.mcp.json` and in git):
   ```bash
   claude mcp add --transport http 21st https://21st.dev/api/mcp --header "x-api-key: <YOUR_21ST_KEY>"
   claude mcp list   # 21st should show "Connected"
   ```
   Restart Claude Code after adding it. Without 21st the agent still works and notes `MCP_21ST_UNAVAILABLE` in its doc.

### How to use it

| Step | You type | What happens | Output |
|---|---|---|---|
| 1 | `/plan-ui F03` (or `/plan-ui F03 docs/DESIGN.md`) | Reads the plan, `DESIGN.md`, and the existing pages; lists screens, flow, layouts, components, states, tokens, accessibility, data mapping | `docs/11-ui-designs/F03-<slug>.ui-plan.md` |
| 2 | Review the UI plan. Changes: `/revise-ui F03 plan <feedback>` | Same file revised, version bumped | — |
| 3 | `/build-ui F03` (optional page scope: `/build-ui F03 dashboard`) | **Typing this approves the UI plan.** Creates the UI if none exists, otherwise improves it (keeps behaviour, API calls, and element ids) | `templates/…`, `static/…`, `tests/frontend/…`, `docs/11-ui-designs/F03-<slug>.ui-build.md` |
| 4 | Open the page URL from the build note. Changes: `/revise-ui F03 build <feedback>` | UI and build note revised | — |
| 5 | `/test-feature F03`, `/review-feature F03`, then `/approve-stage feature F03` | The UI is tested and accepted as part of the feature | — |

### When to run it

- **Before `/implement-feature`** (needs an approved feature plan): run `/plan-ui`, review it, then `/implement-feature F##`. The `feature-implementer` follows the UI plan for the frontend; afterwards `/build-ui` can polish it.
- **After `/implement-feature`**: run `/plan-ui` then `/build-ui` to improve the existing UI before `/test-feature`.
- On an already accepted feature: changing the UI changes the feature, so rerun `/test-feature` and `/review-feature` afterwards.

### Rules and limits

- Approval of the UI plan is your `/build-ui` command. It is not recorded in `.workflow/approvals/`; the feature itself is still accepted only with `/approve-stage feature F##`.
- `/build-ui` needs the feature plan approved (`/approve-stage plan F##`), because application code is locked before that.
- The agent writes only to `docs/11-ui-designs/`, `templates/`, `static/`, `tests/frontend/`. It never changes the backend; missing data or endpoints become `OPEN QUESTION:` items with a suggested `/revise-artifact feature F## …`.
- These write limits are in the agent's instructions; the hooks do not know this agent, so review its diff like any other.
- 21st receives only generic component descriptions, never your code, data, or the case study.

---

## 6. Team usage (parallel work)

- Everyone together: the lead runs steps 1–4 (PRD and MoSCoW), the team reviews, then commit and push the docs and `.workflow/approvals/*.json`.
- After that, each teammate works in their own clone on `feat/F##-<slug>` and runs plan → implement → test → review → accept for their own feature.
- Before every stage: `git pull`. After every approval: commit code together with its `.workflow/approvals/` files and push.
- In shared files, add only your own feature's section. Do not reformat other features' code.

---

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| Hooks don't run | Accept workspace trust; check `/hooks`; run `python3 .claude/hooks/workflow_state.py status` |
| `/approve-stage` says the hook did not run | Update Claude Code; or run `python3 .claude/hooks/workflow_state.py approve plan F01` in your own terminal |
| "Stage locked: … changed after approval" | You edited an approved file. Review it and approve again in order |
| "F01 is still in progress in this clone" | Accept it, or park it with `/revoke-stage active` |
| Command aborts on `python3` | Windows: replace `python3` with `python` / `py` |
| Model error on `prd-analyst` | Change `model: fable` to `model: opus` in `.claude/agents/prd-analyst.md` |
| `/plan-ui` says the design file is missing | Add `DESIGN.md` to the project root, or pass its path: `/plan-ui F03 docs/DESIGN.md` |
| UI doc says `MCP_21ST_UNAVAILABLE` | Run `claude mcp list`; add or re-key the 21st server (section 5a) and restart Claude Code |
| `uv: command not found` | Install uv: <https://docs.astral.sh/uv/getting-started/installation/> |

Emergency only: `python3 .claude/hooks/workflow_state.py bypass on` in your own terminal (`bypass off` to undo). Secret and ledger protection stay on.

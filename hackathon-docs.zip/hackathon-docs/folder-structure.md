# Project Folder Structure

Standard layout for every hackathon project. Create the folders with the **Setup command**, then create the shared files (`__init__.py`, `src/config.py`, `src/core/*`, `app/main.py`) with the **Core files command**. Files that tools generate are not created by either command.

## Architecture

```text
cyberbulls-hackathon-kit/
├── README.md                  problem, architecture, how to run, known limits
├── CLAUDE.md                  project rules for Claude Code
├── CASE_STUDY.md              the case study (input for the PRD). Never edit.
├── .claude/                   workflow engine: agents, commands, hooks, rules, skills, settings (copied, not generated)
├── .workflow/                 approval ledger: approvals/ (committed), local/ (gitignored, created by hooks)
├── .env.example               variable names only, never real keys
├── .gitignore                 .env, logs/, __pycache__/, .venv/
├── pyproject.toml, uv.lock    dependencies (uv, replaces requirements.txt) + ruff and pytest config
├── .python-version            3.12
├── package.json               only sets "type": "module" for the frontend tests
├── .mcp.json                  only if the case uses an MCP server
│
├── mcp_server/                only if building an MCP server (server.py + one module per exposed tool)
│
├── src/
│   ├── config.py              model names, limits, thresholds in ONE place (Settings, env APP_*)
│   ├── schemas.py             all Pydantic models: API request/response DTOs + agent I/O (nullable fields, enums)
│   ├── core/                  errors, responses, middleware, exception handlers, database, pagination, security
│   ├── api/v1/                router.py + controllers/<x>_controller.py
│   ├── services/              <x>_service.py: business rules, transactions, calls agents
│   ├── dao/                   <x>_dao.py: all queries, scoped by owner
│   ├── models/                <x>_model.py: SQLAlchemy ORM
│   ├── dependencies/          providers.py: composition root (session -> DAOs -> service)
│   ├── agents/                common/ shared infra + one file per agent: coordinator.py, extractor.py
│   ├── tools/                 one file per tool + registry.py
│   ├── guardrails/            code gates: approval rules, validation, hooks
│   ├── prompts/               prompt text in .md/.txt files, not buried in code
│   └── observability/
│       └── trace.py           logs every tool call, cost, latency
│
├── data/
│   ├── sample/                inputs for demo and testing
│   ├── fixtures/              mock DB/API data
│   └── seed_mock_data.py      idempotent seed script (from /generate-mock-data)
│
├── tests/
│   ├── cases.py               8-10 test cases with expected results
│   ├── run_tests.py           one command, prints a score table
│   └── unit/, integration/, agents/ (+ evals/), frontend/, conftest.py
│
├── app/                       demo layer (FastAPI)
│   └── main.py                app factory: routers, health, /static, pages (run: uvicorn app.main:app)
│
├── templates/                 HTML pages: index.html + one folder per area (templates/dashboard/overview.html)
├── static/                    static assets
│   ├── css/                   tokens.css, app.css, <feature>.css
│   ├── js/                    core/, services/, pages/<area>/<page>.page.js
│   └── images/
│
├── docs/
│   ├── architecture.md        one-page diagram and key decisions
│   ├── pitch.md               5-slide outline and demo script
│   └── 00-workflow … 10-demo  numbered workflow artifacts (PRD, MoSCoW, plans, reviews, reports)
│
├── migrations/                Alembic, only once PostgreSQL is used
└── logs/                      trace output (gitignored)
```

### Folder details

| Path | Purpose |
|------|---------|
| `src/` | All application Python code. `app/` imports `src/`; `src/` never imports `app/`. |
| `src/core/` | Errors, response envelope, middleware, exception handlers, database, pagination, security. |
| `src/api/v1/` | Routers and controllers (HTTP layer only). |
| `src/services/` | Business rules and transactions. Calls agents. |
| `src/dao/` | All database queries, always scoped by owner. |
| `src/models/` | SQLAlchemy ORM models. |
| `src/dependencies/` | `providers.py` is the only composition root. |
| `src/agents/` | `common/` for shared agent infrastructure, one file per agent. |
| `src/tools/` | One file per tool, plus `registry.py`. |
| `src/guardrails/` | Code-level gates: approval rules, validation, hooks. |
| `src/prompts/` | Prompt text in `.md` / `.txt` files. |
| `src/observability/` | `trace.py` logs every tool call, cost and latency. |
| `data/sample/` | Demo and test inputs. |
| `data/fixtures/` | Mock DB and API data. |
| `tests/` | Unit, integration, agent (and evals), and frontend tests. |
| `app/` | Demo layer. `main.py` is the FastAPI app factory only. |
| `templates/` | HTML pages, one folder per area. |
| `static/` | CSS, JS and images. No frameworks, no build step. |
| `docs/` | Numbered workflow artifacts plus `architecture.md` and `pitch.md`. |
| `logs/` | Trace output. Gitignored. |
| `.claude/` | Copied from the kit. Holds the agents, slash commands, hooks, rules and skills that drive the workflow. | Project start |
| `.workflow/approvals/` | Approval ledger (`prd.json`, `moscow.json`, `plan-F##.json`). Committed, so teammates share approvals. | Setup command |
| `.workflow/local/` | Activity log and active state. Gitignored. | Hooks, on first run |
| `docs/02-moscow/must-have/`, `should-have/`, `could-have/` | One file per feature, grouped by MoSCoW category. `00-MOSCOW-INDEX.md` sits in `docs/02-moscow/`. | Setup command |

### Files and folders NOT created by the command

These are generated by tools or added only when needed. Do not create them by hand.

| Item | Created by | When |
|------|-----------|------|
| `CASE_STUDY.md` | Provided with the case | Project start. Never edit. |
| `.claude/` | Copied from the kit | Project start |
| `pyproject.toml`, `uv.lock` | `uv init` / `uv add` | Project setup |
| `.python-version` | `uv python pin 3.12` | Project setup |
| `.venv/` | `uv sync` | Project setup |
| `.env` | `cp .env.example .env` | Project setup. Never commit it. |
| `migrations/` | `alembic init migrations` | Only once PostgreSQL is used |
| `mcp_server/`, `.mcp.json` | Written by hand | Only if the case needs an MCP server |
| `package.json` | Written by hand | Only when frontend tests are added |
| `README.md`, `CLAUDE.md`, `.gitignore`, `.env.example` | Team, by hand | Project start |
| `__init__.py` files, `src/config.py`, `src/api/v1/router.py`, `src/core/*.py`, `app/main.py` | **Core files command** (below) | Right after the Setup command |
| `src/core/security.py`, `src/schemas.py`, `src/dependencies/providers.py` | First feature that needs them | Feature implementation |

## Setup command

Run this from the project root. It creates every folder and subfolder in the structure above, then adds the `.gitkeep` placeholders the `.gitignore` and the approval ledger expect. It is safe to run again because `mkdir -p` skips folders that already exist and `touch` does no harm on an existing file.

```bash
mkdir -p \
  src/core \
  src/api/v1/controllers \
  src/services \
  src/dao \
  src/models \
  src/dependencies \
  src/agents/common \
  src/tools \
  src/guardrails \
  src/prompts \
  src/observability \
  data/sample \
  data/fixtures \
  tests/unit \
  tests/integration \
  tests/agents/evals \
  tests/frontend \
  app \
  templates \
  static/css \
  static/js/core \
  static/js/services \
  static/js/pages \
  static/images \
  docs/00-workflow \
  docs/01-prd \
  docs/02-moscow \
  docs/03-feature-plans \
  docs/04-agent-designs \
  docs/05-implementation-notes \
  docs/06-reviews \
  docs/07-test-reports \
  docs/08-mock-data \
  docs/09-debug-reports \
  docs/10-demo \
  docs/02-moscow/must-have \
  docs/02-moscow/should-have \
  docs/02-moscow/could-have \
  .workflow/approvals \
  logs

touch logs/.gitkeep .workflow/approvals/.gitkeep
```

After it runs, check the result:

```bash
find . -type d -not -path "./.git*" -not -path "./.venv*" | sort
```

Then run the setup steps that create the tool-generated files. Run `uv init` only in a brand-new project, because it overwrites an existing `pyproject.toml`:

```bash
uv python pin 3.12      # writes .python-version
uv sync                 # creates .venv and uv.lock from pyproject.toml
cp .env.example .env    # then fill in real values locally; never commit .env
```

Notes:

- `.gitkeep` files come from the `touch` line above: `logs/.gitkeep` (the `.gitignore` expects it) and `.workflow/approvals/.gitkeep`. Git does not track empty folders, so add a `.gitkeep` to any other folder that stays empty.
- `src/mocks/` and `static/js/mocks/` are not in the setup command. They appear only when a feature is built against a teammate's unfinished dependency (`DEP-MOCK`), and the implementer creates them then.
- `src/` folders get their `__init__.py` from the **Core files command**. `tests/` subfolders do not need `__init__.py` unless a tool requires it.

## Core files command

These files are the same in every project, so they are created by command instead of being planned and written per feature. They hold the shared plumbing: app factory, settings, error handling, response envelope, pagination, middleware, and database setup.

Run the commands from the project root, **after** the folder setup command above. They overwrite files with the same name, so run them in a new project only. Features add to these files later (see "Rules after this step").

### Step 1: `__init__.py` files

Makes every `src/` folder a package. `src/models/__init__.py` is imported by `app/main.py`; each feature appends its own model import to it.

```bash
touch \
  src/__init__.py \
  src/core/__init__.py \
  src/api/__init__.py \
  src/api/v1/__init__.py \
  src/api/v1/controllers/__init__.py \
  src/services/__init__.py \
  src/dao/__init__.py \
  src/models/__init__.py \
  src/dependencies/__init__.py \
  src/agents/__init__.py \
  src/agents/common/__init__.py \
  src/tools/__init__.py \
  src/guardrails/__init__.py \
  src/observability/__init__.py
```

### Step 2: `src/config.py` and `src/api/v1/router.py`

`app/main.py` needs both. They start minimal; features add their own settings and their own `include_router` line.

```bash
cat > src/config.py <<'EOF'
"""Application configuration loaded from environment variables (12-factor).

The ONE place for settings. Every layer reads configuration through
``get_settings()``; nothing else in ``src/`` or ``app/`` reads the environment.
Features add their own settings here (for example LLM model ids) as they are built.

Example:
    >>> get_settings().environment  # doctest: +SKIP
    'dev'
"""

from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Typed, validated application settings.

    Every value comes from an ``APP_``-prefixed environment variable or ``.env``.

    Attributes:
        app_name (str): Human readable service name used in logs and OpenAPI.
        environment (str): ``dev``, ``test`` or ``prod``.
        database_url (str): SQLAlchemy async URL (PostgreSQL in prod, SQLite in tests).
        cors_origins (list[str]): Explicit allow-list of browser origins. Never ``*``.
        default_page_size (int): Page size used when the client does not send ``limit``.
        max_page_size (int): Hard upper bound for ``limit`` on every list endpoint.
        problem_type_base (str): URI prefix for RFC 9457 ``type`` values.
        templates_dir (str): Folder with the HTML pages served by the app.
        static_dir (str): Folder with CSS/JS/images mounted at ``/static``.
        log_dir (str): Folder for trace output (gitignored).
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="APP_",
        extra="ignore",
        hide_input_in_errors=True,
    )

    app_name: str = "hackathon-api"
    environment: Literal["dev", "test", "prod"] = "dev"
    database_url: str = "sqlite+aiosqlite:///./dev.db"
    cors_origins: list[str] = Field(default_factory=list)
    default_page_size: int = Field(default=20, ge=1, le=100)
    max_page_size: int = Field(default=100, ge=1, le=500)
    problem_type_base: str = "urn:hackathon:problem:"
    templates_dir: str = "templates"
    static_dir: str = "static"
    log_dir: str = "logs"


@lru_cache
def get_settings() -> Settings:
    """Return the process-wide settings instance.

    The instance is created on first call and cached, so every caller shares it.
    Call ``get_settings.cache_clear()`` in tests that change the environment.

    Returns:
        settings (Settings): Cached ``Settings`` object.
    """
    return Settings()
EOF

cat > src/api/v1/router.py <<'EOF'
"""Version 1 API router: include every feature controller here.

The application factory in ``app/main.py`` includes ``api_router`` once. Each
feature adds only its own ``include_router`` line.

Attributes:
    api_router (APIRouter): Router mounted at ``/api/v1`` that aggregates all
        feature routers.
"""

from fastapi import APIRouter

api_router = APIRouter(prefix="/api/v1")
EOF
```

### Step 3: `src/core/` files

Errors, exception handlers, middleware, response envelope, pagination, and database session. No project-specific names inside.

```bash
cat > src/core/errors.py <<'EOF'
"""Typed application errors mapped to RFC 9457 Problem Details.

Services and DAOs raise these; only ``src.core.exception_handlers`` turns them
into HTTP responses. Clients branch on the stable ``code`` value, never on the
``detail`` text. Every layer that signals an expected failure imports these classes.
"""

from typing import Any


class AppError(Exception):
    """Base class for every expected (handled) application error.

    Subclasses override ``status_code``, ``code`` and ``title``; an instance may
    override ``code`` and carries a client-safe ``detail``.

    Example:
        >>> error = AppError("Something broke.")
        >>> error.status_code, error.code
        (500, 'INTERNAL_ERROR')

    Attributes:
        status_code (int): HTTP status returned to the client.
        code (str): Stable machine-readable error code (UPPER_SNAKE_CASE).
        title (str): Short, human-readable summary of the error type.
        detail (str): Occurrence-specific explanation safe to show to clients.
        errors (list[dict[str, Any]]): Optional field-level errors
            ``[{"field": ..., "message": ...}]``.
        headers (dict[str, str]): Optional extra response headers (for example
            ``Retry-After``).
    """

    status_code: int = 500
    code: str = "INTERNAL_ERROR"
    title: str = "Internal Server Error"

    def __init__(
        self,
        detail: str,
        *,
        code: str | None = None,
        errors: list[dict[str, Any]] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Create an application error.

        Args:
            detail (str): Client-safe explanation of this occurrence.
            code (str | None): Optional override of the class-level error code.
            errors (list[dict[str, Any]] | None): Optional list of field-level
                validation errors.
            headers (dict[str, str] | None): Optional response headers to attach.
        """
        super().__init__(detail)
        self.detail = detail
        if code:
            self.code = code
        self.errors = errors or []
        self.headers = headers or {}


class ValidationAppError(AppError):
    """Input is well-formed but semantically invalid (422).

    Attributes:
        status_code (int): Fixed to 422.
        code (str): Stable error code ``VALIDATION_FAILED``.
        title (str): Summary ``Validation Failed``.
    """

    status_code = 422
    code = "VALIDATION_FAILED"
    title = "Validation Failed"


class UnauthorizedError(AppError):
    """Caller is not authenticated (401).

    Attributes:
        status_code (int): Fixed to 401.
        code (str): Stable error code ``UNAUTHENTICATED``.
        title (str): Summary ``Unauthorized``.
    """

    status_code = 401
    code = "UNAUTHENTICATED"
    title = "Unauthorized"


class PermissionDeniedError(AppError):
    """Caller is authenticated but not allowed (403).

    Attributes:
        status_code (int): Fixed to 403.
        code (str): Stable error code ``PERMISSION_DENIED``.
        title (str): Summary ``Forbidden``.
    """

    status_code = 403
    code = "PERMISSION_DENIED"
    title = "Forbidden"


class NotFoundError(AppError):
    """Resource does not exist or is not visible to the caller (404).

    Attributes:
        status_code (int): Fixed to 404.
        code (str): Stable error code ``RESOURCE_NOT_FOUND``.
        title (str): Summary ``Not Found``.
    """

    status_code = 404
    code = "RESOURCE_NOT_FOUND"
    title = "Not Found"


class ConflictError(AppError):
    """Request conflicts with current state, e.g. idempotency key reuse (409).

    Attributes:
        status_code (int): Fixed to 409.
        code (str): Stable error code ``CONFLICT``.
        title (str): Summary ``Conflict``.
    """

    status_code = 409
    code = "CONFLICT"
    title = "Conflict"


class PreconditionFailedError(AppError):
    """``If-Match`` version does not match the stored version (412).

    Attributes:
        status_code (int): Fixed to 412.
        code (str): Stable error code ``VERSION_MISMATCH``.
        title (str): Summary ``Precondition Failed``.
    """

    status_code = 412
    code = "VERSION_MISMATCH"
    title = "Precondition Failed"


class PreconditionRequiredError(AppError):
    """A conditional header such as ``If-Match`` is required (428).

    Attributes:
        status_code (int): Fixed to 428.
        code (str): Stable error code ``PRECONDITION_REQUIRED``.
        title (str): Summary ``Precondition Required``.
    """

    status_code = 428
    code = "PRECONDITION_REQUIRED"
    title = "Precondition Required"


class BusinessRuleError(AppError):
    """A domain rule rejected the operation (422).

    Attributes:
        status_code (int): Fixed to 422.
        code (str): Stable error code ``BUSINESS_RULE_VIOLATION``.
        title (str): Summary ``Business Rule Violation``.
    """

    status_code = 422
    code = "BUSINESS_RULE_VIOLATION"
    title = "Business Rule Violation"


class ExternalServiceError(AppError):
    """A dependency (LLM, third-party API) is unavailable (503).

    Attributes:
        status_code (int): Fixed to 503.
        code (str): Stable error code ``UPSTREAM_UNAVAILABLE``.
        title (str): Summary ``Service Unavailable``.
    """

    status_code = 503
    code = "UPSTREAM_UNAVAILABLE"
    title = "Service Unavailable"


class DatabaseUnavailableError(AppError):
    """The database cannot be reached (503, always with ``Retry-After``).

    Attributes:
        status_code (int): Fixed to 503.
        code (str): Stable error code ``DATABASE_UNAVAILABLE``.
        title (str): Summary ``Service Unavailable``.
    """

    status_code = 503
    code = "DATABASE_UNAVAILABLE"
    title = "Service Unavailable"
EOF

cat > src/core/exception_handlers.py <<'EOF'
"""Global exception handlers producing RFC 9457 ``application/problem+json``.

No stack traces, SQL, or exception text ever reach the client; full detail is
logged server-side with the request id. The app factory calls
``register_exception_handlers`` once at startup.

Mapping (BR-07): ``AppError`` -> its own status/code; ``RequestValidationError`` ->
422 ``VALIDATION_FAILED``; Starlette 404 -> ``RESOURCE_NOT_FOUND``; 405 ->
``METHOD_NOT_ALLOWED`` (keeps ``Allow``); other HTTP errors -> ``HTTP_<status>``;
``OperationalError``/``InterfaceError`` -> 503 ``DATABASE_UNAVAILABLE`` with
``Retry-After: 5``; anything else -> 500 ``INTERNAL_ERROR``.

Attributes:
    logger (logging.Logger): Logger ``src.errors`` for unexpected failures.
    PROBLEM_JSON (str): Media type ``application/problem+json`` for error responses.
    DB_RETRY_AFTER_SECONDS (str): ``Retry-After`` value sent with database outages.
"""

import logging
from http import HTTPStatus
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.exc import InterfaceError, OperationalError
from starlette.exceptions import HTTPException as StarletteHTTPException

from src.config import get_settings
from src.core.errors import AppError, DatabaseUnavailableError

logger = logging.getLogger("src.errors")
PROBLEM_JSON = "application/problem+json"
DB_RETRY_AFTER_SECONDS = "5"
_HTTP_CODES = {404: "RESOURCE_NOT_FOUND", 405: "METHOD_NOT_ALLOWED"}
_HTTP_DETAILS = {
    404: "The requested resource was not found.",
    405: "This method is not allowed for this resource.",
}


def problem_response(
    request: Request,
    *,
    status: int,
    code: str,
    title: str,
    detail: str,
    errors: list[dict[str, Any]] | None = None,
    headers: dict[str, str] | None = None,
) -> JSONResponse:
    """Build a Problem Details response.

    Args:
        request (Request): Current request (for ``instance`` and ``request_id``).
        status (int): HTTP status code.
        code (str): Stable machine-readable error code.
        title (str): Short summary of the problem type.
        detail (str): Occurrence-specific, client-safe explanation.
        errors (list[dict[str, Any]] | None): Optional field-level error list.
        headers (dict[str, str] | None): Optional extra headers.

    Returns:
        response (JSONResponse): Response with media type ``application/problem+json``
            and the ``X-Request-ID`` header.
    """
    request_id = getattr(request.state, "request_id", "unknown")
    body: dict[str, Any] = {
        "type": f"{get_settings().problem_type_base}{code.lower()}",
        "title": title,
        "status": status,
        "detail": detail,
        "instance": request.url.path,
        "code": code,
        "request_id": request_id,
    }
    if errors:
        body["errors"] = errors
    merged = {
        "X-Request-ID": request_id,
        "X-Content-Type-Options": "nosniff",
        **(headers or {}),
    }
    return JSONResponse(body, status_code=status, media_type=PROBLEM_JSON, headers=merged)


async def _handle_app_error(request: Request, exc: Exception) -> JSONResponse:
    """Map a typed ``AppError`` to its problem response."""
    assert isinstance(exc, AppError)
    return problem_response(
        request,
        status=exc.status_code,
        code=exc.code,
        title=exc.title,
        detail=exc.detail,
        errors=exc.errors,
        headers=exc.headers,
    )


async def _handle_validation(request: Request, exc: Exception) -> JSONResponse:
    """Map request validation errors to 422 with a field list (no input echo)."""
    assert isinstance(exc, RequestValidationError)
    field_errors = [
        {"field": ".".join(str(p) for p in err["loc"] if p != "body"), "message": err["msg"]}
        for err in exc.errors()
    ]
    return problem_response(
        request,
        status=422,
        code="VALIDATION_FAILED",
        title="Validation Failed",
        detail="One or more fields are invalid.",
        errors=field_errors,
    )


async def _handle_http(request: Request, exc: Exception) -> JSONResponse:
    """Map framework HTTP errors (404, 405, ...) to stable codes."""
    assert isinstance(exc, StarletteHTTPException)
    status = exc.status_code
    try:
        phrase = HTTPStatus(status).phrase
    except ValueError:
        phrase = "HTTP Error"
    headers = {k: v for k, v in (exc.headers or {}).items() if k.lower() == "allow"}
    return problem_response(
        request,
        status=status,
        code=_HTTP_CODES.get(status, f"HTTP_{status}"),
        title=phrase,
        detail=_HTTP_DETAILS.get(status, phrase),
        headers=headers,
    )


async def _handle_db_unavailable(request: Request, exc: Exception) -> JSONResponse:
    """Map database connectivity errors to 503 with ``Retry-After`` (no SQL leaked)."""
    logger.error(
        "database_unavailable",
        extra={
            "request_id": getattr(request.state, "request_id", None),
            "error_type": type(exc).__name__,
        },
    )
    error = DatabaseUnavailableError("The database is temporarily unavailable. Retry shortly.")
    return problem_response(
        request,
        status=error.status_code,
        code=error.code,
        title=error.title,
        detail=error.detail,
        headers={"Retry-After": DB_RETRY_AFTER_SECONDS},
    )


async def _handle_unexpected(request: Request, exc: Exception) -> JSONResponse:
    """Log the full traceback server-side and return a generic 500."""
    logger.exception(
        "unhandled_error", extra={"request_id": getattr(request.state, "request_id", None)}
    )
    return problem_response(
        request,
        status=500,
        code="INTERNAL_ERROR",
        title="Internal Server Error",
        detail="An unexpected error occurred. Quote the request_id when reporting it.",
    )


def register_exception_handlers(app: FastAPI) -> None:
    """Register all global exception handlers on the app.

    Args:
        app (FastAPI): FastAPI application instance.

    Returns:
        None: Handlers are registered on ``app`` in place.
    """
    app.add_exception_handler(AppError, _handle_app_error)
    app.add_exception_handler(RequestValidationError, _handle_validation)
    app.add_exception_handler(StarletteHTTPException, _handle_http)
    app.add_exception_handler(OperationalError, _handle_db_unavailable)
    app.add_exception_handler(InterfaceError, _handle_db_unavailable)
    app.add_exception_handler(Exception, _handle_unexpected)
EOF

cat > src/core/middleware.py <<'EOF'
"""Request-id propagation, baseline security headers, and structured access logging.

The app factory registers ``RequestIdMiddleware`` once; it runs for every HTTP
request. The access log line never contains request headers, so API keys never
reach the logs.

Attributes:
    logger (logging.Logger): Access logger ``src.access``.
"""

import json
import logging
import re
import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger("src.access")
_VALID_REQUEST_ID = re.compile(r"^[A-Za-z0-9._-]{8,64}$")


def _log_access(request: Request, request_id: str, status: int, started: float) -> None:
    """Write one JSON access line (no headers, no body)."""
    logger.info(
        json.dumps(
            {
                "event": "http_request",
                "request_id": request_id,
                "method": request.method,
                "path": request.url.path,
                "status": status,
                "latency_ms": round((time.perf_counter() - started) * 1000, 1),
            }
        )
    )


class RequestIdMiddleware(BaseHTTPMiddleware):
    """Attach a correlation id to every request and log one JSON line per request.

    A valid incoming ``X-Request-ID`` (``^[A-Za-z0-9._-]{8,64}$``) is reused;
    otherwise a new ``uuid4().hex`` is generated. The id is exposed as
    ``request.state.request_id`` and echoed on the response together with
    ``X-Content-Type-Options: nosniff``.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        """Assign ``request.state.request_id``, call the app, and log the outcome.

        Args:
            request (Request): Incoming request.
            call_next (RequestResponseEndpoint): Next ASGI handler.

        Returns:
            response (Response): The downstream response with ``X-Request-ID`` and
                ``X-Content-Type-Options`` headers.

        Raises:
            Exception: An unhandled downstream exception is logged as status 500
                and re-raised so the server error handler answers.
        """
        incoming = request.headers.get("X-Request-ID", "")
        request_id = incoming if _VALID_REQUEST_ID.match(incoming) else uuid.uuid4().hex
        request.state.request_id = request_id
        started = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            _log_access(request, request_id, 500, started)
            raise
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        _log_access(request, request_id, response.status_code, started)
        return response
EOF

cat > src/core/responses.py <<'EOF'
"""Consistent success envelope shared by every endpoint.

Success: ``{"data": ..., "meta": {"request_id", "timestamp", "pagination"?}}``.
Errors never use this envelope; they use ``application/problem+json``. Every
controller wraps its result with these models.
"""

from datetime import UTC, datetime

from fastapi import Request
from pydantic import BaseModel, Field


class PageMeta(BaseModel):
    """Cursor pagination metadata.

    Attributes:
        limit (int): Page size that was applied.
        has_more (bool): Whether another page exists.
        next_cursor (str | None): Opaque cursor for the next page, ``None`` on the
            last page.
    """

    limit: int
    has_more: bool
    next_cursor: str | None = None


class ResponseMeta(BaseModel):
    """Metadata attached to every successful response.

    Attributes:
        request_id (str): Correlation id, identical to the ``X-Request-ID`` header.
        timestamp (datetime): Server time in UTC (ISO 8601).
        pagination (PageMeta | None): Present only on list endpoints.
    """

    request_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    pagination: PageMeta | None = None


class SuccessResponse[T](BaseModel):
    """Generic success envelope.

    Attributes:
        data (T): The resource or list of resources.
        meta (ResponseMeta): Correlation and pagination metadata.
    """

    data: T
    meta: ResponseMeta


def build_meta(request: Request, pagination: PageMeta | None = None) -> ResponseMeta:
    """Build response metadata for the current request.

    Args:
        request (Request): Incoming request (carries ``state.request_id``).
        pagination (PageMeta | None): Optional pagination block for list endpoints.
            Defaults to ``None``.

    Returns:
        meta (ResponseMeta): Populated ``ResponseMeta``.
    """
    request_id = getattr(request.state, "request_id", "unknown")
    return ResponseMeta(request_id=request_id, pagination=pagination)
EOF

cat > src/core/pagination.py <<'EOF'
"""Opaque cursor encoding for keyset (cursor) pagination.

A cursor is URL-safe base64 of a small JSON object holding the sort key(s) of
the last item on a page, e.g. ``{"s": "TCS"}``. Services use it for every list
endpoint; the decoded values are always used as bound SQL parameters.

Example:
    >>> decode_cursor(encode_cursor({"s": "TCS"}), ("s",))
    {'s': 'TCS'}
"""

import base64
import binascii
import json

from src.core.errors import ValidationAppError

_MAX_CURSOR_LENGTH = 512


def _invalid() -> ValidationAppError:
    """Build the single error raised for every malformed cursor."""
    return ValidationAppError(
        "Invalid pagination cursor.", errors=[{"field": "cursor", "message": "malformed"}]
    )


def encode_cursor(position: dict[str, str]) -> str:
    """Encode a keyset position as an opaque cursor string.

    Args:
        position (dict[str, str]): Sort key name -> value of the last item on the page.

    Returns:
        cursor (str): URL-safe base64 cursor without padding.

    Example:
        >>> encode_cursor({"s": "TCS"})
        'eyJzIjogIlRDUyJ9'
    """
    raw = json.dumps(position, sort_keys=True).encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def decode_cursor(cursor: str, keys: tuple[str, ...]) -> dict[str, str]:
    """Decode a cursor produced by ``encode_cursor`` and check its keys.

    Args:
        cursor (str): Opaque cursor from the client.
        keys (tuple[str, ...]): Keys the cursor must contain (string values).

    Returns:
        position (dict[str, str]): Mapping with exactly the requested keys.

    Raises:
        ValidationAppError: If the cursor is too long, not base64 JSON, or lacks a key
            (``field: cursor``).
    """
    if not cursor or len(cursor) > _MAX_CURSOR_LENGTH:
        raise _invalid()
    try:
        padded = cursor + "=" * (-len(cursor) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded.encode()))
    except (ValueError, binascii.Error, UnicodeDecodeError) as exc:
        raise _invalid() from exc
    if not isinstance(payload, dict):
        raise _invalid()
    result: dict[str, str] = {}
    for key in keys:
        value = payload.get(key)
        if not isinstance(value, str):
            raise _invalid()
        result[key] = value
    return result
EOF

cat > src/core/database.py <<'EOF'
"""Async SQLAlchemy engine, session factory, and declarative base.

The DAO layer and the composition root (``src/dependencies/providers.py``) use
this module for database access; ``app/main.py`` uses the engine for
``create_all`` (dev/test only) and the readiness probe.
"""

from collections.abc import AsyncIterator
from functools import lru_cache

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from src.config import get_settings


class Base(DeclarativeBase):
    """Declarative base for every ORM model."""


@lru_cache
def get_engine() -> AsyncEngine:
    """Create the process-wide async engine with pooling and pre-ping.

    Returns:
        engine (AsyncEngine): Shared ``AsyncEngine``.
    """
    return create_async_engine(get_settings().database_url, pool_pre_ping=True)


@lru_cache
def get_sessionmaker() -> async_sessionmaker[AsyncSession]:
    """Return the session factory bound to the shared engine.

    Returns:
        factory (async_sessionmaker[AsyncSession]): Factory producing ``AsyncSession``
            objects.
    """
    return async_sessionmaker(get_engine(), expire_on_commit=False)


async def get_db_session() -> AsyncIterator[AsyncSession]:
    """FastAPI dependency yielding one session per request.

    Yields:
        session (AsyncSession): An ``AsyncSession`` closed automatically after the
            request.

    Raises:
        Exception: Errors raised while the session is in use propagate to the caller.
    """
    async with get_sessionmaker()() as session:
        yield session
EOF
```

### Step 4: `app/main.py`

The FastAPI app factory: middleware, exception handlers, `/api/v1` router, health probes, `/static`, and HTML pages from `templates/`. It only wires things; no business logic.

```bash
cat > app/main.py <<'EOF'
"""Application factory: middleware, error handlers, routers, health, static files, pages.

This is the demo layer entry point; uvicorn serves ``app.main:app``. It only
wires things together, imports from ``src``, and is never imported by it.

Attributes:
    app (FastAPI): The application instance built by ``create_app``.
"""

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text

import src.models  # noqa: F401 - registers every table on Base.metadata
from src.api.v1.router import api_router
from src.config import get_settings
from src.core.database import Base, get_engine
from src.core.exception_handlers import register_exception_handlers
from src.core.middleware import RequestIdMiddleware

logging.basicConfig(level=logging.INFO, format="%(message)s")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Create tables (dev/test only) and dispose the engine on exit.

    Production uses Alembic migrations instead of ``create_all``.

    Args:
        app (FastAPI): The application.

    Yields:
        None: Control to the running application.
    """
    settings = get_settings()
    if settings.environment in {"dev", "test"}:
        async with get_engine().begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    yield
    await get_engine().dispose()


def create_app() -> FastAPI:
    """Build the FastAPI application.

    Returns:
        app (FastAPI): Configured application instance.

    Raises:
        HTTPException: At request time only: 404 from the page routes when a page
            file is missing or outside ``templates/``.
    """
    settings = get_settings()
    app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)
    app.add_middleware(RequestIdMiddleware)
    if settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.cors_origins,
            allow_methods=["GET", "POST", "PATCH", "DELETE"],
            allow_headers=["Authorization", "Content-Type", "Idempotency-Key", "If-Match"],
            expose_headers=["X-Request-ID", "ETag", "Location"],
        )
    register_exception_handlers(app)
    app.include_router(api_router)

    @app.get("/health", tags=["health"], summary="Liveness probe (public)")
    async def health() -> dict[str, str]:
        """Liveness alias: the process is up.

        Returns:
            body (dict[str, str]): ``{"status": "ok"}``.
        """
        return {"status": "ok"}

    @app.get("/health/live", include_in_schema=False)
    async def live() -> dict[str, str]:
        """Liveness: the process is up.

        Returns:
            body (dict[str, str]): ``{"status": "ok"}``.
        """
        return {"status": "ok"}

    @app.get("/health/ready", include_in_schema=False)
    async def ready() -> JSONResponse:
        """Readiness: the database is reachable.

        Returns:
            response (JSONResponse): ``{"status": "ok"}`` with 200, or
                ``{"status": "unavailable"}`` with 503 if the database cannot be reached.
        """
        try:
            async with get_engine().connect() as conn:
                await conn.execute(text("SELECT 1"))
        except Exception:  # noqa: BLE001 - readiness must never raise
            return JSONResponse({"status": "unavailable"}, status_code=503)
        return JSONResponse({"status": "ok"})

    static_dir = Path(settings.static_dir)
    if static_dir.is_dir():
        app.mount("/static", StaticFiles(directory=static_dir), name="static")
    templates_dir = Path(settings.templates_dir)

    @app.get("/", include_in_schema=False)
    async def index() -> FileResponse:
        """Serve the landing page (plain HTML, no template engine).

        Returns:
            response (FileResponse): ``templates/index.html``.

        Raises:
            HTTPException: 404 if the file is missing.
        """
        target = templates_dir / "index.html"
        if not target.is_file():
            raise HTTPException(status_code=404)
        return FileResponse(target)

    @app.get("/pages/{page:path}", include_in_schema=False)
    async def page(page: str) -> FileResponse:
        """Serve one HTML page, e.g. ``dashboard/overview``, from inside ``templates/`` only.

        Args:
            page (str): Page path without the ``.html`` suffix, from the URL.

        Returns:
            response (FileResponse): The matching HTML file.

        Raises:
            HTTPException: 404 if the file is outside ``templates/`` or does not exist.
        """
        target = (templates_dir / f"{page}.html").resolve()
        if not target.is_relative_to(templates_dir.resolve()) or not target.is_file():
            raise HTTPException(status_code=404)
        return FileResponse(target)

    return app


app = create_app()
EOF
```

### Check the result

```bash
uv run ruff check . && uv run ruff format --check .
uv run python -c "from app.main import app; print(app.title)"
uv run uvicorn app.main:app --reload     # http://localhost:8000/health and /docs
```

### Rules after this step

- Do not recreate these files in a feature. Extend them: add settings to `src/config.py`, add one `include_router` line to `src/api/v1/router.py`, add one import line to `src/models/__init__.py`.
- `src/core/security.py` (API-key/auth helpers) is not here. It depends on the auth design, so the first feature that needs authentication creates it.
- `src/schemas.py` and `src/dependencies/providers.py` are not here either. The first feature that needs them creates them, and later features add only their own section.
- Never edit `src/core/` files for one feature's needs. If a shared change is needed, tell the team first.

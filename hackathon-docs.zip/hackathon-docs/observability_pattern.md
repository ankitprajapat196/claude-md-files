# LLM Usage/Cost Observability — Portable Implementation Spec

**Audience: an AI coding agent (e.g. Claude Code) implementing this in a
different Python codebase.** This document is self-contained — it does not
assume you've seen the original application this pattern was extracted
from. Read the whole thing before writing code. Where you need a fact
about *this specific* codebase (the LLM provider, the ORM, the web
framework, what a "project" is called here), stop and look it up or ask —
every such point is called out explicitly below as `<ASK OR DISCOVER>`.

## How to use this document

1. Read sections 1-3 to understand the shape of the thing you're building.
2. Run the **Discovery checklist** (§4) against the target codebase before
   writing anything — it tells you how many call sites exist and whether
   any of them need special handling.
3. Implement in the order given in §5 — schema, then the instrumentation
   boundary, then migrate call sites one at a time, then the read API,
   then dashboards. Each step is independently testable; don't skip ahead.
4. Check your work against §7 (gotchas) and §8 (verification) before
   calling it done.

This assumes a Python async backend (FastAPI, Flask-async, or Django
async views all work — examples below are FastAPI-flavored, with notes
where another framework differs) talking to Postgres. If your stack
differs in some other way, the architecture in §1-3 still applies; only
the code in §5 needs translating.

---

## 1. The problem this solves

An application calls an LLM from multiple places in the code, and none of
those calls produce any record of what they cost, how long they took, or
what happened when they failed. Two questions become unanswerable:

- **"Why did this customer/project/workspace cost so much?"** — no way to
  know; LLM spend is invisible, mixed into one undifferentiated API bill.
- **"Why did the model get this wrong?"** — no way to check after the
  fact; once a response comes back, the exact call that produced it is
  gone.

The fix is not "add a log line at each call site" — that gets redone
every time a new call site is added, and drifts the moment someone adds
call site #7 and forgets. The fix is **one instrumentation boundary**
every call in the app is routed through, so adding usage tracking to a
new call site means wrapping one function call, not writing new logging
code.

## 2. Non-negotiable design principles

These are the rules that make this pattern work. Violating any of them
produces a worse version of this feature — read them before writing code,
not after something breaks.

1. **One recorder, not N.** There is exactly one function that computes
   cost and writes the usage row. Every call site reaches it through a
   thin adapter, never by duplicating its logic.
2. **The recorder never raises.** A bug in the observability code must
   never be able to break the LLM call it's observing. Every exception
   inside the recording path is caught and logged, not propagated.
3. **Context flows implicitly, not as parameters.** Attribution data
   (which tenant/project/user this call belongs to) is almost never
   available at every call site that needs to use it — some are nested
   several function calls deep inside business logic that has no reason
   to know about tenants. Threading extra parameters through every
   intermediate function signature is invasive and gets forgotten at the
   8th call site. Use a `ContextVar` (stdlib `contextvars`) set once per
   request/operation, read implicitly by the recorder. This also survives
   `asyncio.to_thread()`/executor hops automatically — real tracing
   systems (OpenTelemetry) use the same technique for the same reason.
4. **Cost is computed once, at write time, from a maintained price
   table.** LLM provider APIs return token counts, not dollar amounts.
   Compute cost when the row is written and store the result — never
   recompute historical cost at read time, or a pricing table update
   silently rewrites history.
5. **Every change is additive.** New table, new columns (nullable where
   it matters), new endpoints. Never modify the behavior of an existing
   call site's business logic — only change *which function* makes the
   actual HTTP call to the LLM.
6. **Nothing risky ships without a kill switch.** If you're adding
   anything beyond bare usage tracking (a second provider for comparison,
   experimental tracing, anything with its own failure mode), gate it
   behind a settings flag that defaults off. When off, the code path must
   not just "behave the same" — it should not execute at all.

## 3. Architecture

```
Business logic (wherever the app currently calls the LLM)
        |
        |  one call, unchanged except for which function it calls
        v
Instrumented call wrapper  <-- the ONE place every call passes through
        |
        v
Recorder (never raises) ── computes cost from token counts
        |
        v
Postgres: usage table (one row per call) + correlation to whatever
          "parent" record the call happened on behalf of
        |
        v
Read API (role-gated) ── project/workspace -> operation -> individual
                          call drill-down
        |
        v
Dashboard(s) ── admin cross-tenant view, optional self-service
                per-user/per-workspace view
```

Three independent layers — you can build and test each before starting
the next:
- **Schema + instrumentation boundary** (the only part every other layer
  depends on)
- **Read API** (depends on the schema existing and having data)
- **Dashboard(s)** (depends on the read API)

---

## 4. Discovery checklist — run this before writing any code

Do not assume you know how many places the target codebase calls an LLM.
Grep for it:

```bash
# Find every place a provider client gets constructed — this is more
# reliable than grepping for "openai"/"anthropic" as plain text, which
# also matches comments and unrelated strings.
grep -rn "OpenAI(\|AsyncOpenAI(\|Anthropic(\|AsyncAnthropic(\|ChatOpenAI(\|ChatAnthropic(" --include="*.py" .
```

For each call site found, answer:
- Does it use the provider's raw SDK directly, or a framework wrapper
  (LangChain `ChatOpenAI`/`ChatAnthropic`, LlamaIndex, etc.)? You'll need
  one adapter shape per calling style (see §5.3) — most codebases need
  exactly two: a raw-SDK adapter and a framework-callback adapter.
- Does this call site need its **own** dedicated client instance (a
  different timeout, a different API key, a caller-supplied override)?
  If so, note it — it can't use the shared singleton client and needs its
  own copy wrapped the same way (see the gotcha in §7).
- What's the natural "parent" record this call happens on behalf of —
  the thing a human would look at a cost report grouped by? (A project, a
  conversation, a workspace, a document — `<DISCOVER: ask the user or
  find the app's core domain entity>`.) This becomes the foreign key the
  usage table correlates against.
- Is there an existing event/audit log table that records "an operation
  ran" separately from "a model was called"? If so, plan to add one
  nullable correlation column to it rather than inventing a parallel log.

---

## 5. Implementation

### 5.1 Schema

One table, one row per LLM call. Adapt field names to the target
conventions, but keep the shape:

```sql
CREATE TABLE IF NOT EXISTS llm_calls (
    id                          BIGSERIAL PRIMARY KEY,
    tenant_id                   UUID,              -- nullable if the app isn't multi-tenant
    parent_id                   UUID NOT NULL,     -- FK to whatever "project"/"workspace"/"conversation" means here
    run_id                      UUID,              -- correlates multiple calls from one logical operation; see below
    operation_name              TEXT NOT NULL,      -- "requirements_extraction", "summarize", whatever the call site is called
    model                       TEXT NOT NULL,
    input_tokens                INTEGER NOT NULL DEFAULT 0,
    output_tokens               INTEGER NOT NULL DEFAULT 0,
    cache_creation_input_tokens INTEGER NOT NULL DEFAULT 0,  -- drop if the provider has no prompt caching
    cache_read_input_tokens     INTEGER NOT NULL DEFAULT 0,
    cost_usd                    NUMERIC(12, 6) NOT NULL DEFAULT 0,
    latency_ms                  INTEGER,
    status                      TEXT NOT NULL CHECK (status IN ('ok', 'error')),
    error                       TEXT,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_llm_calls_parent_id ON llm_calls (parent_id);
CREATE INDEX IF NOT EXISTS idx_llm_calls_run_id    ON llm_calls (run_id);
CREATE INDEX IF NOT EXISTS idx_llm_calls_created_at ON llm_calls (created_at);
```

**On `run_id`:** if a single logical operation (e.g. "handle this chat
turn") makes multiple LLM calls, generate one UUID at the top of that
operation and pass it down so every resulting `llm_calls` row — and, if
you have one, every row in an existing operation-level event log — shares
it. This is what lets a dashboard show "every model call that happened
during this operation" as a group, without `llm_calls` needing a foreign
key to a specific event-log row (an event log usually has *multiple* rows
per operation — started/completed/failed — so there's no single row to
point at; the shared `run_id` is the join key instead).

If the target app already has an operation/event log table, add `run_id
UUID` to it as a new nullable column rather than building a parallel one.

### 5.2 Cost calculation

Provider APIs return token counts, not dollars. One small module:

```python
# pricing.py
from decimal import Decimal

# USD per million tokens. <DISCOVER: current rates for whichever models
# the target app actually uses — check the provider's pricing page, don't
# guess or carry over numbers from a different provider/model family.>
MODEL_PRICING: dict[str, tuple[Decimal, Decimal]] = {
    "<model-id>": (Decimal("<input-rate>"), Decimal("<output-rate>")),
}

_MILLION = Decimal("1000000")

def calculate_cost_usd(
    model: str, input_tokens: int, output_tokens: int,
    cache_creation_tokens: int = 0, cache_read_tokens: int = 0,
) -> Decimal:
    """Falls back to $0 for an unrecognized model rather than raising —
    a missing price shouldn't break the call that earned it."""
    rates = MODEL_PRICING.get(model)
    if rates is None:
        return Decimal("0")
    input_rate, output_rate = rates
    cost = (Decimal(input_tokens) * input_rate) + (Decimal(output_tokens) * output_rate)
    # Add cache multipliers here only if the target provider supports
    # prompt caching and bills it at a different rate than fresh tokens.
    return (cost / _MILLION).quantize(Decimal("0.000001"))
```

### 5.3 The instrumentation boundary

This is the one piece of code every call site routes through. Two parts:
the context propagation, and the call wrapper(s).

**Context propagation** (framework-agnostic, pure stdlib):

```python
# llm_instrumentation.py
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Iterator, Optional

@dataclass(frozen=True)
class _CallContext:
    tenant_id: Optional[str]
    parent_id: str
    operation_name: str
    run_id: Optional[str]

_call_context: ContextVar[Optional[_CallContext]] = ContextVar("_call_context", default=None)

@contextmanager
def set_call_context(tenant_id, parent_id, operation_name, run_id) -> Iterator[None]:
    """Call this once, at the top of whatever function handles one
    logical operation (a request handler, a graph node, a background job
    — wherever you naturally know the parent_id). Every LLM call made
    anywhere below this point in the same async context is attributed
    automatically — no need to pass these IDs into the business logic
    functions that happen to call the LLM."""
    token = _call_context.set(_CallContext(tenant_id, parent_id, operation_name, run_id))
    try:
        yield
    finally:
        _call_context.reset(token)

def get_call_context() -> Optional[_CallContext]:
    return _call_context.get()
```

**The recorder** (never raises):

```python
async def record_llm_call(
    *, model: str, input_tokens: int, output_tokens: int,
    cache_creation_tokens: int = 0, cache_read_tokens: int = 0,
    latency_ms: Optional[int], status: str, error: Optional[str] = None,
) -> None:
    ctx = get_call_context()
    if ctx is None:
        logger.warning("record_llm_call: no call context set for model=%s — dropping", model)
        return
    cost_usd = calculate_cost_usd(model, input_tokens, output_tokens, cache_creation_tokens, cache_read_tokens)
    try:
        await db.execute(
            "INSERT INTO llm_calls (tenant_id, parent_id, run_id, operation_name, model, "
            "input_tokens, output_tokens, cache_creation_input_tokens, cache_read_input_tokens, "
            "cost_usd, latency_ms, status, error) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)",
            ctx.tenant_id, ctx.parent_id, ctx.run_id, ctx.operation_name, model,
            input_tokens, output_tokens, cache_creation_tokens, cache_read_tokens,
            cost_usd, latency_ms, status, error,
        )
    except Exception:
        logger.exception("record_llm_call: failed to write usage row (the LLM call itself is unaffected)")
```

**The call adapter** — the shape depends on how the target codebase calls
its LLM. You need one of these per *calling style* present (most
codebases need exactly one; some need two):

**Raw SDK adapter** (if the code calls `client.chat.completions.create(...)`
/ `client.messages.create(...)` directly):

```python
_client: Optional[ProviderClient] = None  # <DISCOVER: the actual SDK client type>

def get_llm_client() -> ProviderClient:
    """One cached client instance. Built lazily, not at import time, so
    importing this module never requires an API key to be present
    (tests and no-key environments must still be able to import it)."""
    global _client
    if _client is None:
        _client = ProviderClient(api_key=settings.llm_api_key)
    return _client

async def create_instrumented_message(*, client=None, **kwargs):
    """Drop-in replacement for client.<create-method>(**kwargs). Same
    return value, same exceptions re-raised unchanged — the only
    difference is that usage gets captured around the call."""
    import time
    started = time.monotonic()
    model = kwargs.get("model", "unknown")
    actual_client = client if client is not None else get_llm_client()
    try:
        response = await actual_client.<create_method>(**kwargs)  # <DISCOVER: exact method name>
    except Exception as exc:
        await record_llm_call(
            model=model, input_tokens=0, output_tokens=0,
            latency_ms=int((time.monotonic() - started) * 1000), status="error", error=str(exc),
        )
        raise  # unchanged behavior for the caller's own error handling
    usage = response.usage  # <DISCOVER: exact attribute path for token counts on this provider's response object>
    await record_llm_call(
        model=model, input_tokens=usage.input_tokens, output_tokens=usage.output_tokens,
        latency_ms=int((time.monotonic() - started) * 1000), status="ok",
    )
    return response
```

Every existing call site changes from:
```python
response = await client.messages.create(model=..., messages=..., ...)
```
to:
```python
response = await create_instrumented_message(model=..., messages=..., ...)
```
— nothing else about the call site changes. Same prompt, same error
handling, same retry logic if any already exists.

**Framework-callback adapter** (if the code uses LangChain or similar,
which has its own callback-handler mechanism rather than a plain function
call to wrap):

```python
class UsageTrackingCallbackHandler(BaseCallbackHandler):  # <DISCOVER: base class for the framework in use>
    def __init__(self, model: str):
        self._model = model
        self._started_at: dict = {}

    async def on_llm_start(self, serialized, prompts, *, run_id, **kwargs):
        self._started_at[run_id] = time.monotonic()

    async def on_llm_end(self, response, *, run_id, **kwargs):
        started = self._started_at.pop(run_id, None)
        latency_ms = int((time.monotonic() - started) * 1000) if started else None
        usage = ...  # <DISCOVER: how this framework exposes token usage on its response object>
        await record_llm_call(model=self._model, input_tokens=usage.input_tokens,
                               output_tokens=usage.output_tokens, latency_ms=latency_ms, status="ok")

    async def on_llm_error(self, error, *, run_id, **kwargs):
        started = self._started_at.pop(run_id, None)
        latency_ms = int((time.monotonic() - started) * 1000) if started else None
        await record_llm_call(model=self._model, input_tokens=0, output_tokens=0,
                               latency_ms=latency_ms, status="error", error=str(error))
```
Attach it once, where the framework's client/chain is constructed:
`ChatOpenAI(..., callbacks=[UsageTrackingCallbackHandler(model=...)])`.

### 5.4 Migrating existing call sites

For each call site found in §4's discovery pass:
1. Swap the direct SDK call for `create_instrumented_message(...)` (or
   confirm the framework callback is attached, if it's a framework call
   site) — no other change to that function.
2. Find the nearest enclosing point where the "parent" record (project/
   workspace/conversation id) is known, and wrap the call to that
   function in `with set_call_context(tenant_id, parent_id, operation_name, run_id):`.
   This is usually one level up from the call site itself — a request
   handler, a background job's entry point, a workflow node — not inside
   the function that calls the LLM.
3. If this call site needs its own dedicated client (noted in §4), wrap
   that client the same way the shared one is wrapped and pass it via
   `create_instrumented_message(client=..., **kwargs)`.

### 5.5 Read API

Role-gate every route to whatever the target app's admin-equivalent role
is. FastAPI shown; translate to Flask (`@admin_required` decorator +
`flask.jsonify`) or Django (a `PermissionRequiredMixin` view + DRF
serializer) as needed — the three endpoints and their SQL don't change.

```python
router = APIRouter(prefix="/api/v1/observability")

@router.get("/parents", dependencies=[Depends(require_admin)])
async def list_parent_usage(limit: int = 50, offset: int = 0):
    """Parents (projects/workspaces/whatever) with at least one LLM call,
    most recently active first — the top level of the drill-down."""
    rows = await db.fetch(
        "SELECT parent_id, COUNT(*) AS call_count, SUM(input_tokens) AS total_input_tokens, "
        "SUM(output_tokens) AS total_output_tokens, SUM(cost_usd) AS total_cost_usd, "
        "MAX(created_at) AS last_call_at FROM llm_calls "
        "GROUP BY parent_id ORDER BY last_call_at DESC LIMIT $1 OFFSET $2",
        limit, offset,
    )
    return rows

@router.get("/parents/{parent_id}/runs", dependencies=[Depends(require_admin)])
async def list_runs_for_parent(parent_id: UUID):
    """Every run_id under this parent, grouped — if the app has an
    existing operation/event log with its own run_id column, source the
    list of runs from THAT table (left-joined with llm_calls totals), not
    from llm_calls alone, so an operation that made zero LLM calls still
    shows up instead of silently vanishing from the drill-down."""
    ...

@router.get("/runs/{run_id}/calls", dependencies=[Depends(require_admin)])
async def list_calls_for_run(run_id: UUID):
    """The individual llm_calls rows for one run — the bottom of the
    drill-down."""
    rows = await db.fetch("SELECT * FROM llm_calls WHERE run_id = $1 ORDER BY created_at", run_id)
    return rows
```

If the target app has distinct user roles where a non-admin user should
see *only their own* usage (not cross-tenant), add a second, narrower
endpoint (e.g. `GET /my-usage`) that hardcodes the `parent_id`/`tenant_id`
filter to the calling user's own records instead of accepting it as a
query param — don't just rely on the frontend to not ask for someone
else's data.

### 5.6 Dashboard(s)

If the target app already has an admin frontend (any stack), add one page
there following its existing conventions — don't introduce a new
frontend framework just for this. If there's no existing frontend
convention to match, a single static HTML page with vanilla JS calling
the three endpoints above is sufficient: a KPI row (total cost, call
count, token count) computed by reducing the same array the table
renders (so the two can never disagree), and a table with click-to-expand
rows for the parent → run → call drill-down.

---

## 6. Feasibility checklist — before applying this pattern to a new area

If you're asked to extend this to track a *different* kind of paid API
call (not just the LLM), or add a second LLM provider for comparison, use
this order:

1. **Grep for every call site first**, not just the ones you already
   know about (§4). Assuming you know the count is how call sites end up
   silently untracked.
2. **Design one choke point, not N.** If more than one call site exists,
   resist writing capture logic at each independently.
3. **Decide the correlation key before writing the schema.** Retrofitting
   one onto an existing table later is much more painful than deciding it
   up front.
4. **Verify third-party SDK behavior empirically before designing around
   it**, especially token-count attribute paths and response shapes —
   provider docs are frequently incomplete or stale on exactly these
   details. Write a 3-line throwaway script that makes one real call and
   inspect the actual response object.
5. **Gate anything new and risky behind a settings flag, off by
   default.** This is what lets you build and merge incrementally without
   any risk to what's already shipped.
6. **Migrate and prove one call site fully before doing the rest.** Get
   one working end-to-end — a real call producing a real row — before
   touching the others. The pattern it proves is what every other site
   copies verbatim.

## 7. Gotchas

- **A call site with its own dedicated client is easy to leave
  unwrapped.** Any call site that can't use the shared singleton client
  (needs its own timeout, its own API key override) is easy to forget
  during review, since it doesn't go through the obvious shared factory
  function. Grep for direct `ProviderClient(...)` construction outside
  the instrumentation module itself as a review signal.
- **"No usage rows" is not always a bug.** If part of the app's pipeline
  is deterministic (template rendering, a rules-based scorer, anything
  that doesn't call the LLM), seeing zero rows for that stage is correct,
  not a gap. Confirm by checking whether the stage actually constructs an
  LLM client at all before assuming instrumentation is missing.
- **An operation that made zero LLM calls still needs to appear in the
  drill-down**, if you're sourcing the "runs" list from an existing event
  log rather than from `llm_calls` alone — otherwise a deterministic
  stage silently disappears from the dashboard instead of showing
  `call_count=0`.
- **Never let the recorder's own exceptions propagate.** Test this
  explicitly: mock the DB write to raise, and assert the LLM call site's
  own return value is unaffected.
- **Recording the context-missing case as a dropped row with a warning
  log (not a raised exception) is deliberate** — a call site that
  genuinely has no attribution context yet (e.g. during initial rollout,
  before every call site has been migrated to set context) must not start
  failing requests just because observability isn't fully wired up yet.

## 8. Verification

1. Unit tests: mock the provider client, assert `record_llm_call` /
   the DB write function is called with the right token counts on
   success, and assert a provider exception is still re-raised unchanged
   after being recorded as `status="error"`.
2. Unit test: the recorder's own DB write raising must not propagate —
   assert the wrapped call's return value is unaffected.
3. One real end-to-end check against a real (even if cheap/small) LLM
   call: confirm a row lands in `llm_calls` with correct token counts and
   a non-zero `cost_usd`, not just that the mocked test passes.
4. Confirm a non-admin role gets 403 on the admin-only read routes.
5. Confirm the full existing test suite still passes unmodified — this
   feature should not change any existing test's expected behavior.

# app/

- Holds only `main.py`: the FastAPI app factory `create_app()` plus a module-level `app`. Run with `uv run uvicorn app.main:app --reload`.
- `main.py` only wires things together: middleware, exception handlers, `src.api.v1.router.api_router`, `/health/live` and `/health/ready`, the `/static` mount, `/` serving `templates/index.html`, and `/pages/<area>/<page>` serving `templates/<area>/<page>.html`.
- No business logic, queries, agents, settings or Pydantic models live here. They live directly in `src/` (layers, `src/config.py`, `src/schemas.py`).
- `app` imports `src`. `src` never imports `app`.
- The first feature creates `main.py` from `.claude/skills/production-api-standards/examples/02-resource-endpoint-end-to-end.md` (section `app/main.py`). Later features only add their router in `src/api/v1/router.py`.
- Tests build the app with `from app.main import create_app` (production-api-standards example 03).

# src/

## What lives here
- All application code: the API layer, agents, tools, guardrails, prompts, and observability.
- `config.py` is the only place for settings: model names, limits, thresholds, retry counts. Nothing else reads environment variables directly.
- `schemas.py` holds the shared Pydantic models. Nullable fields are used wherever the source data may not contain a value.
- `api/v1/router.py` holds `api_router`. Each feature adds its own router here. `app/main.py` includes it and is not edited for new features.

## Folders
- `api/` request handling only. It validates input, calls the layer below, and returns the response.
- `agents/` one file per agent. Agent loops branch on `stop_reason`.
- `tools/` one file per tool plus `registry.py`. Handlers never raise. Failures return structured error results.
- `guardrails/` code-level gates for anything that must never go wrong: limits, identity checks, approval steps.
- `prompts/` prompt text in `.md` or `.txt` files, loaded by agents. No long prompts inline in code.
- `observability/trace.py` logs every tool call with latency and cost.

## Dependency direction
- `src` never imports `app`.
- Dependencies flow one way: `api` calls `agents`, `agents` use `tools` and `guardrails`, and `tools` never import `agents` or `api`.
- Every package folder contains an `__init__.py`.

## Conventions
- One responsibility per file, under about 200 lines.
- Every tool call goes through `trace.py`.
- Guardrails run in code on every call, whatever the prompt says.
- Source references travel with every claim an agent produces.

# static/

- Files in this folder are served as-is at `/static`, through the mount in `app/main.py`.
- Contents are plain CSS, JavaScript, images and fonts. There is no build step.
- No server logic, secrets, API keys, or generated data live here. Anything in this folder is public to anyone who can open the page.
- Pages in `templates/` reference these files by their `/static/...` URL.
- Files are named in lowercase with hyphens (for example `app-styles.css`).
- Scripts call the backend only through `/api/v1/...` endpoints.
- Assets are kept small so the demo loads quickly on any network.

# templates/

- Holds the HTML pages the app serves. `app/main.py` serves `index.html` at `/` and `templates/<area>/<page>.html` at `/pages/<area>/<page>`.
- Adding a page means adding a file at `templates/<area>/<page>.html`. No new route is needed.
- Templates use Jinja2 syntax with autoescape on. Content that came from documents or users is always escaped.
- Common head, navigation and layout live in `base.html`. Pages extend it.
- Pages hold presentation only. Business logic, queries and secrets stay in `src/`. Pages fetch data from `/api/v1/...` endpoints.
- Scripts and styles come from `/static/...`. Inline scripts are kept to a few lines.
- The demo flow has its own clearly named page so it can be opened directly during the pitch.

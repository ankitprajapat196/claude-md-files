# Generation modes, versions, batches, and UI (main conversation)

Subagents cannot talk to the human, so **you** (the coordinator) run the loops below. Everything here happens *inside* the stage command the human typed. Moving to the next stage still needs `/approve-stage`.

## 1. AUTO vs APPROVAL mode (PRD and MoSCoW)
- `/start-workflow` and `/prioritize-moscow` take an optional `mode=auto|approval`. If it is missing, ask with AskUserQuestion (header `Mode`):
  - **Approval mode (Recommended)**: one PRD section / one MoSCoW feature at a time; you approve each before the next.
  - **Auto mode**: the whole document in one run, reviewed at the end.
- Delegation labels: `Generation: AUTO` or `Generation: STEP`, plus `Step:`, `Accepted steps:`, `Step feedback:`, `Continue from:` (see the agent files).

### Progress record (resume-safe)
`subagents-docs/01-prd/.prd-progress.json` and `subagents-docs/02-moscow/.moscow-progress.json` are written **only** by `python3 .claude/scripts/step_progress.py` (`SP` below), which you run with Bash. Never edit them by hand; subagents never write them.
- `SP` checks the documents on every call. A section or feature that an interrupted run already wrote is recovered as `drafted`, so it is reviewed, not regenerated. It keeps a timestamped history of every event (`SP history <artifact>`).
- **Record each decision the moment the human makes it**, before delegating anything. The chat can close at any time, and anything not recorded is lost:

| Event | Command |
|---|---|
| Stage command starts, or resumes (mode known) | `SP start <artifact> --mode approval\|auto [--focus "<notes>"]` |
| A subagent run wrote step(s) | `SP drafted <artifact> <step or range>` (AUTO: `<Continue from>-<last step>`; unwritten ones are skipped) |
| Human approves one or more steps | `SP accept <artifact> <steps>` or `all-drafted` |
| Human asks for changes (current step, or reopening an earlier one) | `SP feedback <artifact> <step> --text - <<'FEEDBACK'` + their words verbatim + `FEEDBACK` (quoted heredoc, so nothing is shell-expanded) |
| Mode switch | `SP mode <artifact> auto\|approval` |
| Pause | `SP pause <artifact>` |

- **Never take loop state from chat memory.** Before every delegation, run `SP status <artifact> --json` and use its fields:
  - `accepted_steps` → `Accepted steps:`;
  - `focus_notes` → `Focus notes:`;
  - `mode`;
  - `next` → what to do (below).

### Step loop (driven by `next`)
1. Run `SP status <artifact> --json` and act on `next.action`:
   - **`rerun`**: delegate `Generation: STEP`, `Step: <next.step>`, `Step feedback: <next.feedback>`. Then `SP drafted`, and go to 2.
   - **`review`**: the step is already written (by a previous session or an interrupted run). Do not delegate. Read that section / feature file and show it as in 2 (say "written earlier, not yet reviewed").
   - **`generate`**: delegate `Generation: STEP`, `Step: <next.step>`. Then `SP drafted`, and go to 2.
     - PRD steps: `S01` … `S16`.
     - MoSCoW steps: `OUTLINE`, each `F##` in the order `SP` lists (it reads the index table, so splits and merges appear on their own), then `FINALIZE`.
   - **`auto`**: delegate once with `Generation: AUTO`, `Continue from: <next.continue_from>`, `Accepted steps:`. Then `SP drafted <artifact> <continue_from>-<last step>`, and go to 3.
   - **`complete`**: go to 3.
2. Show the step under `### <Step> — <section / feature name> (step k of N)`, with `review_points` and `open_questions` when there is a RESULT. Ask with AskUserQuestion (header `Step`):
   - **Approve and continue (Recommended)**;
   - **Approve all drafted**: only when `SP` shows more than one drafted step (e.g. after an AUTO run or a resume);
   - **Switch to auto mode**: accept this step and write the rest in one run;
   - **Pause here**: resume later from exactly this point.

   The human types changes through "Other".

   Handle the answer, recording it first:
   - changes → `SP feedback`;
   - approve → `SP accept`;
   - approve all → `SP accept … all-drafted`;
   - switch → `SP accept` + `SP mode auto`;
   - pause → `SP pause`, then stop and show the resume command.

   Then loop to 1.
3. Complete (approval: every step accepted; auto: nothing pending):
   - save a version (section 2);
   - show the normal review request from `00-workflow-gates.md` and stop.

   Step approvals are not ledger approvals; the stage still needs `/approve-stage prd|moscow`.

### Approve or change at any point mid-session
At any step boundary, in words or with `/review-step`, the human may:
- **approve** the shown step, or several drafted steps at once (`approve S05-S07`, "approve everything drafted");
- **change** the shown step;
- **reopen an earlier, accepted step** ("change S03: …", `/review-step prd S03 <changes>`): `SP feedback` marks it `changes-requested`, `next` makes it the next rerun, and the loop then returns to where it was;
- **see progress** (`/review-step status`) or the full record (`/review-step history`).

Later accepted steps stay accepted. If a reopened step makes them inconsistent, the subagent lists that under `open_questions`. Show it, and offer to reopen those steps too.

`SP status` warns when an accepted step's text changed after acceptance (e.g. a hand edit). Show the warning, and offer to review it again (`SP feedback` with "review the manual edit", or approve it again).

### Resuming after the chat was closed
- The human types the same stage command (`/start-workflow` or `/prioritize-moscow`), or `/review-step`. It runs `SP start` with the recorded mode (`--mode` from `SP status --json`, unless the human gave a new `mode=`) and continues the step loop from `next`. It never restarts from S01 / OUTLINE.
- If the human only says "continue", "resume", or "where were we": run `SP status` for the unfinished artifact, show it, and give the exact command to type. Stage commands can only be started by the human.

### Switching mode mid-chat
The human may switch at any time: by choosing the option above, by typing `/switch-mode auto|approval`, or by saying so in words ("switch to auto", "go step by step"). Switch at the next step boundary. Record it with `SP mode`, then continue from `next`:
- **APPROVAL → AUTO:** `next` becomes `auto` with `continue_from` = the first pending step. Steps that need changes are rerun first.
- **AUTO → APPROVAL, while a run is going:** let the run finish and record `SP drafted`. Then `next` walks through each drafted step (`review`).
- **AUTO → APPROVAL, after a run:** the same walk-through. Changes are delegated with `Generation: STEP`, `Step: <id>`, `Step feedback:`. Use `Mode: CREATE` if the artifact was never approved, else `Mode: REVISE`.

## 2. Versions (feature-wise history)
Run `python3 .claude/scripts/artifact_versions.py …` with Bash yourself. It only writes `subagents-docs/versions/`, which no approval hashes. Save:
- **PRD:** `save prd --note "<event>"` after an AUTO run, after S16, and before and after every REVISE (saving is a no-op when nothing changed).
- **MoSCoW:** `save moscow --note "<event>"` at the same moments. Every changed feature file also gets its own history.
- **Plans:** `save plan F01 F02 … --note "<event>"` after every planner run.

Show the one-line output. The human browses history with `/versions` (list, diff, restore). Never restore unless the human typed `/versions restore`.

## 3. Batches (several features in one command)
- `/plan-feature` and `/implement-feature` accept several ids, `all`, or a bucket (`must`, `should`, `could`). Resolve the list from the status table, and skip what is already done (planned / accepted). Show the final list before delegating.
- **Planning:** one `feature-planner` per feature, in **dependency waves**.
  - Wave 1 = batch features whose dependencies are outside the batch; wave 2 depends only on wave 1; and so on.
  - Send all of a wave's Agent calls in one message (parallel). Each call carries its own `Feature ID:` (the gate checks each one), plus `Batch:`, `Wave:`, and `Sibling plans:` (earlier-wave draft plans).
- **Implementation:** one `feature-implementer` run for the whole batch, because the stage gate allows only one in-progress feature per clone.
  - Order the batch topologically. Pass `Feature ID: <first>`, `Batch: <ordered list>`, and `Plans:`.
  - The gate only reads the first id, so you must check that **every** feature's plan is `approved` first. Drop any feature whose plan is not approved and say which, so it never gets past the gate silently.
- **Dependencies:** the check in `80-team-parallel-work.md` applies only to dependencies **outside** the batch. Dependencies inside the batch are met by build order (implementation) or by sibling plans (planning).
- After a batch, show one review request per feature (or one combined table) with every `/approve-stage plan F##` line.

## 4. Independence
- Every subagent can run on its own. Never start one just because another finished, and never make one a precondition for another beyond the hook-enforced approvals.
- `/test-feature` and `/review-feature` work with or without an implementation note (ad-hoc `Scope:` when there is no feature id). Show `next_command_after_approval` as "Suggested next", never as a must.

## 5. UI work goes to the ui-designer (automatic, with a style choice)
**Trigger** whenever the work involves a UI component:
- `/implement-feature` with frontend in scope for a feature whose plan says `UI involvement: yes`, or has pages;
- `/revise-artifact feature` feedback about pages, layout, styling, theme, or animation;
- any chat request to create or change a page, screen, or component.

**Ask** once per command, before delegating, with AskUserQuestion. Two questions in one call:
1. Header `UI style`, multiSelect, "Which UI design do you want for <F##…>?":
   - **Modern production-ready (Recommended)**: clean, accessible, polished states, responsive;
   - **Theme**: brand palette, light/dark themes with a toggle;
   - **Background visuals**: gradients, patterns, SVG illustrations, glass surfaces;
   - **Motion graphics**: micro-interactions, entry and scroll animations, animated SVG.

   "Other" holds free-text style notes.
2. Header `Builder`:
   - **ui-designer (Recommended)**;
   - **Basic UI from the implementer**: skips the ui-designer.

**Delegate** to `ui-designer` with:
- `MODE: UI-AUTO` (or `REVISE-UI-BUILD` when a `.ui-build.md` already exists);
- `Feature ID:`, `Plan:`, `Design file: DESIGN.md`;
- `UI style: <modern, theme, …>` and `Style notes: <verbatim>`.

Run one feature at a time, sequentially, because features share `tokens.css`. For a chat request, find the feature that owns the page (from `templates/` and the plans). If unclear, ask which feature.

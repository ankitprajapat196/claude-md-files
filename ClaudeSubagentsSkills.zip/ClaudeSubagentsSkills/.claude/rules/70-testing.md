---
paths:
  - "tests/**"
  - "tests/frontend/**"
  - "subagents-docs/07-test-reports/**"
---

# Tests

- Follow the `testing-standards` skill: every acceptance criterion has a test; failure paths (401, other-user 404, 422, 409, 412/428, empty lists, agent timeouts/empty/partial results) are covered.
- Tests are deterministic: in-memory SQLite, fixed mock data, fake Messages API, no network.
- Test reports start with `**Overall result:** PASS`, `FAIL`, or `MOCKED`; PASS only when everything passes, every AC is covered, and no dependency is mocked. MOCKED when the code still runs on `DEP-MOCK` mocks (see `80-team-parallel-work.md`).

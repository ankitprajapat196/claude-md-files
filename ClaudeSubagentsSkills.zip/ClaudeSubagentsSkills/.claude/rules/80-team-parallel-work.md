# Team parallel work and feature dependencies

After MoSCoW is approved, each of the 4 teammates works alone in their own clone on their own branch (`feat/F##-<slug>`). Approvals live in `.workflow/approvals/` and travel through git, so a teammate's work becomes visible here only after they push it and you pull it. `.workflow/local/` (the in-progress marker and activity log) is per clone and is never committed.

## Before starting a stage
- Run `git pull` (or merge `main`) so you see teammates' accepted features and approvals.
- Commit code together with its `.workflow/approvals/` files, and push after every approval so teammates can pull it.
- In shared files (`src/schemas.py`, `src/dependencies/providers.py`, `src/api/v1/router.py`, `app/main.py`), add only your feature's own section or lines. Do not reformat or reorder other features' code; this keeps merges small.

## Dependency check (used by `/plan-feature`, `/implement-feature`, `/design-agent`, `/build-agent`)
1. Read the feature's `Depends on:` line in `subagents-docs/02-moscow/*/<F##>-*.md` (or the `Depends on` column in `subagents-docs/02-moscow/00-MOSCOW-INDEX.md`).
2. A dependency is **met** when:
   - for planning or design: its plan is `approved` or the feature is accepted (the status table shows it);
   - for implementation or build: the feature is accepted (`accepted = yes` in the status table).
   - in a batch command (several ids, `all`, or a bucket), a dependency that is **in the same batch** counts as met: implementation builds it first in the same run, and planning plans it in an earlier wave. Check only dependencies outside the batch, and ask the question once for the whole batch.
3. If every dependency is met, or there are none, continue silently.
4. Otherwise, list the unmet ones with their names, then ask the human with AskUserQuestion (header `Dependency`, one question, these two options):
   - **A. Wait for the teammate.** Stop the stage and show:
     - a ready-to-send message for the teammate who owns `<F##>`: "I need `<F##> <name>` for `<this F##>`. Please finish it, get it accepted (`/approve-stage feature <F##>`), then commit the code with its `.workflow/approvals/` files and push `feat/<F##>-<slug>`.";
     - if they say it is already pushed: `git pull` (or `git merge origin/feat/<F##>-<slug>`) here, then rerun this same command;
     - meanwhile, one or two other features from the status table with no unmet dependencies.
   - **B. Mock the dependency and continue.** Continue the stage and add `Dependency mode: MOCK <F##>,<F##>` to the delegation message. For implementation, the stage-gate hook may then ask its own "Continue anyway?" question; the human answers yes. Then say the mock lifecycle in one line: build on mocks → `/test-feature` on mocks → when `<F##>` is accepted, `/connect-dependency <F##>` → `/test-feature` again → accept.
5. Never choose an option for the human.

## Mock rules (Dependency mode: MOCK)
- **Planning:** plan against the dependency's assumed contract, taken from its MoSCoW file, its plan if one exists, and the PRD. Add a section `## Assumed dependency contracts` that lists, per dependency, the functions, endpoints, schemas, and fields relied on, each marked `ASSUMED (F##)`.
- **Implementation:** put mock code only in new files that belong to this feature:
  - backend: `src/mocks/dep_<f##>.py` (for example `src/mocks/dep_f02.py`), a fake class or functions matching the assumed contract, returning deterministic data;
  - frontend: `static/js/mocks/dep-<f##>.js`.
- Never create or edit files that belong to the dependency feature itself; its owner is building them.
- Every line outside the mock files that wires a mock in (imports, the provider in `providers.py`, a fallback) carries the comment `DEP-MOCK(<F##>)`. The mock files start with a module docstring containing `DEP-MOCK(<F##>)`.
- The implementation note gets a `## Mocks to remove` table: dependency, mock file, wiring lines (file:line), real target to wire instead, status (`active` / `removed`).
- Tests may run against the mocks. A test report on mocks says `**Overall result:** MOCKED`, never PASS, so the approval hook refuses `/approve-stage feature` until the mocks are gone and the feature is retested.

## Connecting the real dependency (`/connect-dependency`)
When the teammate's `<F##>` is accepted and pulled (or merged with `--from <branch>`), `/connect-dependency <F##>` finds every feature in this clone that mocks it and sends them to `feature-implementer` with `Mode: CONNECT`. That run:
- deletes the mock files and every `DEP-MOCK(<F##>)` wiring line, and wires the real `<F##>` code;
- compares each `ASSUMED (<F##>)` item with the real contract and adapts only the consuming feature's own code;
- reruns the tests and records a `## Dependency connections` section in the implementation note.

Then the human runs `/test-feature <this F##>` for a fresh PASS report and accepts the feature.

## Mock-removal reminder
`/test-feature`, `/review-feature`, `/approve-stage feature`, and `/show-status` search for `DEP-MOCK` (Grep tool over `src/`, `static/`, `templates/`, `tests/`, `app/`). For each mocked dependency of the feature, show:
- If the dependency is now accepted here: "Mocks for `<F##>` are still in place. Connect the real feature now: `/connect-dependency <F##>`", then "After that, rerun `/test-feature <this F##>`."
- If the dependency is still not accepted: "`<this F##>` runs on mocks of `<F##>`. Do not accept it yet. When `<F##>` is accepted, pull it (or use `/connect-dependency <F##> --from feat/<F##>-<slug>`) to connect it."

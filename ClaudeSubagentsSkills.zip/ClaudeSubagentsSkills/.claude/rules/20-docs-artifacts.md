---
paths:
  - "subagents-docs/**"
---

# Docs and artifacts

- Naming, IDs, templates, and the RESULT block are defined in the `workflow-artifacts` skill; follow them exactly (hooks parse `F##-<slug>`, `AD##-<slug>`, `Depends on:`, and `**Overall result:** PASS|FAIL|MOCKED`; only PASS can be accepted).
- Never write "Approved" in a document; the approval ledger in `.workflow/approvals/` is the only source of truth.
- Editing an approved artifact invalidates its approval (content hash). Only edit approved artifacts through `/revise-artifact` (or `/versions restore`, typed by the human).
- Version history lives in `subagents-docs/versions/` and is written only by `.claude/scripts/artifact_versions.py`. Never edit it by hand.
- Progress records (`subagents-docs/01-prd/.prd-progress.json`, `subagents-docs/02-moscow/.moscow-progress.json`) are written only by `.claude/scripts/step_progress.py`, which the coordinator runs. Subagents never write them; they keep `_Pending (…)_` placeholders and write one section / feature at a time so the script can see their progress.
- Keep slugs stable across all artifacts of the same item.

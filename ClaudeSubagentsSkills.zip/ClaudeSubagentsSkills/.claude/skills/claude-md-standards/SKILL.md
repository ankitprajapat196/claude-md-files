---
name: claude-md-standards
description: Rules for creating and updating CLAUDE.md context files (root and folder-level) so they stay short, specific, and free of instructions that belong elsewhere - what Claude Code loads when, where each kind of information belongs, when a folder deserves its own CLAUDE.md, what to include and exclude, size budgets, templates, and how to update an existing file. Use whenever proposing, writing, reviewing, or trimming a CLAUDE.md.
user-invocable: false
---

# CLAUDE.md standards

Every line of a CLAUDE.md costs context in every session that loads it. A line belongs only if Claude would otherwise make a mistake or waste time **in most sessions in that scope**.

## 1. What Claude Code loads, and when

| Source | When it is in context | Use it for |
|---|---|---|
| Root `CLAUDE.md` (and `.claude/CLAUDE.md`) | **Every session, every turn** | Whole-project facts most tasks need |
| `<folder>/CLAUDE.md` | Only after Claude reads or edits files in that folder | Facts needed only while working there |
| `.claude/rules/*.md` **without** `paths:` | Every session | Always-on policy (this kit: workflow gates, generation modes, security, team work) |
| `.claude/rules/*.md` **with** `paths:` | Only when Claude works on matching files | Coding conventions for a file type or area |
| Skills (`.claude/skills/*/SKILL.md`) | Only the `description` always; the body when the skill is used | Long how-tos, standards, examples, templates |
| `@path` import inside a CLAUDE.md | Loaded **together with** the importing file | Rarely: a short file that is truly needed in that scope. Never import long docs |
| `~/.claude/CLAUDE.md`, `CLAUDE.local.md` | Per person, not shared | Personal preferences (never in the repo's CLAUDE.md) |

## 2. Where each kind of information goes

| Information | Goes in |
|---|---|
| What the product is (1 line), stack, how to install / run / test / lint, top-level map, where generated docs live | Root `CLAUDE.md` |
| A folder's entry points, local commands, local map, local traps | That folder's `CLAUDE.md` |
| "Always / never" coding conventions for a path or file type | Path-scoped `.claude/rules/` file. The CLAUDE.md **points** to it and never copies it |
| Step-by-step procedures, reference tables, code examples | A skill |
| PRD content, feature specs, API contracts, plans, statuses | `subagents-docs/` (stage artifacts). Never in CLAUDE.md |
| Who works on what, current sprint, approval state, dates | Nowhere static: `/show-status`, git, the approval ledger |
| Secrets, tokens, real personal data | Nowhere. Config comes from env vars documented in `.env.example` |

**This kit already ships** these path-scoped rules. A CLAUDE.md must not restate them:

| Rule file | Scope |
|---|---|
| `30-backend-python.md` | `app/**/*.py`, `src/**/*.py` |
| `40-api-layer.md` | `src/api/**`, `src/schemas.py`, `src/services/**` |
| `50-agentic-code.md` | `src/agents/**`, `src/tools/**`, `src/guardrails/**`, `src/prompts/**`, `src/observability/**` |
| `60-frontend.md` | `static/**`, `templates/**` |
| `70-testing.md` | `tests/**` |
| `20-docs-artifacts.md` | `subagents-docs/**` |

The always-on rules (`00`, `05`, `10`, `80`) cover the workflow, security, and team work.

## 3. Does a folder deserve its own CLAUDE.md?

Propose a folder file only with **at least one strong reason, backed by evidence** (file counts, manifests, commands found, or a rules gap):

- **Distinct stack or runtime** from the root: backend vs. frontend vs. infra, MCP server, scripts.
- **Own commands** that differ from the root ones: its own test runner, build, seed, or dev server.
- **Non-obvious local structure**: entry points, generated or vendored files nobody should edit, a module that must stay import-free, or a wiring order.
- **Recurring traps** seen in debug reports, reviews, or implementation notes (`subagents-docs/09-…`, `06-…`, `05-…`).

Do **not** propose one when:
- the folder is small (about 5 files or fewer) and self-explanatory;
- its guidance is already in a path-scoped rule;
- it is generated, vendored, or a cache (`.venv/`, `node_modules/`, `__pycache__/`, `migrations/versions/`, `data/fixtures/`);
- it is a docs folder (`subagents-docs/`);
- a parent folder's CLAUDE.md already covers it.

Prefer **one file per area** (`src/CLAUDE.md`) over one per subfolder.

Each proposal states its reason in one sentence, citing the evidence. Example: "`src/` holds 34 Python files across 6 layers with its own wiring order (`providers.py` → `router.py`); `30-backend-python.md` covers style but not this map."

## 4. Content rules

**Include** (only what passes the test at the top):
- one line on what the project or folder is for;
- **exact** commands: install, run, full test, single test, lint, seed. Copy them from manifests or the docs; never invent;
- a map of the entry points and key folders that are not obvious from names;
- project-specific conventions that are **not** in `.claude/rules/` or a skill and **not** visible from the code in one read;
- traps: things that broke before and how to avoid them;
- pointers (paths) to the rule, skill, or doc that holds the details.

**Exclude:**
- anything already in `.claude/rules/` or a skill. Write a pointer (`Conventions: .claude/rules/30-backend-python.md`) or nothing, since path-scoped rules load anyway;
- generic advice: "write clean code", "follow best practices", "be careful", "use meaningful names";
- what the code says plainly: a list of every file, a function-by-function description, the dependency list from `pyproject.toml`;
- volatile facts: feature status, who owns what, dates, sprint goals, versions that change weekly;
- feature specs, API contracts, PRD text, MoSCoW lists (they live in `subagents-docs/`);
- code blocks longer than about 8 lines;
- the same instruction in both the root and a folder file;
- workflow or approval rules (always-on rules in `.claude/rules/` already carry them);
- secrets, hostnames with credentials, `.env` values, real personal data.

**Style:** imperative, specific, testable bullets ("Run `uv run pytest -q tests/api`", not "tests should be run"). Use headings and bullets, no prose paragraphs, no emojis, and no marketing.

## 5. Size budgets

| File | Target | Hard limit | Over the limit? |
|---|---|---|---|
| Root `CLAUDE.md` | 30–60 lines | 80 lines | Move conventions to a path-scoped rule, procedures to a skill |
| Folder `CLAUDE.md` | 10–30 lines | 40 lines | Split the guidance, or move it to a rule with `paths:` |

Count the lines of every draft and report them. Cut the weakest lines first.

## 6. Templates

**Root:**
```markdown
# <Project name>
<One line: what it is and for whom.>

## Commands
- Install: `…`
- Run: `…`
- Test all / one: `…` / `…`
- Lint: `…`

## Map
- `app/main.py`: <role>
- `src/`: <role> (details in `src/CLAUDE.md`)
- `subagents-docs/`: generated workflow documents (PRD, plans, reports)

## Project conventions
- <only what no rule or skill covers>

## Traps
- <thing that broke before + how to avoid it>
```

**Folder:**
```markdown
# <folder>/: <purpose in one line>

## Entry points
- `<file>`: <role>

## Commands
- `<command>`: <when to use it>

## Local rules
- <only the deltas from the root and from path-scoped rules>

## Traps
- <…>
```

Drop any heading that would be empty.

## 7. Updating an existing CLAUDE.md

- Read the whole file first. Keep human-written content unless it is **wrong** (contradicted by the code or manifests, with evidence) or **duplicated** (by a rule, a skill, or another CLAUDE.md, naming which).
- Propose the update as a list of changes (add / change / remove + reason), plus the complete new text.
- Never silently drop a section. Removal is a listed change the human sees before anything is written.
- Keep the file inside the budget after the update.

## 8. Self-check before proposing or writing

- [ ] Each line passes the test at the top.
- [ ] Nothing duplicates `.claude/rules/`, a skill, or another CLAUDE.md.
- [ ] Commands were copied from real manifests, scripts, or docs.
- [ ] No volatile facts, specs, or secrets.
- [ ] The file is within budget (line count reported).
- [ ] Every folder file has an evidence-based reason.

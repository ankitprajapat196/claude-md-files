# MoSCoW prioritisation — <Product name>

| Field | Value |
|---|---|
| Version | v1.0 |
| Status | Draft / Ready for review |
| Source PRD | `subagents-docs/01-prd/PRD.md` (version vX.Y) |

## Capacity check
- Budget: ~30 hours x 4 people ≈ 120 person-hours; reserve 25% for integration, bugs, demo prep → ~90 build hours.
- Must-have total: <h> (target ≤ 60% of build hours). Should: <h>. Could: <h>.

## Feature table
| ID | Feature | Category | User stories | Depends on | Effort (S≤3h / M≤6h / L≤10h) | Independently testable? | How to test alone | File |
|---|---|---|---|---|---|---|---|---|
| F01 | | Must | US-01 | none | M | Yes | API tests with mock data | `must-have/F01-<slug>.md` |

## Build order
```mermaid
flowchart LR
  F01 --> F02
```
1. F01 — why first
2. …

## Parallelisation for 4 people
| Track | Features | Notes |
|---|---|---|

## Won't have (this hackathon)
See `wont-have.md`.

## Rationale
- Must: …
- Should: …
- Could: …

## Revision history
| Version | Date | Change | Reason / feedback |
|---|---|---|---|

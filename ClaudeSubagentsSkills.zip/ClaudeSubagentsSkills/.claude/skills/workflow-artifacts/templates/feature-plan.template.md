# Plan — F## <Feature name>

| Field | Value |
|---|---|
| Version | v1.0 |
| Status | Draft / Ready for review |
| Feature file | `subagents-docs/02-moscow/<category>/F##-<slug>.md` |
| PRD refs | US-##, FR-## |
| Depends on | none / F## |

## 1. User story (final)
As a <persona>, I want <capability> so that <benefit>.

## 2. Acceptance criteria
| # | Given | When | Then | Test id |
|---|---|---|---|---|

## 3. Functionality
- What the user can do, step by step.
- UI states: loading, empty, error, success (and partial if relevant).

## 4. Business logic and rules
| ID | Rule | Enforced in (service / schema / DB) | Error code + HTTP status |
|---|---|---|---|
| BR-01 | | | `CODE` 422 |
- State transitions (if any):
```mermaid
stateDiagram-v2
  [*] --> todo
```
- Edge cases and failure paths (empty input, duplicates, concurrency, external failure, timeouts).

## 5. Flow
```mermaid
sequenceDiagram
  participant UI as Page controller
  participant C as Controller
  participant S as Service
  participant D as DAO
  participant DB as PostgreSQL
  UI->>C: request
  C->>S: validated DTO
  S->>D: persistence call
  D->>DB: SQL
  DB-->>D: rows
  D-->>S: model
  S-->>C: response DTO
  C-->>UI: {data, meta}
```

## 6. API contract
| Method | Path | Auth | Request schema | Success (status + schema) | Errors (status: CODE) | Idempotency / concurrency | Pagination |
|---|---|---|---|---|---|---|---|
Example request/response JSON for success AND one error (problem+json).

## 7. Data model changes
| Table | Column | Type | Null | Index | Notes |
|---|---|---|---|---|---|
Migration: <alembic revision description>. Tenant/owner column enforced in every query.

## 8. Layer design (Controller -> Service -> DAO -> Schema)
| Layer | File | Class / function | Responsibility |
|---|---|---|---|
| Schema | `src/schemas.py` (section `# --- <x> ---`) | | request/response DTOs |
| DAO | `src/dao/<x>_dao.py` | | queries, owner-scoped |
| Service | `src/services/<x>_service.py` | | rules, transaction |
| Provider | `src/dependencies/providers.py` | `get_<x>_service` | wiring |
| Controller | `src/api/v1/controllers/<x>_controller.py` | | HTTP adapter |

## 9. Frontend plan
| Page / module | File | States | Validation (mirrors schema) | API calls |
|---|---|---|---|---|

## 10. AI / agent involvement
none | AD## (link) | needs `/design-agent` first.

## 11. Production checklist mapping
| Checklist section | Applies? | How this feature satisfies it |
|---|---|---|
| Auth / BOLA | | |
| Input validation | | |
| Idempotency | | |
| Pagination | | |
| Errors (RFC 9457) | | |
| Logging / request id | | |

## 12. Test plan
| Test id | Type (unit/integration/negative/e2e) | Scenario | Expected | Mock data |
|---|---|---|---|---|

## 13. Implementation tasks (each ≤ 2 h, in order)
| # | Task | Layer | Est. | Suggested owner |
|---|---|---|---|---|

## 14. Risks and open questions
- OPEN QUESTION: …

## Revision history
| Version | Date | Change | Reason / feedback |
|---|---|---|---|

# Test report — <F## / AD##> <Name>

**Overall result:** PASS | FAIL | MOCKED

<!-- MOCKED: the target runs on DEP-MOCK dependency mocks; add the line `**Tests on mocks:** PASS | FAIL`. Only PASS lets the feature be accepted. -->

| Field | Value |
|---|---|
| Date | |
| Command(s) | `uv run pytest -q tests/...` |
| Totals | passed / failed / skipped |

## Acceptance criteria coverage
| AC | Test(s) | Result |
|---|---|---|

## Results by type
| Type | Count | Passed | Notes |
|---|---|---|---|
| Unit | | | |
| Integration (API) | | | |
| Negative / security (401, 404-not-403, 422, 409, 412) | | | |
| Agent/workflow failure paths (timeouts, empty, partial) | | | |
| Frontend (node --test) | | | |

## Failures
| Test | Error | Suspected cause | Suggested fix |
|---|---|---|---|

## Gaps not covered
-

## Revision history
| Version | Date | Change |
|---|---|---|

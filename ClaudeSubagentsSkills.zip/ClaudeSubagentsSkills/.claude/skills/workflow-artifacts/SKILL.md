---
name: workflow-artifacts
description: Shared contract for every CyberBulls workflow stage - artifact folders, file naming, ID formats, document templates, revision history, and the RESULT block each subagent returns. Use whenever creating or revising a PRD, MoSCoW file, feature plan, agent design, implementation note, review, test report, mock-data report, debug report, or demo document.
user-invocable: false
---

# Workflow artifacts contract

## Where every artifact goes

| Stage | Owner subagent | Path (exact naming) |
|---|---|---|
| 1 PRD | prd-analyst | `subagents-docs/01-prd/PRD.md` |
| 2 MoSCoW | moscow-prioritizer | `subagents-docs/02-moscow/00-MOSCOW-INDEX.md`, `subagents-docs/02-moscow/{must-have,should-have,could-have}/F##-<kebab-slug>.md`, `subagents-docs/02-moscow/wont-have.md` |
| 3 Feature plan | feature-planner | `subagents-docs/03-feature-plans/F##-<slug>.plan.md` |
| Agent design | agent-architect | `subagents-docs/04-agent-designs/AD##-<slug>.design.md` |
| 4 Implementation note | feature-implementer / agent-architect | `subagents-docs/05-implementation-notes/F##-<slug>.impl.md` or `AD##-<slug>.impl.md` |
| Review | code-reviewer | `subagents-docs/06-reviews/F##-<slug>.review.md` (or `AD##-...`) |
| Test report | test-engineer | `subagents-docs/07-test-reports/F##-<slug>.test-report.md` (or `AD##-...`) |
| Mock data | mock-data-generator | `subagents-docs/08-mock-data/MD##-<slug>.mock-data.md` + files in `data/fixtures/` |
| Debug report | debugger | `subagents-docs/09-debug-reports/BUG##-<slug>.debug.md` |
| Demo | demo-pitch-writer | `subagents-docs/10-demo/DEMO_SCRIPT.md`, `subagents-docs/10-demo/PITCH_OUTLINE.md`, `subagents-docs/10-demo/JUDGES_README.md` |
| UI plan / UI build note | ui-designer | `subagents-docs/11-ui-designs/F##-<slug>.ui-plan.md`, `subagents-docs/11-ui-designs/F##-<slug>.ui-build.md` |
| Step-mode progress record | coordinator via `.claude/scripts/step_progress.py` (never a subagent) | `subagents-docs/01-prd/.prd-progress.json`, `subagents-docs/02-moscow/.moscow-progress.json` (decisions, mode, focus notes, history) |
| Case-study digest | prd-analyst | `subagents-docs/01-prd/.case-study-digest.md` |
| CLAUDE.md proposal | claude-md-curator | `subagents-docs/12-context/CLAUDE-MD-PROPOSAL.md` (the approved CLAUDE.md files themselves go to the root / folders) |
| Ad-hoc test report | test-engineer | `subagents-docs/07-test-reports/ADHOC-<scope-slug>.test-report.md` |
| Versions | coordinator via `.claude/scripts/artifact_versions.py` (never a subagent) | `subagents-docs/versions/` (`VERSIONS.md`, `index.json`, `prd/`, `moscow/`, `features/F##-<slug>/{moscow,plan}/`) |

- `<slug>`: lowercase kebab-case, 2-5 words, reused unchanged by every later artifact of the same item (F03-slot-booking.plan.md -> F03-slot-booking.impl.md).
- IDs: features `F01`..`F99` (two digits), agent designs `AD01`.., user stories `US-01`, functional requirements `FR-01`, business rules `BR-01`, mock datasets `MD01`, bugs `BUG01`. Never renumber an existing ID; append new ones.
- Next free number: list the folder and take max + 1.

## Templates (read the one you need, fill every section)

- PRD: `templates/prd.template.md`
- MoSCoW index / one feature: `templates/moscow-index.template.md`, `templates/moscow-feature.template.md`
- Feature plan: `templates/feature-plan.template.md`
- Agent design: `templates/agent-design.template.md`
- Implementation note: `templates/implementation-note.template.md`
- Review: `templates/review.template.md`
- Test report: `templates/test-report.template.md`
- Mock data: `templates/mock-data.template.md`
- Debug report: `templates/debug-report.template.md`
- Demo docs: `templates/demo.template.md`
- UI plan: `templates/ui-plan.template.md`

Paths are relative to `.claude/skills/workflow-artifacts/`.

## Writing rules

- Fill every template section. If a section does not apply, write `N/A - <one-line reason>`; never delete headings.
- Trace everything: user stories cite personas, features cite `US-##`, plans cite `FR-##`/`BR-##`.
- Diagrams are Mermaid code blocks (flowchart, sequenceDiagram, stateDiagram-v2, erDiagram).
- Mark unknowns explicitly as `ASSUMPTION:` or `OPEN QUESTION:`; never invent facts that are not in the inputs.
- Status header: `Draft` while writing, `Ready for review` when done. Never write `Approved`: only the human approves, via `/approve-stage`, and the approval ledger in `.workflow/approvals/` is the source of truth.
- Revisions: edit the same file, bump the version (v1.0 -> v1.1), and add one row to `## Revision history` describing what changed and why (quote the human's feedback briefly).
- Concise beats long: tables and bullets, no filler prose.

## RESULT block (every subagent ends its final message with exactly this)

```text
RESULT
status: success | partial | blocked | error
stage: prd | moscow | plan | design | implementation | review | test | mock-data | debug | demo | ui-plan | ui-build | context
item_id: <F01 / AD01 / none, or a comma-separated list for a batch: F01, F02>
step: <STEP generation only: S01..S16 | OUTLINE | F## | FINALIZE>   (omit otherwise)
step_content: |   (STEP generation only: the section / feature exactly as written, for review in chat)
  <content>
artifacts:
  - <path written or updated>
summary:
  - <3-6 bullets: what was produced and key decisions>
review_points:
  - <3-5 specific things the human should check>
open_questions:
  - <questions only the human can answer, or "none">
errors:
  - code: <STABLE_CODE> | message: <what failed> | suggested_action: <next step>   (or "none")
next_command_after_approval: <exact slash command>
```

`blocked` = a precondition is missing (say which). `partial` = some sections or batch items incomplete (list them). `error` = something failed (fill `errors`).

`next_command_after_approval` is a **suggestion** for the human, never a requirement. Subagents are independent: none of them starts, requires, or waits for another one, and none of them refuses to work because an optional earlier artifact (implementation note, test report, review) is missing. The only hard preconditions are the human approvals that the hooks enforce.

## Review request

The main conversation turns your RESULT block into the review request defined in `.claude/rules/00-workflow-gates.md`. Make `summary`, `review_points`, and `open_questions` good enough to paste directly.

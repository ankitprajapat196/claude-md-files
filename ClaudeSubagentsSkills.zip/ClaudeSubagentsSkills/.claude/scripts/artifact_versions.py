#!/usr/bin/env python3
"""Feature-wise version control for workflow artifacts (PRD, MoSCoW, feature plans).

Snapshots live in ``subagents-docs/versions/`` - outside every folder the approval ledger
hashes - so saving a version never invalidates an approval. Standard library only.

Layout:
    subagents-docs/versions/index.json                          machine-readable history
    subagents-docs/versions/VERSIONS.md                         human-readable history
    subagents-docs/versions/prd/<label>/PRD.md                  whole-PRD snapshots
    subagents-docs/versions/prd/sections/<unit>/<label>.md      per-section / per-flow history
    subagents-docs/versions/moscow/<label>/...                  whole MoSCoW set snapshots
    subagents-docs/versions/features/F##-<slug>/moscow/<label>.md
    subagents-docs/versions/features/F##-<slug>/plan/<label>.md

Usage:
    python3 .claude/scripts/artifact_versions.py save prd --note "after REVISE"
    python3 .claude/scripts/artifact_versions.py save moscow
    python3 .claude/scripts/artifact_versions.py save plan F03
    python3 .claude/scripts/artifact_versions.py list [prd|moscow|F03] [--feature F03]
    python3 .claude/scripts/artifact_versions.py diff prd v1.0 [v1.1|current]
    python3 .claude/scripts/artifact_versions.py diff moscow F03 v1.0 [current]
    python3 .claude/scripts/artifact_versions.py restore prd v1.0
    python3 .claude/scripts/artifact_versions.py restore moscow [F03] v1.0
    python3 .claude/scripts/artifact_versions.py restore plan F03 v1.0
"""

from __future__ import annotations

import argparse
import difflib
import getpass
import hashlib
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT / "subagents-docs"
PRD_FILE = DOCS / "01-prd" / "PRD.md"
MOSCOW_DIR = DOCS / "02-moscow"
PLANS_DIR = DOCS / "03-feature-plans"
VERSIONS_DIR = DOCS / "versions"
INDEX_FILE = VERSIONS_DIR / "index.json"
REPORT_FILE = VERSIONS_DIR / "VERSIONS.md"

FEATURE_RE = re.compile(r"^F\d{2}$")
VERSION_ROW_RE = re.compile(r"^\|\s*Version\s*\|\s*(v\d+(?:\.\d+)*)\s*\|", re.MULTILINE)
VERSION_LINE_RE = re.compile(r"^\*\*Version:\*\*\s*(v\d+(?:\.\d+)*)", re.MULTILINE)
HISTORY_ROW_RE = re.compile(r"^\|\s*(v\d+(?:\.\d+)*)\s*\|", re.MULTILINE)
ROW_ID_RE = {"story": re.compile(r"^\|\s*(US-\d+)\s*\|(.*)$", re.MULTILINE),
             "requirement": re.compile(r"^\|\s*(FR-\d+)\s*\|(.*)$", re.MULTILINE)}
NOISE_UNITS = {"header", "revision-history"}


class VersionError(Exception):
    """A user-facing problem (missing artifact, unknown version)."""


# ----------------------------------------------------------------- helpers
def rel(path: Path) -> str:
    """Return a POSIX path relative to the project root."""
    try:
        return path.resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def now_iso() -> str:
    """Return the current UTC time in ISO 8601."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def author() -> str:
    """Best-effort name of the person saving the version."""
    try:
        out = subprocess.run(
            ["git", "config", "user.name"], capture_output=True, text=True, timeout=2, cwd=ROOT
        )
        if out.stdout.strip():
            return out.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    try:
        return getpass.getuser()
    except Exception:  # noqa: BLE001
        return "unknown"


def sha(text: str) -> str:
    """SHA-256 of text with normalised line endings."""
    return hashlib.sha256(text.replace("\r\n", "\n").encode()).hexdigest()


def read(path: Path) -> str:
    """Read a UTF-8 text file."""
    return path.read_text(encoding="utf-8", errors="replace")


def slugify(text: str) -> str:
    """Lowercase kebab-case slug for a heading."""
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:60] or "section"


def doc_version(text: str) -> str:
    """Version label declared by a document (header row, bold line, or last history row)."""
    for regex in (VERSION_ROW_RE, VERSION_LINE_RE):
        match = regex.search(text)
        if match:
            return match.group(1)
    rows = HISTORY_ROW_RE.findall(text)
    return rows[-1] if rows else "v1.0"


def load_index() -> dict:
    """Load the version index (empty structure if none)."""
    if INDEX_FILE.is_file():
        try:
            return json.loads(read(INDEX_FILE))
        except json.JSONDecodeError as exc:
            raise VersionError(f"{rel(INDEX_FILE)} is not valid JSON: {exc}") from exc
    return {"targets": {}}


def save_index(index: dict) -> None:
    """Write the index and regenerate VERSIONS.md."""
    VERSIONS_DIR.mkdir(parents=True, exist_ok=True)
    INDEX_FILE.write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
    REPORT_FILE.write_text(render_report(index), encoding="utf-8")


def unique_label(entries: list[dict], label: str) -> str:
    """Return ``label`` or ``label-rN`` so labels never collide."""
    taken = {e["label"] for e in entries}
    if label not in taken:
        return label
    n = 2
    while f"{label}-r{n}" in taken:
        n += 1
    return f"{label}-r{n}"


# ----------------------------------------------------------------- features
def feature_files() -> dict[str, Path]:
    """Map feature id -> MoSCoW feature file."""
    found: dict[str, Path] = {}
    for folder in ("must-have", "should-have", "could-have"):
        directory = MOSCOW_DIR / folder
        if directory.is_dir():
            for path in sorted(directory.glob("F[0-9][0-9]-*.md")):
                found[path.name[:3]] = path
    return found


def feature_slug(fid: str) -> str:
    """``F03-slot-booking`` for a feature id (from MoSCoW, else plan, else the bare id)."""
    path = feature_files().get(fid)
    if path:
        return path.stem
    plans = sorted(PLANS_DIR.glob(f"{fid}-*.plan.md")) if PLANS_DIR.is_dir() else []
    return plans[0].name[: -len(".plan.md")] if plans else fid


def story_to_features() -> dict[str, list[str]]:
    """Map US-## / FR-## ids to the feature ids that cite them in MoSCoW files."""
    mapping: dict[str, list[str]] = {}
    for fid, path in feature_files().items():
        for ref in set(re.findall(r"\b(?:US|FR)-\d+\b", read(path))):
            mapping.setdefault(ref, []).append(fid)
    return mapping


# ----------------------------------------------------------------- PRD units
def split_units(text: str) -> dict[str, str]:
    """Split a PRD into versioned units: each ``##`` section and each ``### Flow`` subsection."""
    units: dict[str, list[str]] = {"header": []}
    current = "header"
    section = "header"
    for line in text.splitlines(keepends=True):
        h2 = re.match(r"^##\s+(.+?)\s*$", line)
        flow = re.match(r"^###\s+(Flow\b.+?)\s*$", line)
        if h2:
            section = current = slugify(re.sub(r"^\d+\.\s*", "", h2.group(1)))
        elif flow:
            current = f"{section}--{slugify(flow.group(1))}"
        units.setdefault(current, []).append(line)
    return {k: "".join(v) for k, v in units.items()}


def table_rows(text: str, kind: str) -> dict[str, str]:
    """Map row id (US-## / FR-##) -> normalised row text."""
    return {m.group(1): " ".join(m.group(2).split()) for m in ROW_ID_RE[kind].finditer(text)}


def compare_rows(old: dict[str, str], new: dict[str, str]) -> list[str]:
    """Describe added / changed / removed rows, e.g. ``US-03 (changed)``."""
    out = [f"{k} (added)" for k in new if k not in old]
    out += [f"{k} (changed)" for k in new if k in old and old[k] != new[k]]
    out += [f"{k} (removed)" for k in old if k not in new]
    return sorted(out)


# ----------------------------------------------------------------- save
def save_prd(index: dict, note: str) -> str:
    """Snapshot the PRD plus every changed section / flow."""
    if not PRD_FILE.is_file():
        raise VersionError(f"Missing {rel(PRD_FILE)}; nothing to save.")
    text = read(PRD_FILE)
    entries = index["targets"].setdefault("prd", [])
    digest = sha(text)
    if entries and entries[-1]["sha256"] == digest:
        return f"prd unchanged since {entries[-1]['label']}; nothing saved."
    label = unique_label(entries, doc_version(text))
    folder = VERSIONS_DIR / "prd" / label
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "PRD.md").write_text(text, encoding="utf-8")

    previous = read(ROOT / entries[-1]["path"]) if entries else ""
    old_units, new_units = split_units(previous), split_units(text)
    changed_units = []
    for unit, body in new_units.items():
        if old_units.get(unit) != body:
            unit_dir = VERSIONS_DIR / "prd" / "sections" / unit
            unit_dir.mkdir(parents=True, exist_ok=True)
            (unit_dir / f"{label}.md").write_text(body, encoding="utf-8")
            if unit not in NOISE_UNITS:
                changed_units.append(unit)
    changed_units += [f"{u} (removed)" for u in old_units if u not in new_units]
    rows = compare_rows(table_rows(previous, "story"), table_rows(text, "story"))
    rows += compare_rows(table_rows(previous, "requirement"), table_rows(text, "requirement"))
    mapping = story_to_features()
    features = sorted({f for r in rows for f in mapping.get(r.split()[0], [])})
    entries.append({
        "label": label, "sha256": digest, "saved_at": now_iso(), "author": author(),
        "note": note, "path": rel(folder / "PRD.md"), "changed_units": changed_units,
        "changed_rows": rows, "features": features,
    })
    return f"Saved prd {label}: {len(changed_units)} section(s)/flow(s), {len(rows)} story/FR row(s) changed."


def save_feature_file(index: dict, kind: str, fid: str, path: Path, note: str, set_label: str = "") -> str | None:
    """Snapshot one feature's MoSCoW file or plan if it changed; return its label or None."""
    text = read(path)
    key = f"{kind}:{fid}"
    entries = index["targets"].setdefault(key, [])
    digest = sha(text)
    if entries and entries[-1]["sha256"] == digest:
        return None
    label = unique_label(entries, doc_version(text))
    folder = VERSIONS_DIR / "features" / feature_slug(fid) / kind
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"{label}.md"
    target.write_text(text, encoding="utf-8")
    entries.append({
        "label": label, "sha256": digest, "saved_at": now_iso(), "author": author(),
        "note": note, "path": rel(target), "source": rel(path), "set_label": set_label,
    })
    return label


def save_moscow(index: dict, note: str) -> str:
    """Snapshot the whole MoSCoW set and, feature-wise, every changed feature file."""
    files = sorted(p for p in MOSCOW_DIR.rglob("*") if p.is_file()) if MOSCOW_DIR.is_dir() else []
    if not files:
        raise VersionError(f"Nothing under {rel(MOSCOW_DIR)}; nothing to save.")
    digest = hashlib.sha256()
    for path in files:
        digest.update(rel(path).encode() + b"\0" + path.read_bytes().replace(b"\r\n", b"\n"))
    entries = index["targets"].setdefault("moscow", [])
    if entries and entries[-1]["sha256"] == digest.hexdigest():
        return f"moscow unchanged since {entries[-1]['label']}; nothing saved."
    index_file = MOSCOW_DIR / "00-MOSCOW-INDEX.md"
    label = unique_label(entries, doc_version(read(index_file)) if index_file.is_file() else "v1.0")
    folder = VERSIONS_DIR / "moscow" / label
    for path in files:
        target = folder / path.relative_to(MOSCOW_DIR)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    changed = []
    for fid, path in feature_files().items():
        flabel = save_feature_file(index, "moscow", fid, path, note, label)
        if flabel:
            changed.append(f"{fid} {flabel}")
    entries.append({
        "label": label, "sha256": digest.hexdigest(), "saved_at": now_iso(), "author": author(),
        "note": note, "path": rel(folder), "files": [rel(p) for p in files], "features": changed,
    })
    return f"Saved moscow {label}; feature files changed: {', '.join(changed) or 'none'}."


def save_plan(index: dict, fid: str, note: str) -> str:
    """Snapshot one feature plan."""
    plans = sorted(PLANS_DIR.glob(f"{fid}-*.plan.md")) if PLANS_DIR.is_dir() else []
    if not plans:
        raise VersionError(f"No plan for {fid} in {rel(PLANS_DIR)}.")
    label = save_feature_file(index, "plan", fid, plans[0], note)
    return f"Saved plan {fid} {label}." if label else f"plan {fid} unchanged; nothing saved."


# ----------------------------------------------------------------- lookup
def target_key(target: str, fid: str | None) -> str:
    """Index key for a target name and optional feature id."""
    if target == "prd":
        return "prd"
    if target == "moscow":
        return f"moscow:{fid}" if fid else "moscow"
    if target == "plan":
        if not fid:
            raise VersionError("plan needs a feature id, e.g. plan F03.")
        return f"plan:{fid}"
    raise VersionError(f"Unknown target '{target}'. Use prd, moscow, or plan.")


def find_entry(index: dict, key: str, label: str) -> dict:
    """Return the history entry for ``label`` under ``key``."""
    entries = index["targets"].get(key, [])
    for entry in entries:
        if entry["label"] == label:
            return entry
    known = ", ".join(e["label"] for e in entries) or "none"
    raise VersionError(f"No version '{label}' for {key}. Known: {known}.")


def live_path(key: str) -> Path | None:
    """Current file for a single-file target."""
    if key == "prd":
        return PRD_FILE
    kind, _, fid = key.partition(":")
    if kind == "moscow":
        return feature_files().get(fid)
    plans = sorted(PLANS_DIR.glob(f"{fid}-*.plan.md")) if PLANS_DIR.is_dir() else []
    return plans[0] if plans else None


# ----------------------------------------------------------------- commands
def cmd_list(index: dict, target: str | None, feature: str | None) -> str:
    """Text history, optionally filtered to one target or one feature."""
    lines = []
    targets = index["targets"]
    keys = sorted(targets)
    if target and FEATURE_RE.match(target.upper()):
        feature, target = target.upper(), None
    if target:
        keys = [k for k in keys if k == target or k.startswith(f"{target}:")]
    if feature:
        keys = [k for k in keys if k == "prd" or k.endswith(f":{feature}")]
    for key in keys:
        rows = targets[key]
        if key == "prd" and feature:
            rows = [e for e in rows if feature in e.get("features", [])] or []
        if not rows:
            continue
        lines.append(f"## {key}")
        for e in rows:
            extra = ""
            if key == "prd":
                extra = f" | sections: {', '.join(e['changed_units']) or '-'} | rows: {', '.join(e['changed_rows']) or '-'} | features: {', '.join(e['features']) or '-'}"
            elif key == "moscow":
                extra = f" | features: {', '.join(e['features']) or '-'}"
            lines.append(f"- {e['label']}  {e['saved_at']}  {e['author']}  {e['note'] or ''}  -> {e['path']}{extra}")
    return "\n".join(lines) or "No versions saved yet."


def cmd_diff(index: dict, key: str, a: str, b: str) -> str:
    """Unified diff between two versions (or a version and ``current``)."""
    def text_of(label: str) -> tuple[str, str]:
        if label == "current":
            path = live_path(key)
            if not path or not path.is_file():
                raise VersionError(f"No current file for {key}.")
            return read(path), f"current ({rel(path)})"
        entry = find_entry(index, key, label)
        path = ROOT / entry["path"]
        if path.is_dir():
            path = path / "00-MOSCOW-INDEX.md"
        return read(path), f"{key} {label}"
    old, old_name = text_of(a)
    new, new_name = text_of(b)
    diff = difflib.unified_diff(old.splitlines(), new.splitlines(), old_name, new_name, lineterm="")
    return "\n".join(diff) or "No differences."


def cmd_restore(index: dict, key: str, label: str) -> str:
    """Restore a version over the live artifact, after saving the current state first."""
    entry = find_entry(index, key, label)
    note = f"auto-saved before restoring {label}"
    if key == "prd":
        save_prd(index, note)
        shutil.copy2(ROOT / entry["path"], PRD_FILE)
        restored = [rel(PRD_FILE)]
    elif key == "moscow":
        save_moscow(index, note)
        snapshot = ROOT / entry["path"]
        for path in [p for p in MOSCOW_DIR.rglob("*") if p.is_file()]:
            if not (snapshot / path.relative_to(MOSCOW_DIR)).is_file():
                path.unlink()
        restored = []
        for src in [p for p in snapshot.rglob("*") if p.is_file()]:
            dst = MOSCOW_DIR / src.relative_to(snapshot)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            restored.append(rel(dst))
    else:
        kind, _, fid = key.partition(":")
        current = live_path(key)
        if current:
            save_feature_file(index, kind, fid, current, note)
        dst = ROOT / entry["source"]
        if current and current.resolve() != dst.resolve():
            current.unlink()
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / entry["path"], dst)
        restored = [rel(dst)]
    return (
        f"Restored {key} {label} -> {', '.join(restored[:5])}{' ...' if len(restored) > 5 else ''}. "
        "The previous state was saved first. Any approval of this artifact is now stale: review and approve it again."
    )


# ----------------------------------------------------------------- report
def render_report(index: dict) -> str:
    """Markdown view of the index, grouped project-wide and feature-wise."""
    targets = index["targets"]
    out = ["# Artifact versions", "", "Generated by `.claude/scripts/artifact_versions.py`. Do not edit by hand.", ""]
    if targets.get("prd"):
        out += ["## PRD", "", "| Version | Saved | By | Sections / flows changed | Story / FR rows | Features affected | Note |", "|---|---|---|---|---|---|---|"]
        for e in targets["prd"]:
            out.append(f"| [{e['label']}]({Path(e['path']).relative_to('subagents-docs/versions').as_posix()}) | {e['saved_at']} | {e['author']} | {', '.join(e['changed_units']) or '-'} | {', '.join(e['changed_rows']) or '-'} | {', '.join(e['features']) or '-'} | {e['note'] or ''} |")
        out.append("")
    if targets.get("moscow"):
        out += ["## MoSCoW set", "", "| Version | Saved | By | Feature files changed | Note |", "|---|---|---|---|---|"]
        for e in targets["moscow"]:
            out.append(f"| {e['label']} | {e['saved_at']} | {e['author']} | {', '.join(e['features']) or '-'} | {e['note'] or ''} |")
        out.append("")
    fids = sorted({k.split(":")[1] for k in targets if ":" in k})
    if fids:
        out += ["## Feature-wise history", ""]
        for fid in fids:
            out += [f"### {fid}", "", "| Artifact | Version | Saved | By | Note |", "|---|---|---|---|---|"]
            for kind in ("moscow", "plan"):
                for e in targets.get(f"{kind}:{fid}", []):
                    out.append(f"| {kind} | [{e['label']}]({Path(e['path']).relative_to('subagents-docs/versions').as_posix()}) | {e['saved_at']} | {e['author']} | {e['note'] or ''} |")
            out.append("")
    return "\n".join(out) + "\n"


# ----------------------------------------------------------------- CLI
def parse_target(tokens: list[str]) -> tuple[str, str | None, list[str]]:
    """Split ``[target] [F##] rest...`` into (target, feature id, rest)."""
    if not tokens:
        raise VersionError("Missing target (prd, moscow, plan).")
    target, rest = tokens[0].lower(), tokens[1:]
    fid = None
    if rest and FEATURE_RE.match(rest[0].upper()):
        fid, rest = rest[0].upper(), rest[1:]
    return target, fid, rest


def main(argv: list[str]) -> int:
    """Command-line entry point."""
    parser = argparse.ArgumentParser(description="Feature-wise artifact versions")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p_save = sub.add_parser("save")
    p_save.add_argument("tokens", nargs="+")
    p_save.add_argument("--note", default="")
    p_list = sub.add_parser("list")
    p_list.add_argument("target", nargs="?")
    p_list.add_argument("--feature")
    for name in ("diff", "restore"):
        sub.add_parser(name).add_argument("tokens", nargs="+")
    args = parser.parse_args(argv)
    try:
        index = load_index()
        if args.cmd == "list":
            print(cmd_list(index, (args.target or "").lower() or None, (args.feature or "").upper() or None))
            return 0
        target, fid, rest = parse_target(args.tokens)
        if args.cmd == "save":
            if target == "prd":
                message = save_prd(index, args.note)
            elif target == "moscow":
                message = save_moscow(index, args.note)
            elif target == "plan":
                ids = [fid] if fid else []
                ids += [t.upper() for t in rest if FEATURE_RE.match(t.upper())]
                if not ids:
                    raise VersionError("save plan needs one or more feature ids.")
                message = "\n".join(save_plan(index, i, args.note) for i in ids)
            else:
                raise VersionError(f"Unknown target '{target}'.")
            save_index(index)
            print(message)
            return 0
        key = target_key(target, fid)
        if args.cmd == "diff":
            if not rest:
                raise VersionError("diff needs a version, e.g. diff prd v1.0 current.")
            print(cmd_diff(index, key, rest[0], rest[1] if len(rest) > 1 else "current"))
            return 0
        if len(rest) != 1:
            raise VersionError("restore needs exactly one version label.")
        message = cmd_restore(index, key, rest[0])
        save_index(index)
        print(message)
    except VersionError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

#!/usr/bin/env python3
"""Resume-safe progress record for step-by-step PRD and MoSCoW generation.

The coordinator (main conversation) records every human decision here the moment
it is made - step approved, changes requested, earlier step reopened, mode
switched, paused - so closing the chat never loses one. Every command first syncs
the record with the documents on disk, so a section that an interrupted subagent
run already wrote is recovered as ``drafted`` instead of being generated again.
Subagents never write these files. JSON only: the approval ledger hashes
``PRD.md`` and ``subagents-docs/02-moscow/**/*.md``, never these records. Standard library only.

Files:
    subagents-docs/01-prd/.prd-progress.json
    subagents-docs/02-moscow/.moscow-progress.json

Step statuses: pending -> drafted -> accepted, or changes-requested (feedback
waiting for a rerun; also used to reopen an accepted step).

Usage:
    python3 .claude/scripts/step_progress.py status prd|moscow [--json]
    python3 .claude/scripts/step_progress.py start prd|moscow --mode approval|auto [--focus TEXT]
    python3 .claude/scripts/step_progress.py drafted prd S05 [S06-S16 ...]
    python3 .claude/scripts/step_progress.py accept prd S05 [F01-F03 ...] | all-drafted
    python3 .claude/scripts/step_progress.py feedback prd S03 --text - <<'FEEDBACK'
    verbatim feedback (stdin through a quoted heredoc: nothing is shell-expanded)
    FEEDBACK
    python3 .claude/scripts/step_progress.py mode prd auto|approval
    python3 .claude/scripts/step_progress.py pause prd
    python3 .claude/scripts/step_progress.py history prd [--limit 30]
"""

from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT / "subagents-docs"
PRD_FILE = DOCS / "01-prd" / "PRD.md"
MOSCOW_DIR = DOCS / "02-moscow"
MOSCOW_INDEX = MOSCOW_DIR / "00-MOSCOW-INDEX.md"
WONT_FILE = MOSCOW_DIR / "wont-have.md"
RECORDS = {
    "prd": DOCS / "01-prd" / ".prd-progress.json",
    "moscow": MOSCOW_DIR / ".moscow-progress.json",
}
RESUME_COMMAND = {"prd": "/start-workflow", "moscow": "/prioritize-moscow"}
PRD_STEPS = [
    ("S01", "1. Executive summary"),
    ("S02", "2. Problem statement and context"),
    ("S03", "3. Goals and success metrics"),
    ("S04", "4. Personas"),
    ("S05", "5. Scope"),
    ("S06", "6. User stories"),
    ("S07", "7. Main feature flows"),
    ("S08", "8. Functional requirements"),
    ("S09", "9. AI / agentic capabilities"),
    ("S10", "10. Conceptual data model"),
    ("S11", "11. Non-functional requirements"),
    ("S12", "12. Integrations and external dependencies"),
    ("S13", "13. Risks and mitigations"),
    ("S14", "14. Open questions"),
    ("S15", "15. Glossary"),
    ("S16", "16. Traceability matrix + final self-check"),
]
STATUSES = ("pending", "drafted", "changes-requested", "accepted")
MARK = {"accepted": "[x]", "drafted": "[d]", "changes-requested": "[c]", "pending": "[ ]"}
PENDING_MARK = "_Pending ("
FEATURE_ROW_RE = re.compile(r"^\|\s*(F\d{2})\s*\|([^|]*)\|([^|]*)\|", re.MULTILINE)
RANGE_RE = re.compile(r"^([A-Z]+)(\d+)-([A-Z]+)?(\d+)$")


class ProgressError(Exception):
    """A user-facing problem (unknown step, invalid transition)."""


# ----------------------------------------------------------------- helpers
def now_iso() -> str:
    """Return the current UTC time in ISO 8601."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def actor() -> str:
    """Best-effort name of the human making the decision."""
    try:
        out = subprocess.run(
            ["git", "config", "user.name"], capture_output=True, text=True, timeout=2, cwd=ROOT
        )
        if out.stdout.strip():
            return out.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    try:
        return getpass.getuser()
    except Exception:  # noqa: BLE001
        return "unknown"


def sha(text: str) -> str:
    """Return the sha256 hex digest of ``text``."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def read(path: Path) -> str | None:
    """Read a UTF-8 file, or return None when it does not exist."""
    return path.read_text(encoding="utf-8", errors="replace") if path.is_file() else None


def section_body(text: str, heading_re: str) -> str | None:
    """Return the body under the first ``## `` heading matching ``heading_re``."""
    headings = list(re.finditer(r"^## .*$", text, re.MULTILINE))
    for i, match in enumerate(headings):
        if re.match(heading_re, match.group(0)):
            end = headings[i + 1].start() if i + 1 < len(headings) else len(text)
            return text[match.end():end].strip()
    return None


def written(body: str | None) -> bool:
    """True when a section has real content (not empty, not a pending placeholder)."""
    return bool(body) and PENDING_MARK not in body


# ----------------------------------------------------------------- documents
def prd_content() -> dict[str, str | None]:
    """Map each PRD step to its written section text (None when not written)."""
    text = read(PRD_FILE)
    out: dict[str, str | None] = {}
    for step_id, _ in PRD_STEPS:
        body = section_body(text, rf"## +{int(step_id[1:])}\.\s") if text else None
        out[step_id] = body if written(body) else None
    return out


def moscow_features(index_text: str) -> list[tuple[str, str, str]]:
    """Return (id, name, category) rows of the index's feature table, skipping merged ones."""
    table = section_body(index_text, r"## +Feature table") or ""
    rows = []
    for match in FEATURE_ROW_RE.finditer(table):
        line = table[match.start():table.find("\n", match.start())]
        if "merged into" in line.lower():
            continue
        rows.append((match.group(1), match.group(2).strip(), match.group(3).strip()))
    return rows


def moscow_content() -> tuple[list[tuple[str, str]], dict[str, str | None]]:
    """Return the ordered MoSCoW steps and each step's written text (None when not written)."""
    index = read(MOSCOW_INDEX)
    features = moscow_features(index) if index else []
    steps = [("OUTLINE", "Feature outline (index table)")]
    content: dict[str, str | None] = {"OUTLINE": index if features else None}
    for fid, name, category in features:
        steps.append((fid, f"{name or fid} ({category or '?'})"))
        files = sorted(MOSCOW_DIR.glob(f"*/{fid}-*.md"))
        content[fid] = read(files[0]) if files else None
    steps.append(("FINALIZE", "Build order, parallelisation, capacity check, Won't have"))
    finalized = bool(index) and PENDING_MARK + "FINALIZE" not in index and WONT_FILE.is_file()
    content["FINALIZE"] = index if finalized else None
    return steps, content


def document_state(artifact: str) -> tuple[list[tuple[str, str]], dict[str, str | None]]:
    """Return (ordered steps, written content per step) for ``artifact``."""
    if artifact == "prd":
        return PRD_STEPS, prd_content()
    return moscow_content()


# ----------------------------------------------------------------- record
def new_record(artifact: str) -> dict:
    """Return an empty progress record."""
    stamp = now_iso()
    return {"artifact": artifact, "schema": 2, "mode": None, "focus_notes": "",
            "created_at": stamp, "updated_at": stamp, "paused_at": None,
            "steps": [], "history": []}


def load(artifact: str) -> dict | None:
    """Load the record, upgrading a schema-1 file written by an older subagent."""
    text = read(RECORDS[artifact])
    if text is None:
        return None
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ProgressError(f"{RECORDS[artifact].name} is not valid JSON ({exc}).") from exc
    if data.get("schema") != 2:
        old = data
        data = new_record(artifact)
        data["mode"] = {"STEP": "approval", "AUTO": "auto"}.get(str(old.get("generation")), None)
        data["steps"] = [
            {"id": s.get("id"), "title": s.get("section") or s.get("title") or "",
             "status": s.get("status") if s.get("status") in STATUSES else "pending", "rounds": 0}
            for s in old.get("steps", []) if s.get("id")
        ]
        log(data, "upgraded", None, "converted from the subagent-written progress file")
    return data


def save(artifact: str, record: dict) -> None:
    """Write the record atomically."""
    record["updated_at"] = now_iso()
    path = RECORDS[artifact]
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def log(record: dict, event: str, step: str | None, detail: str = "") -> None:
    """Append one event to the record's history."""
    record["history"].append({"at": now_iso(), "by": actor(), "event": event,
                              "step": step, "detail": detail})


def sync(artifact: str, record: dict, recover: bool = True) -> dict[str, str | None]:
    """Align the step list with the documents; recover drafts from interrupted runs.

    Args:
        artifact: ``prd`` or ``moscow``.
        record: The progress record, updated in place.
        recover: Mark pending steps found on disk as ``drafted`` (off for the
            ``drafted`` command, which records them itself).

    Returns:
        The written content per step id (None when not written).
    """
    order, content = document_state(artifact)
    by_id = {s["id"]: s for s in record["steps"]}
    steps = []
    for step_id, title in order:
        step = by_id.pop(step_id, None)
        if step is None:
            step = {"id": step_id, "title": title, "status": "pending", "rounds": 0}
            if record["history"]:
                log(record, "step added", step_id, "new in the document (outline or split)")
        step["title"] = title
        on_disk = content.get(step_id) is not None
        if step["status"] == "pending" and on_disk and recover:
            step["status"] = "drafted"
            step["rounds"] = step.get("rounds", 0) + 1
            log(record, "recovered", step_id, "found written on disk (an interrupted run wrote it)")
        elif step["status"] in {"drafted", "accepted"} and not on_disk:
            log(record, "missing", step_id, f"was {step['status']}, but its content is gone")
            step["status"] = "pending"
        steps.append(step)
    for gone in by_id.values():
        log(record, "step removed", gone["id"], f"no longer in the document (was {gone['status']})")
    record["steps"] = steps
    return content


def expand(tokens: list[str], record: dict) -> list[str]:
    """Expand ``S01-S04`` / ``F01,F03`` / ``all-drafted`` into known step ids, in order."""
    ids = [s["id"] for s in record["steps"]]
    wanted: list[str] = []
    for token in ",".join(tokens).upper().replace(" ", "").split(","):
        if not token:
            continue
        if token == "ALL-DRAFTED":
            wanted += [s["id"] for s in record["steps"] if s["status"] == "drafted"]
            continue
        match = RANGE_RE.match(token)
        if match:
            prefix, lo, prefix2, hi = match.groups()
            if prefix2 and prefix2 != prefix:
                raise ProgressError(f"Range '{token}' mixes step kinds.")
            width = len(lo)
            start, end = f"{prefix}{lo}", f"{prefix}{int(hi):0{width}d}"
            if start not in ids or end not in ids:
                raise ProgressError(f"Range '{token}' names unknown steps. Known: {', '.join(ids)}")
            wanted += ids[ids.index(start): ids.index(end) + 1]
        elif token in ids:
            wanted.append(token)
        else:
            raise ProgressError(f"Unknown step '{token}'. Known: {', '.join(ids) or 'none yet'}")
    return list(dict.fromkeys(wanted))


def compress(ids: list[str]) -> str:
    """Turn ``[S01, S02, S03, S05]`` into ``S01-S03, S05``."""
    parts: list[str] = []
    run: list[str] = []

    def flush() -> None:
        if run:
            parts.append(run[0] if len(run) == 1 else f"{run[0]}-{run[-1]}")
            run.clear()

    for step_id in ids:
        match = re.fullmatch(r"([A-Z]+)(\d+)", step_id)
        prev = re.fullmatch(r"([A-Z]+)(\d+)", run[-1]) if run else None
        if match and prev and match.group(1) == prev.group(1) and int(match.group(2)) == int(prev.group(2)) + 1:
            run.append(step_id)
            continue
        flush()
        if match:
            run.append(step_id)
        else:
            parts.append(step_id)
    flush()
    return ", ".join(parts) or "none"


def next_action(record: dict) -> dict:
    """What the coordinator should do next (reruns with feedback always come first)."""
    steps = record["steps"]
    for step in steps:
        if step["status"] == "changes-requested":
            return {"action": "rerun", "step": step["id"], "feedback": step.get("feedback") or ""}
    if record.get("mode") == "auto":
        pending = [s["id"] for s in steps if s["status"] == "pending"]
        return {"action": "auto", "continue_from": pending[0]} if pending else {"action": "complete"}
    for step in steps:
        if step["status"] == "drafted":
            return {"action": "review", "step": step["id"]}
        if step["status"] == "pending":
            return {"action": "generate", "step": step["id"]}
    return {"action": "complete"}


def summary(artifact: str, record: dict, content: dict[str, str | None]) -> dict:
    """Machine-readable status (what ``status --json`` prints)."""
    changed = [
        s["id"] for s in record["steps"]
        if s["status"] == "accepted" and s.get("sha256") and content.get(s["id"]) is not None
        and sha(content[s["id"]] or "") != s["sha256"]
    ]
    counts = {status: sum(1 for s in record["steps"] if s["status"] == status) for status in STATUSES}
    return {
        "artifact": artifact,
        "mode": record.get("mode"),
        "focus_notes": record.get("focus_notes", ""),
        "paused_at": record.get("paused_at"),
        "updated_at": record.get("updated_at"),
        "counts": counts,
        "total": len(record["steps"]),
        "accepted_steps": compress([s["id"] for s in record["steps"] if s["status"] == "accepted"]),
        "changed_since_accept": changed,
        "steps": [
            {"id": s["id"], "title": s["title"], "status": s["status"], "rounds": s.get("rounds", 0),
             "feedback": s.get("feedback"), "accepted_by": s.get("accepted_by"),
             "accepted_at": s.get("accepted_at")}
            for s in record["steps"]
        ],
        "next": next_action(record),
        "resume_command": RESUME_COMMAND[artifact],
    }


def render(info: dict) -> str:
    """Human-readable status."""
    name = info["artifact"].upper() if info["artifact"] == "prd" else "MoSCoW"
    mode = info["mode"] or "not chosen"
    head = f"{name} progress - {mode} mode"
    if info["paused_at"]:
        head += f" (paused {info['paused_at']})"
    c = info["counts"]
    counts = (f"Accepted {c['accepted']}/{info['total']} | drafted {c['drafted']} | "
              f"changes requested {c['changes-requested']} | pending {c['pending']}")
    lines = [head, counts]
    for step in info["steps"]:
        line = f"  {MARK[step['status']]} {step['id']:<8} {step['title']}"
        if step["status"] == "accepted" and step["accepted_by"]:
            line += f"  (accepted by {step['accepted_by']}, {step['accepted_at']})"
        if step["status"] == "changes-requested":
            line += f'  -> "{(step["feedback"] or "")[:70]}"'
        lines.append(line)
    for step_id in info["changed_since_accept"]:
        lines.append(f"Warning: {step_id} changed after it was accepted; review it again.")
    nxt = info["next"]
    text = {
        "rerun": f"rerun {nxt.get('step')} with the recorded feedback",
        "review": f"review {nxt.get('step')} (already written, waiting for your decision)",
        "generate": f"write {nxt.get('step')}",
        "auto": f"continue the auto run from {nxt.get('continue_from')}",
        "complete": "complete - review the whole document, then /approve-stage " + info["artifact"],
    }[nxt["action"]]
    lines.append(f"Next: {text}. Resume with {info['resume_command']}.")
    return "\n".join(lines)


# ----------------------------------------------------------------- commands
def cmd(artifact: str, action: str, args: argparse.Namespace) -> str:
    """Run one command and return its output."""
    record = load(artifact)
    if record is None:
        if action not in {"status", "start"}:
            raise ProgressError(f"No progress record for {artifact} yet. Run 'start' first.")
        record = new_record(artifact)
        fresh = True
    else:
        fresh = False
    content = sync(artifact, record, recover=action != "drafted")

    if action == "status":
        if fresh and not any(v is not None for v in content.values()):
            info = summary(artifact, record, content)
            return json.dumps({**info, "exists": False}) if args.json else (
                f"No {artifact} progress yet. Start with {RESUME_COMMAND[artifact]}.")
        save(artifact, record)
        info = {**summary(artifact, record, content), "exists": True}
        return json.dumps(info, indent=2) if args.json else render(info)

    if action == "start":
        log(record, "resumed" if record["history"] else "started", None, f"mode {args.mode}")
        if record.get("mode") != args.mode:
            if record.get("mode"):
                log(record, "mode switched", None, f"{record['mode']} -> {args.mode}")
            record["mode"] = args.mode
        if args.focus:
            record["focus_notes"] = args.focus
            log(record, "focus notes", None, args.focus)
        record["paused_at"] = None
    elif action == "drafted":
        skipped = []
        for step_id in expand(args.steps, record):
            step = next(s for s in record["steps"] if s["id"] == step_id)
            if content.get(step_id) is None:
                skipped.append(step_id)
                continue
            if step["status"] != "drafted":
                step["rounds"] = step.get("rounds", 0) + 1
            step["status"] = "drafted"
            step.pop("feedback", None)
            log(record, "drafted", step_id, f"round {step['rounds']}")
        if skipped:
            save(artifact, record)
            return (f"Not written on disk, left as they were: {compress(skipped)}\n"
                    + render(summary(artifact, record, content)))
    elif action == "accept":
        for step_id in expand(args.steps, record):
            step = next(s for s in record["steps"] if s["id"] == step_id)
            if step["status"] == "accepted":
                continue
            if step["status"] != "drafted":
                raise ProgressError(f"{step_id} is {step['status']}; only a drafted step can be accepted.")
            # OUTLINE lives in the index, which every later MoSCoW step edits: no change tracking.
            digest = None if step_id == "OUTLINE" else sha(content.get(step_id) or "")
            step.update(status="accepted", accepted_at=now_iso(), accepted_by=actor(), sha256=digest)
            log(record, "accepted", step_id)
    elif action == "feedback":
        text = sys.stdin.read().strip() if args.text == "-" else args.text
        if not text:
            raise ProgressError("Feedback text is empty.")
        (step_id,) = expand([args.step], record)
        step = next(s for s in record["steps"] if s["id"] == step_id)
        if step["status"] == "accepted":
            log(record, "reopened", step_id, "accepted step reopened for changes")
        step.update(status="changes-requested", feedback=text)
        for key in ("accepted_at", "accepted_by", "sha256"):
            step.pop(key, None)
        log(record, "changes requested", step_id, text)
    elif action == "mode":
        if record.get("mode") != args.mode:
            log(record, "mode switched", None, f"{record.get('mode')} -> {args.mode}")
            record["mode"] = args.mode
    elif action == "pause":
        record["paused_at"] = now_iso()
        nxt = next_action(record)
        log(record, "paused", nxt.get("step") or nxt.get("continue_from"), "resume with "
            + RESUME_COMMAND[artifact])
    elif action == "history":
        rows = record["history"][-args.limit:]
        out = ["| When (UTC) | Who | Event | Step | Detail |", "|---|---|---|---|---|"]
        for row in rows:
            detail = (row.get("detail") or "").replace("|", "/").replace("\n", " ")
            out.append(f"| {row['at']} | {row['by']} | {row['event']} | {row.get('step') or ''} | "
                       f"{detail[:90]} |")
        return "\n".join(out)

    save(artifact, record)
    return render(summary(artifact, record, content))


def main(argv: list[str]) -> int:
    """Entry point."""
    parser = argparse.ArgumentParser(description="Resume-safe PRD / MoSCoW step progress")
    sub = parser.add_subparsers(dest="action", required=True)
    p = sub.add_parser("status")
    p.add_argument("artifact", choices=sorted(RECORDS))
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("start")
    p.add_argument("artifact", choices=sorted(RECORDS))
    p.add_argument("--mode", choices=["approval", "auto"], required=True)
    p.add_argument("--focus", default="")
    for name in ("drafted", "accept"):
        p = sub.add_parser(name)
        p.add_argument("artifact", choices=sorted(RECORDS))
        p.add_argument("steps", nargs="+")
    p = sub.add_parser("feedback")
    p.add_argument("artifact", choices=sorted(RECORDS))
    p.add_argument("step")
    p.add_argument("--text", required=True, help="the feedback, or '-' to read it from stdin")
    p = sub.add_parser("mode")
    p.add_argument("artifact", choices=sorted(RECORDS))
    p.add_argument("mode", choices=["approval", "auto"])
    p = sub.add_parser("pause")
    p.add_argument("artifact", choices=sorted(RECORDS))
    p = sub.add_parser("history")
    p.add_argument("artifact", choices=sorted(RECORDS))
    p.add_argument("--limit", type=int, default=30)
    args = parser.parse_args(argv)
    try:
        print(cmd(args.artifact, args.action, args))
    except ProgressError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

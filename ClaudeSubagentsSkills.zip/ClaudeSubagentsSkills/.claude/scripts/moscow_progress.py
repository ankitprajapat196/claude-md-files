#!/usr/bin/env python3
"""Read-only MoSCoW progress report: completion per priority bucket and per feature.

Builds on ``workflow_state.py json`` (the single source of truth for approvals)
and adds counts, percentages, effort-weighted progress (hours from the MoSCoW
index), test-report PASS/FAIL/MOCKED, review presence, and which features are
unblocked. It never writes anything.

Usage:
    python3 .claude/scripts/moscow_progress.py          # markdown report
    python3 .claude/scripts/moscow_progress.py --json   # machine-readable
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STATE_SCRIPT = ROOT / ".claude" / "hooks" / "workflow_state.py"
MOSCOW_INDEX = ROOT / "subagents-docs" / "02-moscow" / "00-MOSCOW-INDEX.md"
REVIEWS_DIR = ROOT / "subagents-docs" / "06-reviews"
TEST_REPORTS_DIR = ROOT / "subagents-docs" / "07-test-reports"

BUCKETS = ["Must", "Should", "Could"]
# Share of a feature counted as done once it reaches each stage.
STAGE_WEIGHT = {
    "not started": 0.0,
    "plan drafted": 0.1,
    "plan approved": 0.2,
    "built": 0.6,
    "tested": 0.8,
    "accepted": 1.0,
}
EFFORT_RE = re.compile(r"^\|\s*(F\d\d)\s*\|.*?\(\s*(\d+(?:\.\d+)?)\s*h\s*\)", re.MULTILINE)


def load_state() -> dict:
    """Return the workflow status dict from ``workflow_state.py json``.

    Returns:
        The parsed status dictionary.
    """
    out = subprocess.run(
        [sys.executable, str(STATE_SCRIPT), "json"], capture_output=True, text=True, check=True
    )
    return json.loads(out.stdout)


def load_effort() -> dict[str, float]:
    """Parse effort hours per feature id from the MoSCoW index table.

    Returns:
        Mapping of feature id to estimated hours (missing ids are omitted).
    """
    if not MOSCOW_INDEX.is_file():
        return {}
    text = MOSCOW_INDEX.read_text(encoding="utf-8", errors="replace")
    return {fid: float(hours) for fid, hours in EFFORT_RE.findall(text)}


def test_result(fid: str) -> str | None:
    """Return PASS/FAIL/MOCKED from the feature's latest test report, or None if absent.

    Args:
        fid: Feature id such as ``F01``.

    Returns:
        ``"PASS"``, ``"FAIL"``, ``"MOCKED"`` (tested on dependency mocks), ``"?"``
        when unparseable, or None.
    """
    reports = sorted(TEST_REPORTS_DIR.glob(f"{fid}-*.test-report.md"))
    if not reports:
        return None
    text = reports[-1].read_text(encoding="utf-8", errors="replace")
    match = re.search(r"overall result\W*\s*(PASS|FAIL|MOCKED)", text, re.IGNORECASE)
    return match.group(1).upper() if match else "?"


def stage_of(feature: dict) -> str:
    """Return the furthest workflow stage a feature has reached.

    Args:
        feature: One feature entry from the status dict.

    Returns:
        A key of ``STAGE_WEIGHT``.
    """
    if feature["accepted"]:
        return "accepted"
    if feature["tested"]:
        return "tested"
    if feature["implemented"]:
        return "built"
    if feature["plan"] == "approved":
        return "plan approved"
    if feature["plan"] != "missing":
        return "plan drafted"
    return "not started"


def build_report() -> dict:
    """Compute per-feature and per-bucket progress.

    Returns:
        Dict with ``features``, ``buckets``, ``overall`` and ``next``.
    """
    state = load_state()
    effort = load_effort()
    accepted = {f["id"] for f in state["features"] if f["accepted"]}
    features = []
    for f in state["features"]:
        stage = stage_of(f)
        features.append(
            {
                "id": f["id"],
                "slug": f["slug"],
                "category": f["category"],
                "stage": stage,
                "progress": STAGE_WEIGHT[stage],
                "hours": effort.get(f["id"], 0.0),
                "test": test_result(f["id"]),
                "reviewed": bool(list(REVIEWS_DIR.glob(f"{f['id']}-*.review.md"))),
                "stale_plan": f["plan"] == "changed-since-approval",
                "blocked_by": [d for d in f["depends_on"] if d not in accepted],
            }
        )

    def summarize(items: list[dict]) -> dict:
        hours = sum(i["hours"] for i in items)
        done_hours = sum(i["hours"] * i["progress"] for i in items)
        return {
            "total": len(items),
            "accepted": sum(i["stage"] == "accepted" for i in items),
            "in_progress": sum(0 < i["progress"] < 1 for i in items),
            "not_started": sum(i["progress"] == 0 for i in items),
            "hours": hours,
            "hours_done": round(done_hours, 1),
            "weighted_pct": round(100 * done_hours / hours) if hours else 0,
        }

    buckets = {b: summarize([f for f in features if f["category"] == b]) for b in BUCKETS}
    return {
        "features": features,
        "buckets": buckets,
        "overall": summarize(features),
        "next": state.get("next", {}),
    }


def bar(pct: float, width: int = 20) -> str:
    """Render a text progress bar.

    Args:
        pct: Percentage from 0 to 100.
        width: Number of cells.

    Returns:
        A string such as ``[#####...............]``.
    """
    filled = round(width * pct / 100)
    return "[" + "#" * filled + "." * (width - filled) + "]"


def render_markdown(report: dict) -> str:
    """Format the report as markdown.

    Args:
        report: Output of ``build_report``.

    Returns:
        Markdown text.
    """
    lines = ["## MoSCoW progress", ""]
    lines.append("| Bucket | Accepted | In progress | Not started | Effort done | Progress |")
    lines.append("|---|---|---|---|---|---|")
    rows = [(b, report["buckets"][b]) for b in BUCKETS] + [("**All**", report["overall"])]
    for name, s in rows:
        if not s["total"]:
            continue
        lines.append(
            f"| {name} | {s['accepted']}/{s['total']} | {s['in_progress']} | {s['not_started']} | "
            f"{s['hours_done']:g}/{s['hours']:g} h | `{bar(s['weighted_pct'])}` {s['weighted_pct']}% |"
        )
    lines += ["", "| ID | Feature | Priority | Stage | Test | Review | Blocked by |", "|---|---|---|---|---|---|---|"]
    for f in report["features"]:
        stage = f["stage"] + (" (plan changed)" if f["stale_plan"] else "")
        lines.append(
            f"| {f['id']} | {f['slug']} | {f['category']} | {stage} | {f['test'] or '-'} | "
            f"{'yes' if f['reviewed'] else '-'} | {', '.join(f['blocked_by']) or '-'} |"
        )
    ready = [
        f["id"] for f in report["features"] if f["stage"] == "not started" and not f["blocked_by"]
    ]
    lines += ["", f"Unblocked and not started: {', '.join(ready) or 'none'}"]
    nxt = report["next"]
    if nxt:
        lines.append(f"NEXT: {nxt.get('message', '')}  ->  {nxt.get('command') or '(none)'}")
    return "\n".join(lines)


def main(argv: list[str]) -> int:
    """Entry point.

    Args:
        argv: Command-line arguments (``--json`` for JSON output).

    Returns:
        Process exit code.
    """
    report = build_report()
    print(json.dumps(report, indent=2) if "--json" in argv else render_markdown(report))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

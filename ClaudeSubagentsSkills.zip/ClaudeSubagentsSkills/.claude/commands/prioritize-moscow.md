---
description: Stage 2 - split the APPROVED PRD into independently testable Must/Should/Could/Won't features (moscow-prioritizer subagent), in auto mode (one shot) or approval mode (outline, then one feature at a time, you approve each)
argument-hint: "[mode=auto|approval]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status), Bash(python3 .claude/scripts/artifact_versions.py *), Bash(python3 .claude/scripts/step_progress.py *)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. If the PRD is not `approved` in the status, tell the human to review `subagents-docs/01-prd/PRD.md` and run `/approve-stage prd` (or `/revise-artifact prd <feedback>`). Stop.
2. Parse `mode=auto|approval` from `$ARGUMENTS`.
3. **Resume check (never restart):** run `python3 .claude/scripts/step_progress.py status moscow --json` (`SP` below).
   - If it `exists`, show the text form and say "Resuming from <next>".
   - Mode: the `mode=` token if given (record a switch), else the recorded `mode`.
   - It recovers features an interrupted run already wrote, and it reads the step list from the index table.
   - If MoSCoW is already `approved` in the workflow status, or `next` is `complete` and the index says `Ready for review`, say so and point to `/revise-artifact moscow <feedback>` or `/approve-stage moscow`. Stop.
4. If there is no mode yet, ask the mode question from `05-generation-modes.md` §1.
5. Record the start: `SP start moscow --mode <approval|auto>`.
6. Run the step loop from `05-generation-modes.md` §1, driven by `SP status moscow --json` → `next`, recording every decision with `SP` at once.
   - Steps: `OUTLINE`, then each `F##` in the order `SP` lists (re-read after every step, because feedback can split or merge features), then `FINALIZE`.
   - Step delegation (`generate` / `rerun`):
     ```
     PRD: subagents-docs/01-prd/PRD.md
     Mode: CREATE
     Generation: STEP
     Step: <next.step>
     Accepted steps: <accepted_steps from SP>
     Step feedback: <next.feedback, only for rerun>
     Output: subagents-docs/02-moscow/
     ```
   - Auto delegation (`auto`): the same with `Generation: AUTO` and `Continue from: <next.continue_from>` (omit when it is OUTLINE) instead of `Step:`.
   - After each run: `SP drafted moscow <step>` (auto: `<continue_from>-FINALIZE`).
   - For a feature step, show its priority, dependencies, effort, and acceptance criteria. The human can change the priority in the feedback ("make this Should"), reopen an earlier feature, approve several drafted features at once, or pause (§1 "Approve or change at any point mid-session").
7. When `next` is `complete`, run `python3 .claude/scripts/artifact_versions.py save moscow --note "<auto|approval> generation complete"`.

## Output
The review request (`.claude/rules/00-workflow-gates.md`) for stage `moscow`, with:
- the features table (ID, name, category, depends on, effort) from the index;
- the version line;
- next command after approval: `/plan-feature F01` (or `/plan-feature must` to plan every Must feature at once).

On pause: the `SP status moscow` summary and "Resume any time with `/prioritize-moscow` (or `/review-step`); nothing is lost."

Then stop.

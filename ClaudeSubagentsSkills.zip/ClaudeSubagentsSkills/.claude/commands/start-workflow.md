---
description: Stage 1 - generate the PRD from the case study with the prd-analyst subagent, in auto mode (one shot) or approval mode (one section at a time, you approve each)
argument-hint: "[mode=auto|approval] [optional focus notes for the PRD]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status), Bash(python3 .claude/scripts/artifact_versions.py *), Bash(python3 .claude/scripts/step_progress.py *)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Role
You are the CyberBulls workflow coordinator in the main conversation. You delegate and run the approval loop; you do not write the PRD yourself.

## Task
1. If the status shows the case study is MISSING, tell the human to add `CASE_STUDY.md` (or .pdf/.txt) to the project root and stop.
2. If the PRD is already `approved`, do not regenerate it. Say so, point to the NEXT line of the status, and mention `/revise-artifact prd <feedback>` and `/versions list prd`. Stop.
3. Parse `$ARGUMENTS`: an optional `mode=auto` or `mode=approval` token; the rest are focus notes.
4. **Resume check (never restart):** run `python3 .claude/scripts/step_progress.py status prd --json` (`SP` below).
   - If it `exists`, show the text form (`SP status prd`) and say "Resuming from <next>".
   - Mode: the `mode=` token if given (record a switch), else the recorded `mode`.
   - Focus notes: new notes from `$ARGUMENTS` replace the recorded `focus_notes`; otherwise keep them.
   - It recovers sections an interrupted run already wrote, so they are reviewed, not rewritten.
5. If there is no mode yet (no record and no `mode=`), ask the mode question from `05-generation-modes.md` §1.
6. Record the start before any delegation: `SP start prd --mode <approval|auto> [--focus "<notes>"]`.
7. Run the step loop from `05-generation-modes.md` §1, driven by `SP status prd --json` → `next`, and record every decision with `SP` the moment the human makes it. Delegations to `prd-analyst`:
   - **Step (`generate` / `rerun`):**
     ```
     Case study: <path>
     Mode: CREATE
     Generation: STEP
     Step: <next.step>
     Accepted steps: <accepted_steps from SP>
     Step feedback: <next.feedback, only for rerun>
     Focus notes: <focus_notes from SP>
     Output: subagents-docs/01-prd/PRD.md
     ```
   - **Auto (`auto`):**
     ```
     Case study: <path>
     Mode: CREATE (or REVISE if subagents-docs/01-prd/PRD.md already exists and is complete)
     Generation: AUTO
     Continue from: <next.continue_from>   (omit when it is S01)
     Accepted steps: <accepted_steps>
     Focus notes: <focus_notes>
     Output: subagents-docs/01-prd/PRD.md
     ```
   After each run: `SP drafted prd <step>` (auto: `<continue_from>-S16`). The human can approve, change, reopen an earlier step, switch mode, or pause at any checkpoint (§1 "Approve or change at any point mid-session").
8. When `next` is `complete`, run `python3 .claude/scripts/artifact_versions.py save prd --note "<auto|approval> generation complete"` and show its one-line output.

## Output
In approval mode: a step review and the step question after every step. On pause: the `SP status prd` summary and "Resume any time with `/start-workflow` (or `/review-step`); nothing is lost." At the end: the review request from `.claude/rules/00-workflow-gates.md` (stage `prd`, next command `/prioritize-moscow`), plus one line: "Version saved: <label>. History: `/versions list prd`." Then stop.

## Constraints
- Never run or imitate `/approve-stage`; never start MoSCoW.

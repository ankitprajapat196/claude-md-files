---
description: Send human feedback back to the owning subagent to revise a stage artifact (prd [S##], moscow [F##], plan F##, feature F##, design AD##, agent AD##); saves a version before and after
argument-hint: "<prd|moscow|plan|feature|design|agent> [S##|F##|AD##] <feedback>"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status), Bash(python3 .claude/scripts/artifact_versions.py *), Bash(python3 .claude/scripts/step_progress.py *)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Parse `$ARGUMENTS` as:
   - the stage;
   - an optional id: `S##` (a PRD section step), `F##`, or `AD##`;
   - then the feedback text (keep it verbatim).

   For `moscow`, an `F##` means "revise only this feature". If the stage or id is missing or unknown, show the usage line and stop.

   **Mid-generation (PRD / MoSCoW not finished yet):** if the stage is `prd` or `moscow`, it is not `approved`, and `python3 .claude/scripts/step_progress.py status <stage> --json` shows `next` other than `complete`, this is a step change, not a revision. Do exactly what `/review-step <stage> <S##|F##> <feedback>` does (record with `step_progress.py feedback`, rerun the step, continue the loop). Without a step id, ask which step the feedback is for. Skip the rest of this command.
2. Versions, **before** delegating:
   - prd: `save prd --note "before revise"`;
   - moscow: `save moscow --note "before revise"`;
   - plan: `save plan F## --note "before revise"`.

   Use `python3 .claude/scripts/artifact_versions.py`.
3. **UI feedback:** if the stage is `feature` and the feedback is about pages, layout, styling, theme, background, or animation, follow `.claude/rules/05-generation-modes.md` §5. Ask the UI question, then send the feedback to `ui-designer` (`MODE: REVISE-UI-BUILD`, or `UI-AUTO` if no UI build exists), with `UI style:`, `Style notes:`, and `Feedback: <verbatim>`. Send backend parts of mixed feedback to `feature-implementer` as below.
4. Otherwise delegate to the owning subagent with the matching delegation message:

| Stage | Subagent | Delegation message |
|---|---|---|
| prd | prd-analyst | `Case study: <path>` / `Mode: REVISE` / `Generation: AUTO` (or `Generation: STEP` / `Step: S##` when a section id was given) / `Feedback: <verbatim>` |
| moscow | moscow-prioritizer | `PRD: subagents-docs/01-prd/PRD.md` / `Mode: REVISE` / `Generation: AUTO` (or `Generation: STEP` / `Step: F##`) / `Feedback: <verbatim>` |
| plan | feature-planner | `Feature ID: F##` / `Mode: REVISE` / `Feedback: <verbatim>` |
| feature | feature-implementer | `Feature ID: F##` / `Plan: <plan path>` / `Scope: full` / `Mode: REVISE` / `Feedback: <verbatim>` |
| design | agent-architect | `MODE: REVISE-DESIGN` / `Design ID: AD##` / `Feedback: <verbatim>` |
| agent | agent-architect | `MODE: REVISE-BUILD` / `Design ID: AD##` / `Feedback: <verbatim>` |

5. For `prd S##` / `moscow F##` on a finished artifact, also keep the progress record complete: before delegating, `step_progress.py feedback <stage> <id> --text -` (quoted heredoc with the verbatim feedback); after the run, `step_progress.py drafted <stage> <id>`.
6. Wait for the subagent to finish. Then save the new version (same commands as step 2, with `--note "revised: <first 60 chars of the feedback>"`).

## Output
Present the review request from `.claude/rules/00-workflow-gates.md`, with:
- the version line ("Saved <label>. Compare: `/versions diff <target> <old> current`");
- one line: "Any earlier approval of this artifact is now invalid (its content changed); approve again after review."

Then stop.

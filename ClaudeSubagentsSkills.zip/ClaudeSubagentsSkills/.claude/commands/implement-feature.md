---
description: Stage 4 - implement one feature, several features, or all plan-approved features (feature-implementer subagent), following the production API checklist; UI work goes automatically to the ui-designer in the style you choose
argument-hint: "<F## [F## ...] | all | must | should | could> [full|backend|frontend]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Parse `$ARGUMENTS`:
   - the feature tokens (ids, `all`, or a bucket) are resolved as in `/plan-feature`;
   - the last token, if it is `full`, `backend`, or `frontend`, is the scope (default `full`);
   - leave out features that are already accepted.
2. **Plan check, for every feature:** its plan must be `approved` in the status.
   - One feature that is not approved: tell the human to review it and run `/approve-stage plan <ID>`. Stop.
   - In a batch, drop the unapproved ones and list them with their approve commands. If none remain, stop.
   
   This check matters because the stage gate only reads the first `Feature ID:`.
3. If the status shows a feature still in progress in this clone, the gate accepts only a delegation whose first `Feature ID:` is that feature.
   - If it is in this batch and none of its dependencies are in the batch, put it first in build order.
   - Otherwise tell the human to accept it (`/approve-stage feature <ID>`) or park it (`/revoke-stage active`). Stop.
4. Remind the human in one line to `git pull` first if they have not. Run the dependency check from `.claude/rules/80-team-parallel-work.md` for **implementation**, counting dependencies inside the batch as met. On A (wait), stop as that rule says. Order the batch topologically (dependencies first).
5. **UI choice** (`05-generation-modes.md` §5): if the scope is not `backend` and any feature's plan says `UI involvement: yes` (or plans pages), ask the UI question once for the whole command. Remember the styles, the style notes, and the builder.
6. Delegate **once** to `feature-implementer`:
   ```
   Feature ID: <first id in build order>
   Batch: <ordered ids>            (omit for one feature)
   Plans: F01: subagents-docs/03-feature-plans/F01-<slug>.plan.md; F02: …
   Scope: <scope>
   UI: <ui-designer | implementer>
   Mode: CREATE
   Dependency mode: MOCK <F##>,<F##>   (only if the human chose B, mock)
   ```
   If the stage gate asks the human to confirm unmet dependencies, let the human decide (after choosing C, the answer is yes).
7. If the builder is `ui-designer`: for each feature that succeeded and has UI, one at a time, delegate to `ui-designer`:
   ```
   MODE: UI-AUTO   (REVISE-UI-BUILD if subagents-docs/11-ui-designs/<ID>-*.ui-build.md exists)
   Feature ID: <ID>
   Plan: subagents-docs/03-feature-plans/<ID>-<slug>.plan.md
   Design file: DESIGN.md
   UI style: <chosen styles>
   Style notes: <verbatim or none>
   ```

## Output
- **One feature:** the review request for stage `implementation` (files changed, how to try it in 2 minutes, deviations from the plan, the UI pages and styles if the ui-designer ran).
- **Batch:** a table (ID | status | files | how to try | UI), then the details per feature.
- If mocks were used, list the `Mocks to remove` table and the lifecycle: "Test on mocks now with `/test-feature <ID>` (the report says `MOCKED`). When the teammate's `<F##>` is accepted, run `/connect-dependency <F##>` (add `--from feat/<F##>-<slug>` to merge their branch first), then `/test-feature <ID>` again for a PASS that can be accepted."
- If this run created a new top-level code folder (`app/`, `src/`, `static/`, `templates/`, `tests/`, `mcp_server/`) that has no `CLAUDE.md`, add: "Suggested: `/claude-md <folder>` to propose a short context file for it."
- Suggested next (optional, in any order): `/test-feature <ID>`, `/review-feature <ID>`, `/revise-ui <ID> build <feedback>`. Acceptance: `/approve-stage feature <ID>` (needs a PASS test report).

Then stop.

---
description: Read-only code review of one feature (F##), agent build (AD##), or "diff" against the plan, layering, API and agentic checklists (code-reviewer subagent)
argument-hint: "<F##|AD##|diff>"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
Delegate to `code-reviewer` with `Feature ID: F##` / `Design ID: AD##` / `Scope: current diff`, plus the plan/design and implementation note paths when they exist (write `none` for missing ones; neither tests nor a test report are required to review). If a feature's plan is not approved, the gate refuses `Feature ID:`; use `Scope: <the feature's code paths>` instead. Wait for it.

## Output
Verdict, findings grouped by severity (Critical/High first, file:line + fix), and the next command: `/revise-artifact feature F## <the fixes>` if CHANGES REQUIRED, else `/approve-stage feature F##` once the test report says PASS. If the feature still has `DEP-MOCK` markers, show the mock-removal reminder from `.claude/rules/80-team-parallel-work.md` instead of the approve command. Stop.

---
description: Switch PRD or MoSCoW generation between auto mode (rest in one run) and approval mode (one section / feature at a time) and continue from where it is
argument-hint: "<auto|approval> [prd|moscow]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status), Bash(python3 .claude/scripts/artifact_versions.py *), Bash(python3 .claude/scripts/step_progress.py *)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Parse the target mode (`auto` or `approval`) and the artifact (`prd` or `moscow`).
   - If the artifact is missing, use the one in progress: `prd` until the PRD is approved, else `moscow`.
   - If the mode is missing, show the usage line and stop.
2. Refuse if the artifact is already `approved`. Changing it is a revision: `/revise-artifact prd|moscow <feedback>`. Stop.
3. Run `python3 .claude/scripts/step_progress.py status <artifact>` and show its counts line (accepted / drafted / changes requested / pending).
4. Record the switch first: `python3 .claude/scripts/step_progress.py mode <artifact> <auto|approval>`. If no record exists yet, use `start <artifact> --mode <mode>` instead.
5. Continue exactly as `.claude/rules/05-generation-modes.md` §1 says, driven by `status <artifact> --json` → `next`:
   - **to auto:** steps with requested changes are rerun first; then one AUTO delegation with `Continue from: <next.continue_from>` and `Accepted steps:`;
   - **to approval:** a walk-through of every drafted step (`review`), then `generate` for the rest.

   Use the same delegation fields as `/start-workflow` (PRD) or `/prioritize-moscow` (MoSCoW), and record every decision with the script.
6. When the artifact is complete, save a version as those commands do.

## Output
As in `/start-workflow` or `/prioritize-moscow`: step reviews during the loop, then the stage review request. Then stop.

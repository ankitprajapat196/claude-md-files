---
description: Write and run tests on demand for one feature (F##), agent build (AD##), or an ad-hoc scope (paths, module, endpoint, "all"), and produce a test report (test-engineer subagent). Independent - no earlier stage has to hand over first
argument-hint: "<F## | AD## | path/module/endpoint | all>"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Target = `$ARGUMENTS`. If it is empty, ask what to test. Stop.
2. **F## or AD##:** collect what exists:
   - the plan or design path;
   - the implementation note path;
   - the MoSCoW file (features only).

   None of them is required. Delegate to `test-engineer` with:
   - `Feature ID: F##` (or `Design ID: AD##`) and the paths found;
   - one line per missing input, e.g. `Implementation note: none`.

   Note that a `Feature ID:` needs its plan approved (stage gate). If the plan is not approved, delegate with `Scope: <the feature's code paths, or a description>` instead, and say that the report will be ad hoc and cannot be used to accept the feature.
3. **Anything else:** delegate with `Scope: <target>`.
4. Wait for it to finish.

## Output
Show: Overall result (PASS/FAIL/MOCKED), the basis (plan / MoSCoW file / code contract), totals, criteria coverage, and failures.
- **Suggested next** (not required):
  - PASS with a feature id: `/review-feature F##` and `/approve-stage feature F##` (or `agent AD##`);
  - FAIL: `/debug-issue` or `/revise-artifact feature F## <fixes>`;
  - MOCKED: the feature runs on mocks, and the approval hook refuses it until it is retested without them. Show `**Tests on mocks:**`, then the mock-removal reminder below.
- Then search for `DEP-MOCK` markers. If any belong to this feature, show the mock-removal reminder from `.claude/rules/80-team-parallel-work.md`; it overrides the "approve" suggestion until the mocks are gone.

Stop.

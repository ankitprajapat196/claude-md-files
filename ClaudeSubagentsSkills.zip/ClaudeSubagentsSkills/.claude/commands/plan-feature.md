---
description: Stage 3 - plan one feature, several features, or all of them (user story, logic, flow, API contract, data, layers, tests) with the feature-planner subagent; batches run in parallel dependency waves
argument-hint: "<F## [F## ...] | all | must | should | could> [--replan]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status), Bash(python3 .claude/scripts/artifact_versions.py *)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. If MoSCoW is not `approved`, tell the human to run `/approve-stage moscow` first. Stop.
2. Resolve the feature list from `$ARGUMENTS` (case-insensitive):
   - explicit ids (`F01 F03`, or `F01,F03`);
   - `all` = every Must/Should/Could feature;
   - `must` / `should` / `could` = that bucket.

   Leave out accepted features. Leave out features that already have a plan, unless they were named explicitly or `--replan` is given (then use REVISE). If nothing is left, say so and stop. If `$ARGUMENTS` is empty, show the features from the status and ask which ones. Stop.
3. For each feature, find `subagents-docs/02-moscow/*/<ID>-*.md`. Run the dependency check from `.claude/rules/80-team-parallel-work.md` for **planning**, counting dependencies inside this batch as met (`05-generation-modes.md` §3). Ask the dependency question (wait or mock) once for all unmet outside dependencies. On A (wait), stop as that rule says (in a batch, you may drop only the affected features instead, and say which).
4. **One feature:** delegate to `feature-planner`:
   ```
   Feature ID: <ID>
   Feature file: <path>
   Mode: CREATE (REVISE if subagents-docs/03-feature-plans/<ID>-*.plan.md exists)
   Dependency mode: MOCK <F##>,<F##>   (only if the human chose B, mock)
   ```
5. **Several features:** build the dependency waves (`05-generation-modes.md` §3) and show them in one line, e.g. `Wave 1: F01, F02 | Wave 2: F03`. For each wave, send all of its Agent calls **in one message** so they run in parallel. Each call:
   ```
   Feature ID: <ID>
   Feature file: <path>
   Mode: CREATE (or REVISE)
   Batch: <all ids in this command>
   Wave: <n>
   Sibling plans: <plan paths written by earlier waves, or none>
   Dependency mode: MOCK <F##>,<F##>   (only if chosen)
   ```
   Wait for the wave to finish before starting the next one.
6. Save versions: `python3 .claude/scripts/artifact_versions.py save plan <every planned id> --note "planned"`.

## Output
- **One feature:** the review request for stage `plan`, with the API contract table and the task-list size. If the plan has `## Assumed dependency contracts`, list them under **Please check**. Next command after approval: `/implement-feature <ID>`.
- **Several features:** one table (ID | plan file | endpoints | tasks | UI involvement | status | assumed contracts), then the review points that matter most per plan, then every approve line (`/approve-stage plan F01`, …). Request changes with `/revise-artifact plan F## <feedback>`. Next, after approvals: `/implement-feature <ids>` (or `all`).

Then stop.

---
description: Show where the workflow is (approvals, features, in-progress work) and the exact next command
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status), Bash(python3 .claude/scripts/step_progress.py *)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

Summarise the status above in at most 8 lines: current stage, what is waiting for the human's review, anything stale ("changed-since-approval") and how to fix it, and the NEXT command exactly as shown. If the PRD or MoSCoW is not `approved` yet, also run `python3 .claude/scripts/step_progress.py status prd` (or `moscow`) and add its counts line and `Next:` line. Say where generation stopped, and that `/start-workflow` / `/prioritize-moscow` or `/review-step` resumes from there. Then search for `DEP-MOCK` markers (Grep tool, read-only); if any exist, add the mock-removal reminder from `.claude/rules/80-team-parallel-work.md` for each mocked dependency. Do not run any other command (`step_progress.py status` only syncs the progress record).

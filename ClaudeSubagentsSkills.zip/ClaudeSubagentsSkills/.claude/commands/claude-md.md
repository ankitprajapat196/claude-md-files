---
description: Analyse the project and propose CLAUDE.md context files (root and folder-level, e.g. backend or frontend) with the reason for each location; asks before creating or updating any file, then writes only the ones you pick (claude-md-curator subagent)
argument-hint: "[all | <folder> ...] [notes for the curator]"
disable-model-invocation: true
---

## Task
1. Parse `$ARGUMENTS`:
   - leading tokens that are existing folders (or `all`, `.`) form the **scope** (default `all`);
   - the rest is **notes**, verbatim (e.g. "keep the root under 40 lines", "we deploy with Docker; add the compose commands").
2. **Propose.** Delegate to `claude-md-curator`:
   ```
   MODE: PROPOSE
   Scope: <scope>
   Notes: <notes or none>
   ```
3. **Show the proposals** from the RESULT (details are in `subagents-docs/12-context/CLAUDE-MD-PROPOSAL.md`):
   - a table `ID | File | Action | Lines | Why here`, where "Why here" is the reason with its evidence;
   - one line per file on what was left out on purpose and where that lives instead;
   - the `Not proposed` folders, one line each.

   If nothing needs creating or updating, say the CLAUDE.md files are up to date and stop.
4. **Ask before writing anything.** Use AskUserQuestion, header `CLAUDE.md`:
   - **Several proposals:** `multiSelect: true`, question "Which CLAUDE.md files should I create or update?", one option per proposal:
     - label `P1 CLAUDE.md (create)`;
     - description: the reason in one sentence.

     At most 4 options per question and 4 questions per call. With more than 16 proposals, ask in a second call.
   - **A group with one proposal** (AskUserQuestion needs two options): a single-select question "Create `<path>`? <reason>" with **Yes, create it** / **No, skip it** (use "update" for an update).
   - The human can type notes through "Other". Pass them on verbatim as `Human notes:`.
5. If nothing was picked, say "No CLAUDE.md files were written" and stop. If the notes ask for a new location or a different scope, rerun step 2 with them as `Notes:` instead of writing.
6. **Write.** Delegate to `claude-md-curator`:
   ```
   MODE: WRITE
   Proposal: subagents-docs/12-context/CLAUDE-MD-PROPOSAL.md
   Approved: <picked ids, e.g. P1, P3>
   Human notes: <verbatim or none>
   ```

## Output
- The files written, with line counts and their budgets (root ≤ 80 lines, folder ≤ 40), plus any item left `partial` and why.
- "Review the files, then commit them. They are context for every teammate's Claude sessions."
- "Rerun `/claude-md` after structural changes (a new top-level folder, a new stack, new commands). It proposes updates the same way and never writes without asking."

This is not a workflow stage: no `/approve-stage` is needed. Then stop.

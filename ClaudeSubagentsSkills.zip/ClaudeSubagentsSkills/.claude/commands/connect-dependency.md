---
description: Connect a teammate's finished feature to every feature built on mocks of it - optionally merge their branch, then the feature-implementer (Mode CONNECT) removes the DEP-MOCK code, wires the real feature, adapts to contract differences, and reruns tests
argument-hint: "<F## [F## ...] | all> [--from <branch>] [--into F##]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status), Bash(git status *), Bash(git fetch *), Bash(git diff *)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
1. Parse `$ARGUMENTS`:
   - the dependency ids (`F02`, `F02 F04`, `F02,F04`) or `all` (every dependency that has `DEP-MOCK` markers);
   - optional `--from <branch>`: the teammate's branch to merge first (e.g. `feat/F02-auth`). It must match `^[A-Za-z0-9._/-]+$`; otherwise show the usage line and stop;
   - optional `--into F##`: connect only this consuming feature.

   If no id is given, search for markers (step 2), show which dependencies are mocked and by which features, and ask which to connect. Stop.
2. **Inventory.** Use Grep (read-only) for `DEP-MOCK\((F\d{2})\)` over `src/`, `static/`, `templates/`, `tests/`, `app/`, and read the `## Mocks to remove` tables in `subagents-docs/05-implementation-notes/F*-*.impl.md`. Build: dependency → consuming features → mock files and wiring lines. Drop any requested dependency with no markers and no `active` table rows ("nothing to connect for F##"). If nothing is left, stop.
3. **Bring in the real code.**
   - **With `--from <branch>`:**
     - `git status --porcelain` must be empty; otherwise tell the human to commit or stash first. Stop.
     - Run `git fetch origin <branch>`, then `git merge --no-ff --no-edit origin/<branch>`. The human approves the merge in the permission prompt.
     - **Clean merge:** say so in one line.
     - **Conflicts:** list them (`git diff --name-only --diff-filter=U`).
       - Code conflicts under `app/`, `src/`, `templates/`, `static/`, `tests/` go to the implementer in step 6.
       - Any other conflict (`.workflow/`, `.claude/`, `subagents-docs/`, `pyproject.toml`, `uv.lock`) is the human's. List it with the fix (for `pyproject.toml`: keep both dependency lines, then `uv lock`). Say `git merge --abort` backs the whole merge out. Stop.
   - **Without `--from`:** remind the human in one line to `git pull` (or merge the teammate's branch) first if they have not.
4. **Readiness, per dependency:** the status table must show it accepted (`accepted = yes`).
   - **Not accepted:** say why (code not here yet, not accepted, or changed since approval), show the option-A teammate message from `.claude/rules/80-team-parallel-work.md`, and drop that dependency. Any merge already done stays.
   - **Nothing left:** stop.
5. **Consumers:**
   - Each consuming feature's plan must be `approved`. Drop the others and list their `/approve-stage plan F##` lines.
   - If the status shows a feature in progress that is not a consumer, the stage gate will refuse the run. Tell the human to accept it (`/approve-stage feature <ID>`) or park it (`/revoke-stage active`). Stop.
   - Order: the in-progress consumer first, then the rest in dependency order.
   - Show the plan in one line, e.g. `Connecting F02 → F03, F05 (4 mock files, 6 wiring lines)`.
6. Delegate **once** to `feature-implementer`:
   ```
   Feature ID: <first consumer>
   Batch: <ordered consumers>            (omit for one consumer)
   Plans: F03: subagents-docs/03-feature-plans/F03-<slug>.plan.md; F05: …
   Scope: full
   Mode: CONNECT
   Connect: F02 (plan: subagents-docs/03-feature-plans/F02-<slug>.plan.md; note: subagents-docs/05-implementation-notes/F02-<slug>.impl.md); F04 (…)
   Merge conflicts: <paths, or none>
   ```
   If the stage gate asks to confirm another unmet dependency (a consumer still mocks something else), let the human decide.

   **Agent builds** (a consumer note is `subagents-docs/05-implementation-notes/AD##-*.impl.md`): after the implementer run, one at a time, delegate to `agent-architect`:
   ```
   MODE: REVISE-BUILD
   Design ID: AD##
   Feedback: Remove DEP-MOCK(F02). Connect: F02 (plan: …; note: …). Merge conflicts: <paths under src/agents/, or none>
   ```
7. After the run(s), Grep again for `DEP-MOCK(<each connected F##>)`. Anything left is a gap; show it.

## Output
- One review request (stage `implementation`) per consumer, from `.claude/rules/00-workflow-gates.md`, with:
  - the contract-difference table from the note's `## Dependency connections` (assumed vs real, action taken);
  - mock files deleted, wiring lines replaced, test totals;
  - any `blocked` consumer with its reason (`DEP_CONTRACT_GAP`, `DEP_DEFECT`) and the ready-to-send message for the teammate.
- If the merge had conflicts: show `git status --short`. Tell the human to review the resolved files, then run `git add <files>` and `git commit --no-edit` to finish the merge.
- Next, per consumer:
  - "The earlier test report was on mocks (`MOCKED`). Run `/test-feature <F##>` for a fresh report.";
  - then `/approve-stage feature <F##>` once it says PASS;
  - request changes with `/revise-artifact feature <F##> <feedback>`;
  - after acceptance, commit with `.workflow/approvals/` and push.

Then stop.

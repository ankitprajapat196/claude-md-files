---
description: Mid-session approval and changes for PRD / MoSCoW generation - approve the current or several drafted steps, change a step, reopen an accepted one, or see the progress record and history - then continue the step loop exactly where it stopped (also after the chat was closed)
argument-hint: "[prd|moscow] [status | history | <step(s)> approve | <step> <your changes>]"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/hooks/workflow_state.py status), Bash(python3 .claude/scripts/step_progress.py *), Bash(python3 .claude/scripts/artifact_versions.py *)
---

## Current workflow status
!`python3 .claude/hooks/workflow_state.py status`

## Task
`SP` = `python3 .claude/scripts/step_progress.py`.

1. Parse `$ARGUMENTS`:
   - the artifact `prd` or `moscow`. If it is missing, use the one being generated: `prd` until the PRD is approved, else `moscow`;
   - then one action:
     - nothing or `status`;
     - `history`;
     - `<steps> approve` (e.g. `S05 approve`, `S05-S07 approve`, `F02,F04 approve`, `all approve` = every drafted step);
     - `<step> <changes>`: everything after the step id is the human's feedback, verbatim.
2. If the artifact is already `approved` in the workflow status, step decisions no longer apply. Show `SP status <artifact>` if asked, and point to `/revise-artifact prd|moscow [S##|F##] <feedback>`. Stop.
3. **status:** run `SP status <artifact>` and show it. Add the commands below. Stop.
   **history:** run `SP history <artifact>` and show the table (the complete record: who decided what, when, and the verbatim feedback). Stop.
4. **approve:** `SP accept <artifact> <steps>` (`all` → `all-drafted`). If it refuses (a step is pending or has changes waiting), show why. To review a step before approving it, read it from the document and show it first.
5. **changes:** record first, then act. Pipe the feedback through a quoted heredoc so nothing in it is shell-expanded:
   ```
   python3 .claude/scripts/step_progress.py feedback <artifact> <step> --text - <<'FEEDBACK'
   <the human's words, verbatim>
   FEEDBACK
   ```
   If the step was accepted, the output shows it was reopened. Say that later accepted steps stay accepted unless they conflict.
6. **Continue the loop.** If `SP status <artifact> --json` shows no `mode` yet, ask the mode question first and record it with `SP start`. Then run the step loop from `.claude/rules/05-generation-modes.md` §1, driven by `next`:
   - a recorded change → `rerun` → the step is rewritten, shown, and asked about;
   - then the loop goes on from where it stopped.

   Use the delegation fields of `/start-workflow` (PRD) or `/prioritize-moscow` (MoSCoW), and record every further decision with `SP`.
   - If the human only asked for `approve` and wants to stop there, they can choose **Pause here** at the next question.

## Output
- After status / history: the table, then:
  - `/review-step <artifact> <step> approve`;
  - `/review-step <artifact> <step> <changes>`;
  - resume: `/start-workflow` or `/prioritize-moscow`.
- During the loop: as in `/start-workflow` / `/prioritize-moscow`; at the end, their review request.

Step approvals are progress records, not ledger approvals; the stage still needs `/approve-stage prd|moscow`. Then stop.

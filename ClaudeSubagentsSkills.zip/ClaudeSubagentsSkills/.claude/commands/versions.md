---
description: Feature-wise version history of the PRD, MoSCoW set, and feature plans - list, diff, save, or restore a version
argument-hint: "list [prd|moscow|F##] | diff <prd|moscow [F##]|plan F##> <vA> [vB|current] | save <prd|moscow|plan F##> [note] | restore <prd|moscow [F##]|plan F##> <version>"
disable-model-invocation: true
allowed-tools: Bash(python3 .claude/scripts/artifact_versions.py *)
---

## Task
Run `python3 .claude/scripts/artifact_versions.py` with the matching subcommand from `$ARGUMENTS`:
- `list [prd|moscow|F##]`: the history. With `F##`, show every version of that feature's MoSCoW file and plan, plus the PRD versions that changed its user stories or requirements.
- `diff <target> <vA> [vB|current]`: show the diff in a fenced `diff` block. If it is longer than ~150 lines, summarise per section and show the most important hunks.
- `save <target> [note]`: pass the note with `--note "<note>"`.
- `restore <target> <version>`: only when the human typed `restore` in this command.
  - The script saves the current state first.
  - Afterwards, say that the artifact's approval (and everything approved on top of it) is now stale, and give the commands to re-approve in order: `/approve-stage prd`, then `moscow`, then `plan F##`.

If the arguments do not match, show the usage line. Quote file names with spaces.

## Output
The script output (or diff summary), and a link to `subagents-docs/versions/VERSIONS.md` for the full history table. Do nothing else.

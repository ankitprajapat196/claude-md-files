# Workflow and Subagent Guide (Claude Code)

How to start the workflow, how to use the subagents, and which files the workflow needs.

The workflow runs **stage by stage, with your approval between every stage**:

**PRD → MoSCoW → per feature: plan → implement → test + review → accept**, plus a separate track for AI agents (design → build → test + review → accept).

**What's new**

| Feature | Where |
|---|---|
| **All generated documents in `subagents-docs/`** (PRD, MoSCoW, plans, reports, versions), keeping `docs/` free for your own project docs | §1 |
| **`/claude-md`**: analyses the project and proposes root and folder `CLAUDE.md` files with the reason for each location; asks before writing; strict rules keep them short | §5f |
| **Command examples**: what to pass to every command, good vs. weak feedback, and full walkthroughs | §4a, §4b |
| PRD and MoSCoW in **auto mode** (one shot) or **approval mode** (one section / feature at a time), switchable mid-chat | §5b |
| **Approve or change any step mid-session** (`/review-step`), including reopening an accepted section | §5b |
| **Resume-safe generation**: closing the chat never loses progress; every decision and its history are recorded | §5b |
| **Feature-wise version history** for the PRD, the MoSCoW set, and the plans (`/versions`) | §5c |
| Plan or implement **one, several, or all** features in one command | §5d |
| **Independent subagents**: tests and reviews run on demand, nothing forces another agent to run | §5e |
| UI work goes **automatically to `ui-designer`**, in the style you pick (modern, theme, background, motion) | §5a |
| **Team dependencies**: wait for a teammate, or mock their feature and connect it later with `/connect-dependency` | §5, §6 |
| **A model per subagent** (`opus`, `sonnet`, `haiku`), matched to its work | §5 |

---

## 1. Files the workflow needs

### Required to run the workflow

| File / folder | Why it is needed |
|---|---|
| `CASE_STUDY.md` (or `case-study.pdf` / `.txt`) in the project root | Input for `/start-workflow`. Not in the kit; each team adds its own |
| `CLAUDE.md` (root) and `<folder>/CLAUDE.md` (optional) | Short project context Claude Code loads (root: every session; folder: when working there). Created and updated with `/claude-md`, only the files you pick (§5f). **Commit them** |
| `.claude/settings.json` | Permissions and hook wiring |
| `.claude/agents/*.md` | The 12 subagent definitions (10 workflow agents, `ui-designer`, `claude-md-curator`) |
| `.claude/commands/*.md` | The slash commands (`/start-workflow`, `/plan-feature`, …) |
| `.claude/hooks/*.py` | Gates: approvals, stage order, write scopes, bash guard, quality check |
| `.claude/rules/*.md` | Always-on rules (workflow gates, generation modes / versions / batches / UI in `05-generation-modes.md`, security, team work) and path-scoped rules |
| `.claude/scripts/artifact_versions.py` | Version history tool behind `/versions` (standard library only) |
| `.claude/scripts/step_progress.py` | Resume-safe progress record for PRD / MoSCoW generation (behind `/review-step`, `/start-workflow`, `/prioritize-moscow`) |
| `.claude/scripts/moscow_progress.py` | Read-only completion report behind `/show-progress` |
| `subagents-docs/01-prd/.prd-progress.json`, `subagents-docs/02-moscow/.moscow-progress.json` | Step decisions, mode, focus notes, and history. **Commit them**, so whoever continues the PRD / MoSCoW resumes from the same point. Written only by `step_progress.py` |
| `subagents-docs/versions/` | Version snapshots + `VERSIONS.md`. **Commit it** so teammates share the history. No approval hashes this folder |
| `.claude/skills/*/` | Standards and templates the subagents preload (document templates: `.claude/skills/workflow-artifacts/templates/`; CLAUDE.md rules: `.claude/skills/claude-md-standards/`) |
| `subagents-docs/01-prd … subagents-docs/12-context` | Every document the subagents generate, one numbered folder per stage, created on first use. **Commit it.** Your own project documentation can live in `docs/`; the workflow never writes there |
| `subagents-docs/11-ui-designs/` | UI plans and UI build notes from `ui-designer` (created on first use) |
| `DESIGN.md` in the project root | Only for the UI track: your design brief for `ui-designer` |
| `.workflow/approvals/` | Approval ledger. **Commit it** so teammates share approvals. `.workflow/local/` is per-clone and ignored |

### Tooling needed

- A recent Claude Code (`claude --version`). The approval hook relies on the `UserPromptExpansion` event and the `onFailure` hook option.
- `uv` (installs and pins Python 3.12), `git`, Node 18+ (optional, only for frontend tests).
- `pyproject.toml`, `uv.lock`, `.python-version` (hooks and the quality gate run through `uv`).

### Do not edit by hand or let Claude edit

`.workflow/`, `.claude/hooks/`, `.claude/settings.json`, `.env*`, and the case study are protected. Claude is blocked from changing them.

---

## 2. One-time setup

1. Install the tools listed above.
2. Open the project root and initialise git. `.workflow/local/` is git-ignored; if it was staged before the ignore rule existed, untrack it first:
   ```bash
   git init
   git rm -r --cached --ignore-unmatch .workflow/local
   git add -A && git commit -m "chore(core): hackathon kit"
   uv sync
   ```
3. Start Claude Code in the project root with `claude`. Accept the **workspace trust** prompt. Without it, project hooks do not run.
4. Verify:
   - `/hooks` lists SessionStart, UserPromptExpansion, PreToolUse, PostToolUse, SubagentStart/Stop.
   - `/show-status` prints the workflow status (with a new project it says "Case study: MISSING").
   - Typing `/` shows the commands in section 4.
5. **Windows only:** in `.claude/settings.json` and `.claude/commands/*.md`, replace `python3` with `python` (or `py`).

---

## 3. How to start the workflow

Run these in order. Every stage ends with a **review request**; Claude stops and waits for you.

| # | You type | What happens | Output |
|---|---|---|---|
| 0 | Save the case study as `CASE_STUDY.md` in the root | — | — |
| 1 | `/start-workflow [mode=auto\|approval] [focus notes]` | Claude asks **auto or approval mode** (if not given). `prd-analyst` writes the PRD in one run, or one section at a time with your OK after each. Approve or change any section mid-session with `/review-step`; rerun the command after a break to resume | `subagents-docs/01-prd/PRD.md` + version in `subagents-docs/versions/prd/` |
| 2 | Review, then `/approve-stage prd` (or `/revise-artifact prd [S##] <feedback>`) | Approval and SHA-256 recorded | `.workflow/approvals/prd.json` |
| 3 | `/prioritize-moscow [mode=auto\|approval]` | `moscow-prioritizer` creates the feature files, all at once or one feature at a time | `subagents-docs/02-moscow/` + version |
| 4 | Review, then `/approve-stage moscow` | — | — |
| 5 | `/plan-feature F01` (or `F01 F02`, `must`, `all`) | `feature-planner` writes the plan(s); batches run in parallel | `subagents-docs/03-feature-plans/F01-<slug>.plan.md` |
| 6 | Review, then `/approve-stage plan F01` (one line per plan) | Unlocks implementation | — |
| 7 | `/implement-feature F01 [full\|backend\|frontend]` (or several ids / `all`) | Claude asks the **UI style** if there is UI; `feature-implementer` builds, then `ui-designer` builds the pages | code + `subagents-docs/05-implementation-notes/F01-<slug>.impl.md` (+ `subagents-docs/11-ui-designs/…`) |
| 8 | `/test-feature F01` (any time, optional order) | `test-engineer` writes and runs tests | `subagents-docs/07-test-reports/F01-<slug>.test-report.md` |
| 9 | `/review-feature F01` (any time, optional order) | `code-reviewer` gives a read-only verdict | `subagents-docs/06-reviews/F01-<slug>.review.md` |
| 10 | Fix if needed: `/revise-artifact feature F01 <fixes>` or `/debug-issue <symptom>` | — | `subagents-docs/09-debug-reports/BUG##-…` |
| 11 | `/approve-stage feature F01` | Accepted only if the test report says PASS (or `--force`). Frees the clone for the next feature | — |
| 12 | Repeat steps 5–11 for the remaining features (or batch them) | — | — |

**AI agent track** (when a feature needs an LLM agent or workflow):

| # | You type | Output |
|---|---|---|
| A | `/design-agent <need> [for F03]` | `subagents-docs/04-agent-designs/AD01-<slug>.design.md` |
| B | Review, `/approve-stage design AD01`, then `/build-agent AD01` | code + `subagents-docs/05-implementation-notes/AD01-…` |
| C | `/test-feature AD01`, `/review-feature AD01`, `/approve-stage agent AD01` | — |

**UI design track** (optional, per feature, details in section 5a):

| # | You type | Output |
|---|---|---|
| U1 | `/plan-ui F01 [DESIGN.md path]` | `subagents-docs/11-ui-designs/F01-<slug>.ui-plan.md` |
| U2 | Review, then `/build-ui F01` (approves the UI plan) or `/revise-ui F01 plan <feedback>` | UI in `templates/` + `static/`, `subagents-docs/11-ui-designs/F01-<slug>.ui-build.md` |
| U3 | `/revise-ui F01 build <feedback>` if needed, then `/test-feature F01`, `/review-feature F01` | — |

**Context files:** after the first features exist (or any time the structure changes), run `/claude-md`. It proposes a root `CLAUDE.md` and folder files such as `src/CLAUDE.md` or `static/CLAUDE.md`, explains why each belongs there, and writes only the ones you pick (§5f).

**Your feature depends on a teammate's unfinished one?** Wait, or mock it and connect it later with `/connect-dependency` (walkthrough in §4b, scenario B).

**Not sure what is next?** Run `/show-status`. It always prints the exact next command. For what to type after each command, see §4a.

### Rules to remember

- A stage starts **only** when you type its slash command. Saying "looks good" in words does not advance anything.
- Only **you** can approve (`/approve-stage`). Claude and subagents cannot.
- One feature in progress per clone. Park it with `/revoke-stage active`.
- If you edit an approved file, that approval and everything built on it becomes stale. Re-approve in order (PRD → MoSCoW → plan).

---

## 4. Commands

| Command | Purpose |
|---|---|
| `/start-workflow [mode=auto\|approval] [notes]` | Case study → PRD (auto or section-by-section approval) |
| `/prioritize-moscow [mode=auto\|approval]` | PRD → MoSCoW feature files (auto or feature-by-feature approval) |
| `/switch-mode auto\|approval [prd\|moscow]` | Switch generation mode and continue where it is |
| `/review-step [prd\|moscow] [status\|history\|<steps> approve\|<step> <changes>]` | Mid-session: approve one or several steps, change a step, reopen an accepted one, see progress or the full history; then continue where it stopped |
| `/plan-feature F## [F## …] \| all \| must \| should \| could [--replan]` | Plan one, several, or all features |
| `/implement-feature F## [F## …] \| all \| must … [scope]` | Build one, several, or all plan-approved features |
| `/test-feature F##\|AD##\|<path/module/endpoint>\|all` | Tests + report, on demand, no prerequisite artifacts |
| `/review-feature F##\|AD##\|diff` | Read-only review, on demand |
| `/versions list\|diff\|save\|restore …` | Feature-wise version history of PRD, MoSCoW, plans |
| `/design-agent <need>` | Agent or workflow design |
| `/build-agent AD##` | Implement an approved design |
| `/generate-mock-data <scope>` | Mock data + seed script |
| `/debug-issue <symptom>` | Root cause, minimal fix, test |
| `/prepare-demo` | Demo script, pitch, judges README |
| `/plan-ui F## [design file]` | UI plan for one feature from its plan + `DESIGN.md` |
| `/build-ui F## [pages] [design=path]` | Build or improve that feature's UI (typing it approves the UI plan) |
| `/revise-ui F## plan\|build <feedback>` | Send feedback on a UI plan or a built UI |
| `/connect-dependency <F##…\|all> [--from <branch>] [--into F##]` | Swap a teammate's finished feature in for its mocks: optionally merge their branch, remove every `DEP-MOCK`, wire the real code, rerun tests |
| `/claude-md [all\|<folder> …] [notes]` | Propose root / folder `CLAUDE.md` files with a reason for each location; asks before creating or updating; writes only what you pick |
| `/revise-artifact <stage> [id] <feedback>` | Send your feedback to the owning subagent |
| `/approve-stage <stage> [id] [--force]` | **Human only.** Record approval |
| `/revoke-stage <stage> [id]` / `active` | **Human only.** Withdraw an approval / park the active feature |
| `/show-status` | Where you are and the next command |
| `/show-progress` | MoSCoW completion per Must/Should/Could |

Stage commands use `disable-model-invocation: true`, so only you can start them.

---

## 4a. Command examples: what to pass

**General rule:** subagents never see your chat. Whatever you type after a command (focus notes, feedback, a symptom, an agent need) is passed to the subagent **verbatim**, so make it self-contained:
- name the exact section, feature, endpoint, field, or file;
- say what to change **and** the result you expect;
- paste error output, test names, or request ids instead of "it fails".

Anything Claude needs from you beyond the arguments (mode, UI style, wait or mock) it asks with a question; you do not have to type it.

### PRD and MoSCoW

| You type | When / what it does |
|---|---|
| `/start-workflow` | Asks auto or approval mode, then writes the PRD |
| `/start-workflow mode=approval` | Section by section; you approve each of S01–S16 |
| `/start-workflow mode=auto Primary user is the clinic receptionist. Demo story: book, reschedule, and get an AI summary of a patient's history. Must run offline with mock data. Out of scope: payments, mobile app.` | Everything after `mode=` is **focus notes**. They are saved in the progress record and reused on every step and after a resume |
| `/start-workflow` (again, after closing the chat) | **Resumes** where it stopped: shows accepted / drafted / pending steps and continues. It never restarts from S01 |
| `/prioritize-moscow mode=approval` | OUTLINE (feature table) → one feature per step → FINALIZE |
| `/switch-mode auto prd` · `/switch-mode approval moscow` | Change mode at the next step boundary and continue |

**Good focus notes** cover the main persona, the one end-to-end demo story, hard constraints (offline, data you have, time), what is out of scope, and which judging criterion matters most. Avoid vague notes like "make it innovative".

**Answering a step question.** Choose **Approve and continue**, **Approve all drafted**, **Switch to auto mode**, or **Pause here**, or type changes in **Other**:

| Weak | Strong |
|---|---|
| "personas are wrong" | "Merge personas 2 and 3 into 'Front-desk staff'. Add 'Clinic owner' whose goal is reducing no-shows; pain point: no reminder system today." |
| "add more stories" | "Add a story for rescheduling: the receptionist moves a booking to another free slot, and the patient gets a notification. AC: cannot move into a taken slot (409)." |
| (MoSCoW) "lower priority" | "Make F05 Should, not Must; effort M. It depends on F02, not F01." |
| (MoSCoW) "too big" | "Split F04 into F04 'Upload documents' and a new feature 'Parse documents with AI'. Keep F04's existing acceptance criteria on the upload part." |

### Approve or change a step at any point: `/review-step`

| You type | What happens |
|---|---|
| `/review-step` · `/review-step status` | Progress table for the document being generated, plus the next step |
| `/review-step history` | Complete record: who approved what and when, verbatim change requests, pauses, mode switches |
| `/review-step prd S05 approve` | Approve S05, then continue the loop |
| `/review-step prd S05-S07 approve` · `/review-step moscow F02,F04 approve` · `/review-step prd all approve` | Approve several drafted steps at once (`all` = every drafted step) |
| `/review-step prd S03 Success metrics must be measurable in the demo: booking under 30 s, no-show rate shown on the dashboard.` | Change S03. If S03 was already accepted, it is **reopened**, rewritten next, and the loop then returns to where you were |
| `/review-step moscow F03 Acceptance criteria must include the 404 for another clinic's booking.` | Same, for one MoSCoW feature |

In the chat you can also just say "approve S05-S07" or "change S03: …".

### Plans and implementation

| You type | What it does |
|---|---|
| `/plan-feature F03` | Plan one feature |
| `/plan-feature F01 F02 F04` · `/plan-feature must` · `/plan-feature all` | Plans in parallel **dependency waves** |
| `/plan-feature F03 --replan` | Re-plan a feature that already has a plan (REVISE) |
| `/implement-feature F03` | Build F03 fully. Claude asks the UI style if the plan has UI |
| `/implement-feature F03 backend` · `… frontend` · `… full` | Limit the scope (the last token) |
| `/implement-feature F01 F02 must` · `/implement-feature all` | One run in dependency order; features without an approved plan are listed and left out |

When a dependency is not met, Claude asks **Wait for the teammate** or **Mock it and continue** (§5, "Dependencies between features").

**UI style question.** Pick any of *Modern production-ready*, *Theme*, *Background visuals*, *Motion graphics*. Use **Other** for notes such as: "Calm medical look: teal primary #0F766E, light/dark toggle, cards with soft shadows, no gradients behind tables."

### Testing, review, fixes

| You type | What it does |
|---|---|
| `/test-feature F03` | Tests against F03's approved plan and writes `F03-<slug>.test-report.md`. **PASS** is needed to accept. Without an approved plan, Claude tests the feature's code ad hoc, and that report cannot accept it |
| `/test-feature AD01` | Tests an agent build |
| `/test-feature src/services/booking_service.py` · `/test-feature "POST /api/v1/bookings"` · `/test-feature all` | Ad-hoc scope. Its report (`ADHOC-…`) cannot accept a feature |
| `/review-feature F03` · `/review-feature AD01` · `/review-feature diff` | Read-only review with a verdict and file:line fixes |
| `/debug-issue tests/api/test_bookings.py::test_cannot_double_book fails: AssertionError 201 != 409. Started after adding the reschedule endpoint.` | Root cause, minimal fix, regression test |

**What to pass to `/debug-issue`:** the failing test id or command, the exact error or stack trace (paste it), a request id if you have one, steps to reproduce, and expected vs. actual. "The page is broken" is not enough.

Test results:
- **PASS**: the feature can be accepted.
- **FAIL**: tests failed; the report lists each failure with a suggested fix.
- **MOCKED**: the feature still runs on a teammate's mocks. Connect the real feature first (§4b, scenario B).

### Revising an artifact: `/revise-artifact`

| You type | Goes to |
|---|---|
| `/revise-artifact prd S06 Add US-12 for cancelling a booking; AC: cancelled slots become free immediately.` | `prd-analyst`, that section only. While the PRD is still being generated, this works like `/review-step` |
| `/revise-artifact prd Rename the product to "ClinicFlow" everywhere.` | Whole PRD |
| `/revise-artifact moscow F03 Move to Should; effort S.` | `moscow-prioritizer`, one feature |
| `/revise-artifact plan F03 Add 409 BOOKING_CONFLICT when the slot is taken; cursor pagination on GET /bookings, limit max 50.` | `feature-planner` |
| `/revise-artifact feature F03 GET /api/v1/bookings returns another clinic's bookings. Scope the DAO query by clinic_id and add a test for the 404.` | `feature-implementer` (UI feedback goes to `ui-designer` automatically) |
| `/revise-artifact design AD01 Use a single LLM call instead of an agent loop; the categories are fixed.` · `/revise-artifact agent AD01 <fixes>` | `agent-architect` |

A revised artifact must be approved again: the approval was tied to its old content.

### Dependencies between teammates

| You type | What it does |
|---|---|
| `/connect-dependency F02` | After `git pull`, F02 is accepted here: replace every F02 mock with the real F02 code, in every feature that mocks it |
| `/connect-dependency F02 --from feat/F02-auth` | Merge the teammate's branch first (you approve the merge), then connect |
| `/connect-dependency F02 --into F03` | Connect only F03 |
| `/connect-dependency all` | Every mocked dependency that is now accepted |

### AI agents

| You type | What it does |
|---|---|
| `/design-agent Classify incoming patient messages into booking / reschedule / medical question / other and draft a reply for staff to approve. Input: message text + patient's last 5 bookings. Must answer in under 5 s; never give medical advice; low confidence goes to a human. for F04` | Design: pattern choice, prompts, tools, guardrails, evals |
| `/build-agent AD01` | Build the approved design |

**What to put in a `/design-agent` need:**
- the task in one sentence;
- the inputs, and the output you want back;
- data sources and tools it may use;
- limits (latency, cost, privacy);
- what must never happen;
- when a human takes over;
- the feature it belongs to (`for F##`).

### UI, data, demo, history

| You type | What it does |
|---|---|
| `/plan-ui F03` · `/plan-ui F03 docs/brand/DESIGN.md` | UI plan from the feature plan + design file |
| `/build-ui F03` · `/build-ui F03 dashboard design=docs/brand/DESIGN.md` | Build the UI (typing it approves the UI plan); optional page scope |
| `/revise-ui F03 plan Add an empty state for "no bookings today" with a create button.` · `/revise-ui F03 build Table rows 48px high; status as coloured badges; keep focus outlines.` | Change a UI plan or a built UI |
| `/generate-mock-data F03` · `/generate-mock-data Booking Clinic Patient` · `/generate-mock-data demo` | Realistic mock data + seed script (no approval needed) |
| `/prepare-demo` | Demo script, pitch outline, judges README |
| `/versions list F03` · `/versions diff prd v1.0 current` · `/versions save prd before mentor review` · `/versions restore plan F03 v1.0` | Version history (§5c) |

### CLAUDE.md context files: `/claude-md`

| You type | What happens |
|---|---|
| `/claude-md` | Scans the whole project and proposes what to create or update, each with a reason, then asks you file by file |
| `/claude-md src static` | Only these folders (the root file is still checked for duplicates) |
| `/claude-md all We deploy with docker compose; add the up/down commands. Keep the root under 40 lines.` | Notes go to the curator verbatim |
| `/claude-md mcp_server` | After adding a new top-level folder |

**Good notes** add facts the code does not show: deploy commands, an external service's quirk, a trap that bit the team, a size preference. Do not ask it to copy coding conventions into CLAUDE.md; those already load from `.claude/rules/` when they are needed.

At the question, tick the files you want; untick to skip. Use **Other** for changes such as "P2: also mention `uv run alembic upgrade head`". A request for a new location ("also propose `scripts/`") makes it propose again instead of writing.

### Approvals and status (human only)

| You type | Effect |
|---|---|
| `/approve-stage prd` · `moscow` · `plan F03` · `feature F03` · `design AD01` · `agent AD01` | Record your approval. A feature or agent needs a PASS test report |
| `/approve-stage feature F03 --force` | Accept without PASS. Use only for a known, documented reason; never to skip mocks |
| `/revoke-stage plan F03` | Withdraw an approval; everything built on it becomes stale |
| `/revoke-stage active` | Park the feature in progress in this clone so you can start another |
| `/show-status` · `/show-progress` | Next command, PRD / MoSCoW step progress, mock reminders · Must/Should/Could completion |

### Under the hood: the delegation message

You never have to write these; the commands do. They show exactly what a subagent receives (it sees nothing else from your chat) and which labels the hooks check.

```text
# /implement-feature F03 (teammate's F02 mocked, UI by ui-designer)
Feature ID: F03
Plans: F03: subagents-docs/03-feature-plans/F03-slot-booking.plan.md
Scope: full
UI: ui-designer
Mode: CREATE
Dependency mode: MOCK F02

# /connect-dependency F02 --from feat/F02-auth
Feature ID: F03
Plans: F03: subagents-docs/03-feature-plans/F03-slot-booking.plan.md
Scope: full
Mode: CONNECT
Connect: F02 (plan: subagents-docs/03-feature-plans/F02-auth.plan.md; note: subagents-docs/05-implementation-notes/F02-auth.impl.md)
Merge conflicts: none

# /start-workflow, approval mode, rerunning a reopened step
Case study: CASE_STUDY.md
Mode: CREATE
Generation: STEP
Step: S03
Accepted steps: S01-S02, S04-S07
Step feedback: Success metrics must be measurable in the demo …
Focus notes: Primary user is the clinic receptionist …
Output: subagents-docs/01-prd/PRD.md
```

Keep `Feature ID:`, `Design ID:`, and `MODE:` exact: `stage_gate.py` reads them.

---

## 4b. Walkthroughs

### A. PRD in approval mode, interrupted and resumed

1. `/start-workflow mode=approval Primary user is the clinic receptionist; demo must run offline.`
2. Claude writes S01 and shows it. You choose **Approve and continue**. This repeats for S02–S04.
3. At S05 you choose **Other**: "Scope: drop SMS reminders, keep email only." S05 is rewritten and you approve it.
4. While S06 is being written, you close the laptop.
5. Next day: `/start-workflow`. Claude shows:
   ```text
   PRD progress - approval mode
   Accepted 5/16 | drafted 1 | changes requested 0 | pending 10
     [x] S01 … [x] S05
     [d] S06      6. User stories
   Next: review S06 (already written, waiting for your decision). Resume with /start-workflow.
   ```
   S06 was written before you left, so it is shown for review, not regenerated.
6. You notice personas need a change: `/review-step prd S04 Add a 'Clinic owner' persona focused on no-shows.` S04 is reopened, rewritten, and approved. Then the loop returns to S06.
7. After S16: review the whole PRD, then `/approve-stage prd`. `/review-step history` shows every decision with time and author.

### B. Your feature depends on a teammate's unfinished feature

Asha owns **F02 Auth**; you own **F03 Slot booking**, which depends on F02.

1. `/plan-feature F03`. Claude: "F03 depends on F02 Auth, which has no approved plan." You choose **Mock it and continue**. The plan lists everything assumed about F02 as `ASSUMED (F02)`. Then `/approve-stage plan F03`.
2. `/implement-feature F03`: you choose **Mock it** again (and answer yes if the gate asks "Continue anyway?").
   - The mocks go into `src/mocks/dep_f02.py`.
   - Every wiring line is marked `DEP-MOCK(F02)`.
   - The note gets a `Mocks to remove` table.
3. `/test-feature F03`: the report says `**Overall result:** MOCKED` and `**Tests on mocks:** PASS`. `/approve-stage feature F03` is refused at this point, by design.
4. Asha accepts F02 and pushes `feat/F02-auth`.
5. `/connect-dependency F02 --from feat/F02-auth`. Claude:
   - merges the branch;
   - compares the assumed contract with Asha's real code;
   - adapts F03's own code;
   - deletes the mocks;
   - reruns the tests.

   If F02 lacks something F03 needs, you get `DEP_CONTRACT_GAP` and a message to send Asha. F02's files are never edited.
6. `/test-feature F03` → PASS. Then `/approve-stage feature F03`, then commit with `.workflow/approvals/` and push.

If you would rather wait, choose **Wait for the teammate**: Claude gives you a message to send Asha and suggests another feature you can start meanwhile.

### C. One feature from plan to acceptance, with UI

```text
/plan-feature F01                     → review the plan
/approve-stage plan F01
/implement-feature F01                → UI style: Modern + Theme, builder: ui-designer
/test-feature F01                     → PASS
/review-feature F01                   → APPROVE WITH FIXES
/revise-artifact feature F01 <the reviewer's fixes, pasted>
/test-feature F01                     → PASS
/approve-stage feature F01
git add -A && git commit -m "feat(F01): …" && git push
```

---

## 5. How to use the subagents

### The rule

Do not call a subagent freely. **Start it through its slash command.** The command sends the delegation message to the right subagent, and the hooks check it before the subagent starts.

### Subagents

Each agent's model is set in its frontmatter (`model:`), matched to its work:

| Model | Agents | Why |
|---|---|---|
| `opus` | `prd-analyst`, `moscow-prioritizer`, `feature-planner`, `agent-architect`, `code-reviewer`, `debugger` | Deep reasoning where a mistake spreads downstream: requirements, feature slicing and `Depends on:` lines, API contracts that teammates mock against, agent architecture, finding subtle bugs and security issues, root causes |
| `sonnet` | `feature-implementer`, `ui-designer`, `test-engineer`, `demo-pitch-writer`, `claude-md-curator` | Long, high-volume coding and writing runs that follow an approved plan; strong code quality at good speed and cost |
| `haiku` | `mock-data-generator` | Mechanical, schema-driven data generation |

To change one, edit its `model:` line (`haiku`, `sonnet`, `opus`, or `inherit`).

| Subagent | Started by | Modes / batch | Writes to |
|---|---|---|---|
| `prd-analyst` | `/start-workflow`, `/switch-mode`, `/revise-artifact prd` | `Generation: AUTO` or `STEP` (S01–S16, one section per run) | `subagents-docs/01-prd/` (PRD, `.case-study-digest.md`) |
| `moscow-prioritizer` | `/prioritize-moscow`, `/switch-mode`, `/revise-artifact moscow` | `AUTO` or `STEP` (OUTLINE → each F## → FINALIZE) | `subagents-docs/02-moscow/` |
| `feature-planner` | `/plan-feature`, `/revise-artifact plan` | one feature per run; batches = parallel runs in dependency waves | `subagents-docs/03-feature-plans/` |
| `feature-implementer` | `/implement-feature`, `/revise-artifact feature`, `/connect-dependency` | one feature or an ordered `Batch:` in one run; `UI: ui-designer\|implementer`; `Mode: CONNECT` swaps mocks for the real dependency | `app/`, `src/`, `templates/`, `static/`, `tests/`, `subagents-docs/05-…/F*` |
| `agent-architect` | `/design-agent` (MODE DESIGN), `/build-agent` (MODE BUILD) | — | `subagents-docs/04-…`, `subagents-docs/05-…/AD*`, `src/` |
| `test-engineer` | `/test-feature` | `Feature ID`, `Design ID`, or ad-hoc `Scope:`; no implementation note needed | `tests/`, `subagents-docs/07-test-reports/` |
| `code-reviewer` | `/review-feature` | feature, design, diff, or paths; no tests needed | `subagents-docs/06-reviews/` only (read-only otherwise) |
| `mock-data-generator` | `/generate-mock-data` | — | `data/`, `subagents-docs/08-…` |
| `debugger` | `/debug-issue` | — | `app/`, `src/`, `templates/`, `static/`, `subagents-docs/09-…` |
| `demo-pitch-writer` | `/prepare-demo` | — | `subagents-docs/10-demo/` |
| `claude-md-curator` | `/claude-md` | PROPOSE (analysis + drafts, writes no CLAUDE.md) → you pick → WRITE (only the picked files) | `subagents-docs/12-context/`, `CLAUDE.md`, `<folder>/CLAUDE.md` |
| `ui-designer` | `/plan-ui`, `/build-ui`, `/revise-ui`, **automatically** from `/implement-feature` and UI requests | UI-PLAN, UI-BUILD, **UI-AUTO** (plan + build); `UI style:` modern / theme / background / motion | `subagents-docs/11-ui-designs/`, `templates/`, `static/`, `tests/frontend/` |

### How a subagent run works

1. You type the slash command.
2. `stage_gate.py` checks that the subagent's stage is unlocked, the feature/design ID labels are present (`Feature ID:`, `Design ID:`, `MODE:`), only one feature is active, and dependencies are handled.
3. The subagent preloads its skills, does the work, and writes **only** into its own folders (`protect_files.py` enforces this).
4. It returns a structured **RESULT** block: status, artifacts, summary, review points, open questions, errors, next command.
5. The main conversation turns the RESULT into a **review request** and stops.

### Review request format

```markdown
### <Stage> ready for your review — <item id or "project">
**File(s):** `<path>`
**Summary:** <3-6 bullets>
**Please check:** <3-5 specific review points>
**Open questions:** <questions or "none">

- Approve: `/approve-stage <stage> [id]`
- Request changes: `/revise-artifact <stage> [id] <your feedback>`
- After approval, run: `<next command>`
```

If a subagent returns `blocked` or `error`, the reason and the fix are shown instead.

### Giving feedback to a subagent

Use `/revise-artifact <stage> [id] <feedback>`. The feedback is passed to the owning subagent. Subagents cannot see your chat, so put everything they need in the feedback text (error output, file names, the exact change). Examples per stage, and weak vs. strong feedback: §4a.

### Do and don't

- Do let the owning subagent do its own stage work. The main conversation does not do a subagent's work.
- Do keep the `Feature ID:`, `Design ID:`, `MODE:` labels exact if you ever write a delegation message yourself. Hooks read them.
- Don't ask Claude to edit `.workflow/`, `.claude/hooks/`, `.claude/settings.json`, `.env*`, or the case study.
- Don't try to work around a denied hook. Read the reason it shows and run the command it suggests.

### Dependencies between features

Before `/plan-feature`, `/implement-feature`, `/design-agent`, `/build-agent`, Claude checks the feature's `Depends on:` line. If a dependency is not met, you choose:

- **A. Wait for the teammate.** Claude stops and gives you a ready-to-send message for the teammate who owns it, plus one or two other features you can work on meanwhile. When they have pushed, `git pull` and rerun the same command.
- **B. Mock it and continue.** Claude continues with `Dependency mode: MOCK <F##>`. The plan lists the `ASSUMED (F##)` contract; the code puts mocks only in `src/mocks/dep_<f##>.py` / `static/js/mocks/dep-<f##>.js`, every wiring line is marked `DEP-MOCK(<F##>)`, and the implementation note gets a `Mocks to remove` table.

The mock lifecycle:

1. `/implement-feature F03`: built on mocks of F02.
2. `/test-feature F03`: the report says `**Overall result:** MOCKED` (with `Tests on mocks: PASS|FAIL`). The approval hook accepts only PASS, so F03 cannot be accepted yet.
3. The teammate finishes F02, accepts it, and pushes.
4. `/connect-dependency F02 --from feat/F02-<slug>` (or `git pull` first and leave out `--from`). Claude merges the branch and finds every feature mocking F02. The implementer (`Mode: CONNECT`) then:
   - compares each assumed item with the real contract;
   - adapts this feature's own code;
   - deletes the mocks and markers and reruns the tests;
   - records a `Dependency connections` table in the note.

   It never edits F02's files. A missing piece in F02 comes back as `DEP_CONTRACT_GAP`, with a message for the teammate.
5. `/test-feature F03` again for a PASS, then `/approve-stage feature F03`.

---

## 5a. UI design agent (`ui-designer`)

A UI/UX specialist that reads your `DESIGN.md` and one feature plan, plans the screens from the feature's flows, and then builds a production-ready, styled UI (or improves the existing one) in plain HTML/CSS/JS.

### Automatic use and style choice

Whenever work involves a UI, Claude routes it to `ui-designer`. That covers:
- `/implement-feature` with frontend in scope, when the plan says `UI involvement: yes`;
- `/revise-artifact feature` feedback about pages, styling, theme, or animation;
- a UI request typed in chat.

First, Claude asks once per command:

| Question | Options |
|---|---|
| **UI style** (pick one or more) | **Modern production-ready** (always the baseline: clean, accessible, polished states, responsive) · **Theme** (brand palette, light/dark tokens, remembered toggle) · **Background visuals** (gradients, patterns, inline-SVG illustrations, glass surfaces; contrast kept ≥ 4.5:1) · **Motion graphics** (micro-interactions, staggered entry, scroll reveal, animated SVG; always with a `prefers-reduced-motion` fallback). Use "Other" for your own style notes |
| **Builder** | `ui-designer` (recommended) · basic UI from the implementer (skips the ui-designer) |

With `ui-designer` chosen:
- the implementer builds the backend and the frontend service module;
- then `ui-designer` runs in **UI-AUTO** mode (UI plan + build in one run), one feature at a time;
- you review the result once and refine it with `/revise-ui F## build <feedback>`.

`/plan-ui` also asks the style question. If `DESIGN.md` is missing, the visual system is derived from the chosen style (with an open question to add `DESIGN.md` later) instead of stopping.

### What it uses

| Source | Role |
|---|---|
| `DESIGN.md` (project root, or a path you pass) | Your brand and visual rules: colours, typography, spacing, radius, motion, tone, component style. Its values become tokens in `static/css/tokens.css` |
| Feature plan `subagents-docs/03-feature-plans/F##-*.plan.md` | Flows, user stories, states, and the API contract. The UI never adds behaviour the plan does not have |
| `ui-ux-pro-max` skill (`.claude/skills/ui-ux-pro-max/`) | UX, accessibility, layout, colour, typography, and chart guidance where `DESIGN.md` is silent |
| 21st MCP server | Component ideas (cards, tables, forms, empty states). Its React/Tailwind output is **translated** into vanilla HTML/CSS/JS, never pasted |

Project rules still win over all of them: no frameworks, no build step, tokens only in `tokens.css`, no `innerHTML` with data, CSP kept.

### One-time setup (each teammate)

1. Add a `DESIGN.md` to the project root. Suggested sections: brand and tone, colour palette (light + dark), typography (fonts, scale), spacing and radius, shadows, motion, component style (buttons, cards, tables, forms), do / don't, reference screenshots or links.
2. The `ui-ux-pro-max` skill is in the repo (`.claude/skills/ui-ux-pro-max/`). It needs only `python3`.
3. Add the 21st MCP server **in your own clone, with your own key**, in local scope (never `--scope project`, which would put the key in `.mcp.json` and in git):
   ```bash
   claude mcp add --transport http 21st https://21st.dev/api/mcp --header "x-api-key: <YOUR_21ST_KEY>"
   claude mcp list   # 21st should show "Connected"
   ```
   Restart Claude Code after adding it. Without 21st the agent still works and notes `MCP_21ST_UNAVAILABLE` in its doc.

### How to use it

| Step | You type | What happens | Output |
|---|---|---|---|
| 1 | `/plan-ui F03` (or `/plan-ui F03 docs/DESIGN.md`) | Reads the plan, `DESIGN.md`, and the existing pages; lists screens, flow, layouts, components, states, tokens, accessibility, data mapping | `subagents-docs/11-ui-designs/F03-<slug>.ui-plan.md` |
| 2 | Review the UI plan. Changes: `/revise-ui F03 plan <feedback>` | Same file revised, version bumped | — |
| 3 | `/build-ui F03` (optional page scope: `/build-ui F03 dashboard`) | **Typing this approves the UI plan.** Creates the UI if none exists, otherwise improves it (keeps behaviour, API calls, and element ids) | `templates/…`, `static/…`, `tests/frontend/…`, `subagents-docs/11-ui-designs/F03-<slug>.ui-build.md` |
| 4 | Open the page URL from the build note. Changes: `/revise-ui F03 build <feedback>` | UI and build note revised | — |
| 5 | `/test-feature F03`, `/review-feature F03`, then `/approve-stage feature F03` | The UI is tested and accepted as part of the feature | — |

### When to run it

- **Before `/implement-feature`** (needs an approved feature plan): run `/plan-ui`, review it, then `/implement-feature F##`. The `feature-implementer` follows the UI plan for the frontend; afterwards `/build-ui` can polish it.
- **After `/implement-feature`**: run `/plan-ui` then `/build-ui` to improve the existing UI before `/test-feature`.
- On an already accepted feature: changing the UI changes the feature, so rerun `/test-feature` and `/review-feature` afterwards.

### Rules and limits

- Approval of the UI plan is your `/build-ui` command. It is not recorded in `.workflow/approvals/`; the feature itself is still accepted only with `/approve-stage feature F##`.
- `/build-ui` needs the feature plan approved (`/approve-stage plan F##`), because application code is locked before that.
- The agent writes only to `subagents-docs/11-ui-designs/`, `templates/`, `static/`, `tests/frontend/`. It never changes the backend; missing data or endpoints become `OPEN QUESTION:` items with a suggested `/revise-artifact feature F## …`.
- These write limits are in the agent's instructions; the hooks do not know this agent, so review its diff like any other.
- 21st receives only generic component descriptions, never your code, data, or the case study.

---

## 5b. Generation modes: auto vs approval (PRD and MoSCoW)

`/start-workflow` and `/prioritize-moscow` ask which mode you want. You can also pass `mode=auto` / `mode=approval`.

| Mode | PRD | MoSCoW |
|---|---|---|
| **Auto** (one shot) | Whole PRD in one run; review at the end | Whole set (index, every feature, won't-have) in one run |
| **Approval** (step by step) | One section per step: S01 Executive summary … S16 Traceability + self-check | OUTLINE (feature table) → one feature file per step (F01, F02, …) → FINALIZE (won't-have, build order, capacity) |

**In approval mode**, after every step Claude shows the section or feature and asks:
- **Approve and continue**: goes to the next step.
- **Approve all drafted**: shown when several steps are written but not reviewed (after an auto run or a resume).
- **Other: <your changes>**: the same step is redone with your exact words. This repeats until you approve. For MoSCoW you can also change the priority here ("make this Should").
- **Switch to auto mode**: accepts this step and writes the rest in one run.
- **Pause here**: stops. Rerun the same command later to resume.

**Approve or change at any point (mid-session):** besides answering the question, you can say or type:
- "approve S05-S07";
- "change S03: …": reopens an accepted section;
- `/review-step prd S03 <changes>`;
- `/review-step moscow F02,F04 approve`;
- `/review-step status` or `/review-step history`.

A reopened step is rewritten next, then the loop goes back to where it was. Later accepted steps stay accepted; if they now conflict, Claude lists it and offers to reopen them too.

**Closing the chat never loses progress.** Every decision is recorded the moment you make it by `.claude/scripts/step_progress.py`, in `subagents-docs/01-prd/.prd-progress.json` / `subagents-docs/02-moscow/.moscow-progress.json`: approvals (who, when), change requests (verbatim), reopened steps, mode, focus notes, pauses, and a full timestamped history.

The subagents write one section or feature at a time, and the script reads the documents. So a step written just before the chat closed (or by an auto run that was cut off) is **recovered as drafted**, and you review it instead of regenerating it.

To resume, type `/start-workflow` (PRD), `/prioritize-moscow` (MoSCoW), or `/review-step`. Claude shows where it stopped and continues from the first unfinished step, never from S01. `/show-status` also shows the step progress. If someone edits an accepted section by hand, the status warns that it changed after acceptance.

**Switching mode mid-chat:** pick the option above, type `/switch-mode auto|approval`, or just say it ("switch to auto", "let's go section by section").
- **Approval → auto:** the remaining steps are written in one run; accepted sections are never changed.
- **Auto → approval:** Claude walks you through the finished draft section by section (or feature by feature). Only the parts you change are rewritten.

Step approvals in chat are **not** stage approvals. When the document is complete you still run `/approve-stage prd` or `/approve-stage moscow`.

To change a single section or feature of an approved artifact: `/revise-artifact prd S06 <feedback>` or `/revise-artifact moscow F03 <feedback>`.

## 5c. Version control (feature-wise)

Claude saves a version automatically:
- when the PRD or MoSCoW set is complete;
- before and after every `/revise-artifact`;
- after every plan.

Saving does nothing if the content has not changed. Snapshots go to `subagents-docs/versions/`, which no approval hashes, so saving never invalidates an approval.

| What is kept | Where |
|---|---|
| Every PRD version | `subagents-docs/versions/prd/<version>/PRD.md` |
| Per-section and **per-flow** history of the PRD (only changed parts get a new version) | `subagents-docs/versions/prd/sections/<section>/<version>.md` |
| Per PRD version: which sections/flows, which `US-##`/`FR-##` rows changed, and **which features (F##) are affected** | `subagents-docs/versions/VERSIONS.md` |
| Every MoSCoW set version | `subagents-docs/versions/moscow/<version>/` |
| **Per feature**: each version of its MoSCoW file and its plan | `subagents-docs/versions/features/F##-<slug>/{moscow,plan}/<version>.md` |

Version labels come from each document's own `Version` field (v1.0, v1.1, …). A save with an unchanged label gets a suffix such as `v1.0-r2`.

| You type | Result |
|---|---|
| `/versions list` / `/versions list prd` | History |
| `/versions list F03` | Everything about F03: its MoSCoW and plan versions, plus the PRD versions that changed its stories or requirements |
| `/versions diff prd v1.0 current` · `/versions diff moscow F03 v1.0 v1.1` · `/versions diff plan F03 v1.0` | Diff |
| `/versions save prd "before workshop"` | Manual snapshot |
| `/versions restore prd v1.0` · `/versions restore moscow F03 v1.0` · `/versions restore plan F03 v1.0` | Restore. The current state is saved first. The artifact's approval becomes stale: re-approve in order |

Terminal equivalent: `python3 .claude/scripts/artifact_versions.py list`. Commit `subagents-docs/versions/` so the team shares the history.

## 5d. One, several, or all features in one command

| Command | What happens |
|---|---|
| `/plan-feature F01` | One planner run (as before) |
| `/plan-feature F01 F02 F04` · `must` · `should` · `could` · `all` | Claude groups the features into **dependency waves**:<ul><li>each wave's planners run **in parallel**;</li><li>later waves reuse earlier waves' draft plans (`SIBLING (F##, draft)`).</li></ul>Features that already have a plan are skipped unless you name them or add `--replan`. You get one table and one `/approve-stage plan F##` line per plan |
| `/implement-feature F01` | One feature (as before) |
| `/implement-feature F01 F02` · `must` · `all` [scope] | **One** implementer run builds the features **in dependency order**:<ul><li>it writes one implementation note per feature;</li><li>if one is blocked, its dependants are skipped and the rest continue.</li></ul>Only features whose plan is approved are included; Claude lists any left out |

Notes:
- Dependencies inside the same batch count as met (built first, or planned in an earlier wave). The dependency question (wait or mock) is asked once, only for dependencies outside the batch.
- **Hook limitation:** the stage gate (`stage_gate.py`, protected) allows one in-progress feature per clone and reads only the first `Feature ID:`. That is why batch implementation is a single run, and why Claude checks every plan's approval itself before delegating. After a batch, `/show-status` shows only the first feature as "in progress". Accept each feature separately with `/approve-stage feature F##`.
- Large batches use a lot of context. Prefer 2–4 related features per `/implement-feature` call; `all` works but takes long.

## 5e. Independent subagents

- No subagent starts, requires, or waits for another one. The `next_command` in every result is a **suggestion**.
- `/test-feature` works on a feature with or without an implementation note, using the best basis available (plan → MoSCoW file → code contract). It also accepts paths, modules, endpoints, or `all` as an ad-hoc scope (report: `ADHOC-<scope>.test-report.md`). An ad-hoc report cannot be used to accept a feature.
- `/review-feature` needs neither tests nor a test report.
- The only hard prerequisites left are the human approvals enforced by the hooks: PRD before MoSCoW, MoSCoW before plans, plan before implementation, and a PASS test report before acceptance.

## 5f. CLAUDE.md context files (`/claude-md`)

`CLAUDE.md` files tell Claude the few things it cannot see in the code: how to run and test, where things are, and traps. Every line costs context, in every session that loads it, so the kit keeps them short and puts everything else where it loads only when needed.

### What loads when

| Source | In context | Holds |
|---|---|---|
| Root `CLAUDE.md` | Every session, every turn | Purpose (1 line), commands, top-level map, project-wide traps |
| `<folder>/CLAUDE.md` | Only once Claude works in that folder | That folder's entry points, commands, local traps |
| `.claude/rules/*.md` with `paths:` | Only for matching files | Coding conventions (backend, API, agents, frontend, tests) |
| `.claude/rules/*.md` without `paths:` | Every session | Workflow gates, generation modes, security, team work |
| Skills | Description always; body only when used | Long standards, procedures, examples |
| `subagents-docs/` | Only when read | PRD, features, plans, reports: never copied into a CLAUDE.md |

### How `/claude-md` works

1. **Propose.** `claude-md-curator` reads:
   - the file tree, manifests (`pyproject.toml`, `package.json`, …) and the real commands;
   - existing CLAUDE.md files, and the scope of every `.claude/rules/` file;
   - the MoSCoW index, plans, implementation notes, debug reports, and reviews.

   It writes `subagents-docs/12-context/CLAUDE-MD-PROPOSAL.md`, with a complete draft and the evidence for each file. **No CLAUDE.md is touched yet.**
2. **You decide.** Claude shows a table (file, create / update, lines, **why this location**, with evidence), plus what was left out on purpose and where it lives instead. Then it asks which files to write.
3. **Write.** Only the files you ticked are created or updated. Updates never silently remove your own text: every removal is listed in the proposal first.

Example proposal:

| ID | File | Action | Lines | Why here |
|---|---|---|---|---|
| P1 | `CLAUDE.md` | create | 38 | Every session needs the `uv` commands, the app entry point (`app/main.py`), and that generated docs live in `subagents-docs/` |
| P2 | `src/CLAUDE.md` | create | 24 | 31 Python files across 6 layers, with a wiring order (`providers.py` → `router.py`) that `30-backend-python.md` does not describe |
| P3 | `static/CLAUDE.md` | create | 18 | Its own test command (`node --test tests/frontend/`) and generated `tokens.css` that must not be hand-edited |
| — | `tests/` | not proposed | — | `70-testing.md` already covers it; no extra commands |

### The rules every CLAUDE.md follows (`.claude/skills/claude-md-standards/`)

- **Include only** what Claude would otherwise get wrong in most sessions in that scope:
  - exact commands (copied from manifests, never invented);
  - a map of the non-obvious entry points;
  - conventions not covered by a rule or skill;
  - traps.
- **Exclude:**
  - anything already in `.claude/rules/` or a skill (point to it instead);
  - generic advice ("write clean code");
  - file-by-file descriptions;
  - volatile facts (status, owners, dates);
  - specs, PRD or plan text;
  - long code blocks;
  - secrets.
- **Budgets:** root 30–60 lines (max 80); folder 10–30 lines (max 40).
- **Folder files** only with an evidence-backed reason (distinct stack, own commands, non-obvious structure, recurring traps). Never for small, generated, vendored, or docs folders, or folders already covered by a rule. Prefer one file per area (`src/`) over one per subfolder.

When to rerun: after the first `/implement-feature` (Claude suggests it when a new top-level code folder appears), after adding a stack or a folder, or when a trap keeps recurring. Review the written files and commit them; they shape every teammate's sessions.

---

## 6. Team usage (parallel work)

- Everyone together: the lead runs steps 1–4 (PRD and MoSCoW), the team reviews, then commit and push `subagents-docs/` and `.workflow/approvals/*.json`.
- After that, each teammate works in their own clone on `feat/F##-<slug>` and runs plan → implement → test → review → accept for their own feature.
- Before every stage: `git pull`. After every approval: commit code together with its `.workflow/approvals/` files and push.
- In shared files, add only your own feature's section. Do not reformat other features' code.
- `.workflow/local/` (the in-progress marker and activity log) is per clone and git-ignored; never commit it.
- `CLAUDE.md` files are shared: one person runs `/claude-md`, the team reviews the files in the pull request.
- Waiting on a teammate's feature: choose **wait** or **mock** (see "Dependencies between features"); mocked work is joined to the real feature with `/connect-dependency`.

---

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| Hooks don't run | Accept workspace trust; check `/hooks`; run `python3 .claude/hooks/workflow_state.py status` |
| `/approve-stage` says the hook did not run | Update Claude Code; or run `python3 .claude/hooks/workflow_state.py approve plan F01` in your own terminal |
| "Stage locked: … changed after approval" | You edited an approved file. Review it and approve again in order |
| "F01 is still in progress in this clone" | Accept it, or park it with `/revoke-stage active` |
| Command aborts on `python3` | Windows: replace `python3` with `python` / `py` |
| Model error on a subagent | Change its `model:` line in `.claude/agents/<name>.md` (e.g. `haiku`, `sonnet`, `opus`) |
| UI plan says `Design file: none, derived from UI style` | Fine for a start. Add `DESIGN.md` to lock the brand, then `/revise-ui F## plan use DESIGN.md` |
| Generation stopped half way (chat closed, crash, pause) | Rerun `/start-workflow` or `/prioritize-moscow` (or `/review-step`); it resumes from the last recorded decision and recovers steps already written. `/review-step history` shows the full record |
| Batch implement refused with "F0x is still in progress" | Accept that feature, `/revoke-stage active`, or include it in the batch (Claude puts it first) |
| `/versions` says "No versions saved yet" | Run `/versions save prd` (or `moscow`, `plan F##`) once; later saves are automatic |
| UI doc says `MCP_21ST_UNAVAILABLE` | Run `claude mcp list`; add or re-key the 21st server (section 5a) and restart Claude Code |
| "Subagent '…' may only write to: docs/…" or "Missing docs/01-prd/PRD.md" | The hooks still point at the old `docs/` folder. Apply the hooks update that moves them to `subagents-docs/` (one-time, done by a human in their own terminal), then commit it |
| A CLAUDE.md keeps growing | Rerun `/claude-md` with the note "trim to budget"; conventions move to `.claude/rules/`, procedures to a skill |
| `uv: command not found` | Install uv: <https://docs.astral.sh/uv/getting-started/installation/> |

Emergency only: `python3 .claude/hooks/workflow_state.py bypass on` in your own terminal (`bypass off` to undo). Secret and ledger protection stay on.
